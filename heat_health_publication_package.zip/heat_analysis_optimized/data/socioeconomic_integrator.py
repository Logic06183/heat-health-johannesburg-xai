"""
Socio-Economic Data Integration for Heat-Health XAI Analysis

Integrates GCRO Quality of Life Survey data with existing optimal XAI datasets
to add social determinants of heat vulnerability.

GCRO Data Available:
- 2009, 2011, 2013-2014, 2015-2016, 2017-2018, 2020-2021
- Comprehensive socio-economic indicators
- Johannesburg metro area (matches our health data location)
"""

import pandas as pd
import numpy as np
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any
import logging
from datetime import datetime
import warnings
import zipfile

warnings.filterwarnings('ignore')

class SocioEconomicIntegrator:
    """
    Integrates GCRO socio-economic data with heat-health datasets.
    """
    
    def __init__(self, base_path: str = "/home/cparker"):
        self.base_path = Path(base_path)
        self.se_path = self.base_path / "selected_data_all" / "data" / "socio-economic" / "RP2" / "JHB" / "GCRO" / "quailty_of_life"
        self.xai_path = self.base_path / "heat_analysis_optimized" / "data" / "optimal_xai_ready"
        self.output_path = self.base_path / "heat_analysis_optimized" / "data" / "socioeconomic_integrated"
        
        # Create output directory
        self.output_path.mkdir(parents=True, exist_ok=True)
        
        # Setup logging
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)
        
        # Key socio-economic variables to extract
        self.se_variables = {
            'income': ['income', 'household_income', 'personal_income', 'earnings', 'wage'],
            'employment': ['employment', 'employed', 'job', 'work', 'unemployed', 'occupation'],
            'education': ['education', 'school', 'tertiary', 'matric', 'qualification', 'degree'],
            'housing': ['housing', 'dwelling', 'rooms', 'toilet', 'water', 'electricity', 'formal_dwelling'],
            'transport': ['transport', 'taxi', 'bus', 'car', 'travel', 'commute'],
            'health_access': ['clinic', 'hospital', 'health', 'medical', 'treatment'],
            'food_security': ['food', 'hungry', 'meals', 'afford_food'],
            'safety': ['crime', 'safe', 'violence', 'afraid', 'security'],
            'social_capital': ['trust', 'community', 'social', 'network', 'support'],
            'life_satisfaction': ['satisfaction', 'happy', 'quality_life', 'wellbeing']
        }
    
    def discover_gcro_datasets(self) -> Dict[str, Dict]:
        """
        Discover all available GCRO Quality of Life datasets.
        """
        self.logger.info("=" * 80)
        self.logger.info("🔍 DISCOVERING GCRO SOCIO-ECONOMIC DATASETS")
        self.logger.info("=" * 80)
        
        datasets = {}
        
        # Check each year directory
        if self.se_path.exists():
            year_dirs = [d for d in self.se_path.iterdir() if d.is_dir() and d.name != 'metadata']
            
            for year_dir in sorted(year_dirs):
                self.logger.info(f"\\n📅 YEAR: {year_dir.name}")
                
                native_path = year_dir / "native"
                if native_path.exists():
                    # Look for CSV files (direct or in zip)
                    csv_files = list(native_path.glob("*.csv"))
                    zip_files = list(native_path.glob("*csv*.zip"))
                    csv_dirs = [d for d in native_path.iterdir() if d.is_dir() and 'csv' in d.name.lower()]
                    
                    dataset_info = {
                        'year': year_dir.name,
                        'path': native_path,
                        'csv_files': csv_files,
                        'zip_files': zip_files,
                        'csv_dirs': csv_dirs,
                        'data_file': None,
                        'records': 0,
                        'variables': 0
                    }
                    
                    # Try to find the main data file
                    data_file = None
                    
                    # Check direct CSV files
                    if csv_files:
                        data_file = csv_files[0]
                        self.logger.info(f"   📄 Direct CSV: {data_file.name}")
                    
                    # Check CSV directories
                    elif csv_dirs:
                        csv_dir = csv_dirs[0]
                        csv_in_dir = list(csv_dir.glob("*.csv"))
                        if csv_in_dir:
                            data_file = csv_in_dir[0]
                            self.logger.info(f"   📄 CSV in directory: {data_file.name}")
                    
                    # Check zip files
                    elif zip_files:
                        zip_file = zip_files[0]
                        self.logger.info(f"   📦 ZIP file: {zip_file.name}")
                        # Try to extract and find CSV
                        try:
                            with zipfile.ZipFile(zip_file, 'r') as z:
                                csv_files_in_zip = [f for f in z.namelist() if f.endswith('.csv')]
                                if csv_files_in_zip:
                                    # Extract first CSV
                                    extract_path = native_path / "extracted"
                                    extract_path.mkdir(exist_ok=True)
                                    z.extract(csv_files_in_zip[0], extract_path)
                                    data_file = extract_path / csv_files_in_zip[0]
                                    self.logger.info(f"   📄 Extracted: {csv_files_in_zip[0]}")
                        except Exception as e:
                            self.logger.error(f"   Error extracting ZIP: {e}")
                    
                    if data_file and data_file.exists():
                        try:
                            # Quick check of data file
                            df_sample = pd.read_csv(data_file, nrows=5)
                            df_info = pd.read_csv(data_file, nrows=0)  # Just header
                            
                            dataset_info['data_file'] = data_file
                            dataset_info['variables'] = len(df_info.columns)
                            
                            # Get record count (expensive, so do it properly)
                            with open(data_file, 'r') as f:
                                dataset_info['records'] = sum(1 for line in f) - 1  # Subtract header
                            
                            self.logger.info(f"   📊 Records: {dataset_info['records']:,}")
                            self.logger.info(f"   📊 Variables: {dataset_info['variables']}")
                            
                            # Check for key socio-economic variables
                            se_vars_found = []
                            columns_lower = [col.lower() for col in df_info.columns]
                            
                            for se_category, patterns in self.se_variables.items():
                                for pattern in patterns:
                                    if any(pattern in col for col in columns_lower):
                                        se_vars_found.append(se_category)
                                        break
                            
                            if se_vars_found:
                                self.logger.info(f"   🏠 SE categories found: {len(se_vars_found)} - {se_vars_found[:5]}")
                                dataset_info['se_categories'] = se_vars_found
                            
                            datasets[year_dir.name] = dataset_info
                            
                        except Exception as e:
                            self.logger.error(f"   Error analyzing data file: {e}")
                    else:
                        self.logger.warning(f"   No data file found")
        
        total_records = sum(d['records'] for d in datasets.values())
        self.logger.info(f"\\n📊 DISCOVERY SUMMARY:")
        self.logger.info(f"   Datasets found: {len(datasets)}") 
        self.logger.info(f"   Total records: {total_records:,}")
        self.logger.info(f"   Years covered: {sorted(datasets.keys())}")
        
        return datasets
    
    def extract_socioeconomic_features(self, dataset_info: Dict) -> pd.DataFrame:
        """
        Extract key socio-economic features from a GCRO dataset.
        """
        data_file = dataset_info['data_file']
        year = dataset_info['year']
        
        self.logger.info(f"\\n📥 Extracting SE features from {year}")
        
        try:
            # Load the dataset
            df = pd.read_csv(data_file, low_memory=False)
            self.logger.info(f"   Loaded {len(df)} records, {len(df.columns)} variables")
            
            # Create standardized socio-economic dataset
            se_df = pd.DataFrame()
            
            # Add metadata
            se_df['participant_id'] = [f"gcro_{year}_{i:05d}" for i in range(len(df))]
            se_df['se_survey_year'] = year
            se_df['se_data_source'] = 'gcro_qols'
            
            # Extract location information
            location_vars = ['ward', 'municipality', 'region', 'area', 'suburb']
            for loc_var in location_vars:
                matching_cols = [col for col in df.columns if loc_var in col.lower()]
                if matching_cols:
                    se_df[f'se_location_{loc_var}'] = df[matching_cols[0]]
                    break
            
            # Extract standardized socio-economic variables
            features_extracted = 0
            
            for se_category, patterns in self.se_variables.items():
                category_features = []
                
                for col in df.columns:
                    col_lower = col.lower()
                    if any(pattern in col_lower for pattern in patterns):
                        # Try to create standardized feature
                        try:
                            # Attempt numeric conversion
                            numeric_values = pd.to_numeric(df[col], errors='coerce')
                            if numeric_values.notna().sum() > len(df) * 0.1:  # At least 10% valid
                                feature_name = f'se_{se_category}_{col.lower()[:20]}'  # Truncate long names
                                se_df[feature_name] = numeric_values
                                category_features.append(feature_name)
                                features_extracted += 1
                            else:
                                # Keep as categorical if mostly non-numeric
                                feature_name = f'se_{se_category}_cat_{col.lower()[:15]}'
                                se_df[feature_name] = df[col].astype(str)
                                category_features.append(feature_name)
                                features_extracted += 1
                        except:
                            pass
                
                # Create category summary variables
                if category_features:
                    # Count of non-missing values in this category
                    numeric_features = [f for f in category_features if not 'cat_' in f]
                    if numeric_features:
                        se_df[f'se_{se_category}_completeness'] = se_df[numeric_features].notna().sum(axis=1)
                        
                        # Average for numeric features (where appropriate)
                        if se_category in ['life_satisfaction', 'safety']:
                            se_df[f'se_{se_category}_avg'] = se_df[numeric_features].mean(axis=1)
            
            # Create composite indices
            self._create_composite_indices(se_df)
            
            self.logger.info(f"   ✅ Extracted {features_extracted} SE features")
            self.logger.info(f"   📊 Final SE dataset: {len(se_df)} records, {len(se_df.columns)} variables")
            
            return se_df
            
        except Exception as e:
            self.logger.error(f"Error extracting SE features from {year}: {e}")
            return pd.DataFrame()
    
    def _create_composite_indices(self, se_df: pd.DataFrame) -> None:
        """
        Create composite socio-economic indices.
        """
        # Socio-Economic Status (SES) composite
        ses_components = []
        
        # Income components
        income_cols = [col for col in se_df.columns if 'se_income' in col and 'cat_' not in col]
        if income_cols:
            se_df['se_income_index'] = se_df[income_cols].mean(axis=1)
            ses_components.append('se_income_index')
        
        # Education components
        education_cols = [col for col in se_df.columns if 'se_education' in col and 'cat_' not in col]
        if education_cols:
            se_df['se_education_index'] = se_df[education_cols].mean(axis=1)
            ses_components.append('se_education_index')
        
        # Employment components
        employment_cols = [col for col in se_df.columns if 'se_employment' in col and 'cat_' not in col]
        if employment_cols:
            se_df['se_employment_index'] = se_df[employment_cols].mean(axis=1)
            ses_components.append('se_employment_index')
        
        # Housing quality components
        housing_cols = [col for col in se_df.columns if 'se_housing' in col and 'cat_' not in col]
        if housing_cols:
            se_df['se_housing_index'] = se_df[housing_cols].mean(axis=1)
            ses_components.append('se_housing_index')
        
        # Create overall SES index
        if ses_components:
            se_df['se_composite_ses_index'] = se_df[ses_components].mean(axis=1)
        
        # Vulnerability index (inverse of protective factors)
        vulnerability_components = []
        
        # Food security (low = high vulnerability)
        food_cols = [col for col in se_df.columns if 'se_food_security' in col and 'cat_' not in col]
        if food_cols:
            se_df['se_food_vulnerability'] = -se_df[food_cols].mean(axis=1)  # Invert so high = vulnerable
            vulnerability_components.append('se_food_vulnerability')
        
        # Safety (low = high vulnerability)
        safety_cols = [col for col in se_df.columns if 'se_safety' in col and 'cat_' not in col]
        if safety_cols:
            se_df['se_safety_vulnerability'] = -se_df[safety_cols].mean(axis=1)
            vulnerability_components.append('se_safety_vulnerability')
        
        # Health access (low = high vulnerability)
        health_cols = [col for col in se_df.columns if 'se_health_access' in col and 'cat_' not in col]
        if health_cols:
            se_df['se_health_access_vulnerability'] = -se_df[health_cols].mean(axis=1)
            vulnerability_components.append('se_health_access_vulnerability')
        
        # Create overall vulnerability index
        if vulnerability_components:
            se_df['se_composite_vulnerability_index'] = se_df[vulnerability_components].mean(axis=1)
    
    def integrate_with_xai_datasets(self, se_datasets: Dict[str, pd.DataFrame]) -> Dict[str, pd.DataFrame]:
        """
        Integrate socio-economic data with existing XAI datasets.
        """
        self.logger.info("\\n" + "=" * 60)
        self.logger.info("🔗 INTEGRATING SE DATA WITH XAI DATASETS")
        self.logger.info("=" * 60)
        
        # Load existing XAI datasets
        xai_files = {
            'high_quality': 'xai_ready_high_quality.csv',
            'dphru_053_optimal': 'xai_ready_dphru_053_optimal.csv',
            'dphru_013_optimal': 'xai_ready_dphru_013_optimal.csv',
            'vida_008_optimal': 'xai_ready_vida_008_optimal.csv'
        }
        
        integrated_datasets = {}
        
        for dataset_name, filename in xai_files.items():
            file_path = self.xai_path / filename
            
            if file_path.exists():
                self.logger.info(f"\\n🔗 Integrating with {dataset_name}")
                
                try:
                    xai_df = pd.read_csv(file_path)
                    self.logger.info(f"   📊 XAI dataset: {len(xai_df)} records, {len(xai_df.columns)} variables")
                    
                    # Create integrated version
                    integrated_df = self._spatial_temporal_integration(xai_df, se_datasets, dataset_name)
                    
                    if not integrated_df.empty:
                        integrated_datasets[dataset_name] = integrated_df
                        self.logger.info(f"   ✅ Integration complete: {len(integrated_df.columns)} total variables")
                    
                except Exception as e:
                    self.logger.error(f"   Error integrating {dataset_name}: {e}")
            else:
                self.logger.warning(f"   XAI file not found: {filename}")
        
        return integrated_datasets
    
    def _spatial_temporal_integration(self, xai_df: pd.DataFrame, se_datasets: Dict[str, pd.DataFrame], dataset_name: str) -> pd.DataFrame:
        """
        Integrate SE data using spatial and temporal matching.
        """
        integrated_df = xai_df.copy()
        
        # Get dataset temporal coverage
        if 'std_visit_date' in integrated_df.columns:
            valid_dates = integrated_df['std_visit_date'].notna()
            if valid_dates.sum() > 0:
                date_range = pd.to_datetime(integrated_df.loc[valid_dates, 'std_visit_date'])
                min_year = date_range.dt.year.min()
                max_year = date_range.dt.year.max()
            else:
                min_year, max_year = 2015, 2020  # Default range
        else:
            min_year, max_year = 2015, 2020  # Default range
        
        self.logger.info(f"   📅 Dataset date range: {min_year}-{max_year}")
        
        # Find best matching SE dataset(s)
        matching_se_datasets = []
        
        for year, se_df in se_datasets.items():
            se_year = int(year.split('-')[0]) if '-' in year else int(year)
            if min_year <= se_year <= max_year + 5:  # Allow some flexibility
                matching_se_datasets.append((year, se_df, abs(se_year - np.mean([min_year, max_year]))))
        
        # Sort by temporal proximity
        matching_se_datasets.sort(key=lambda x: x[2])
        
        if matching_se_datasets:
            best_year, best_se_df, distance = matching_se_datasets[0]
            self.logger.info(f"   🎯 Best matching SE data: {best_year} (distance: {distance:.1f} years)")
            
            # Since we can't do exact spatial matching, use representative SE values
            # Sample from SE dataset to represent population characteristics
            n_samples = min(len(best_se_df), 1000)  # Use up to 1000 representative samples
            se_sample = best_se_df.sample(n_samples, random_state=42)
            
            # Calculate population-level SE statistics
            se_columns = [col for col in best_se_df.columns if col.startswith('se_')]
            numeric_se_cols = []
            
            for col in se_columns:
                if best_se_df[col].dtype in ['int64', 'float64']:
                    numeric_se_cols.append(col)
            
            # Add population-level SE features to each health record
            for col in numeric_se_cols:
                if col in se_sample.columns:
                    # Add population statistics
                    integrated_df[f'{col}_pop_mean'] = se_sample[col].mean()
                    integrated_df[f'{col}_pop_std'] = se_sample[col].std()
                    integrated_df[f'{col}_pop_median'] = se_sample[col].median()
                    
                    # Add individual random assignment from population (for diversity)
                    if len(integrated_df) <= len(se_sample):
                        # Direct assignment
                        sampled_values = se_sample[col].sample(len(integrated_df), replace=True, random_state=42).values
                        integrated_df[f'{col}_assigned'] = sampled_values
                    else:
                        # Bootstrap sampling
                        np.random.seed(42)
                        sampled_values = np.random.choice(se_sample[col].dropna().values, len(integrated_df), replace=True)
                        integrated_df[f'{col}_assigned'] = sampled_values
            
            # Add SE contextual variables
            integrated_df['se_data_year'] = best_year
            integrated_df['se_population_size'] = len(best_se_df)
            integrated_df['se_variables_available'] = len(numeric_se_cols)
            
            self.logger.info(f"   📊 Added {len(numeric_se_cols)} SE variable sets (mean/std/median/assigned)")
        
        else:
            self.logger.warning(f"   No matching SE datasets found for date range {min_year}-{max_year}")
        
        return integrated_df
    
    def save_integrated_datasets(self, integrated_datasets: Dict[str, pd.DataFrame]) -> None:
        """
        Save all integrated datasets.
        """
        self.logger.info("\\n" + "=" * 60)
        self.logger.info("💾 SAVING INTEGRATED DATASETS")
        self.logger.info("=" * 60)
        
        for dataset_name, df in integrated_datasets.items():
            output_file = self.output_path / f"se_integrated_{dataset_name}.csv"
            df.to_csv(output_file, index=False)
            
            se_cols = [col for col in df.columns if col.startswith('se_')]
            self.logger.info(f"✅ {dataset_name}: {len(df)} records, {len(se_cols)} SE variables")
            self.logger.info(f"   Saved to: {output_file}")
        
        # Create summary report
        summary_lines = []
        summary_lines.append("# Socio-Economic Integrated Datasets Summary\\n")
        summary_lines.append("| Dataset | Records | Total Variables | SE Variables | SE Data Year |")
        summary_lines.append("|---------|---------|-----------------|--------------|--------------|")
        
        for dataset_name, df in integrated_datasets.items():
            se_cols = len([col for col in df.columns if col.startswith('se_')])
            se_year = df['se_data_year'].iloc[0] if 'se_data_year' in df.columns else 'Unknown'
            summary_lines.append(f"| {dataset_name} | {len(df)} | {len(df.columns)} | {se_cols} | {se_year} |")
        
        summary_lines.append("\\n## Integration Method")
        summary_lines.append("- **Temporal Matching**: SE data matched by closest survey year to health data collection")
        summary_lines.append("- **Population Statistics**: SE population means, medians, and standard deviations added")
        summary_lines.append("- **Individual Assignment**: Random sampling from SE population for individual-level variation")
        summary_lines.append("- **Composite Indices**: SES composite, vulnerability index, and domain-specific indices")
        
        summary_file = self.output_path / "SE_INTEGRATION_SUMMARY.md"
        with open(summary_file, 'w') as f:
            f.write('\\n'.join(summary_lines))
        
        self.logger.info(f"📋 Summary saved: {summary_file}")
    
    def run_complete_integration(self) -> Dict[str, pd.DataFrame]:
        """
        Run complete socio-economic data integration pipeline.
        """
        self.logger.info("🏠 SOCIO-ECONOMIC DATA INTEGRATION PIPELINE")
        self.logger.info("=" * 80)
        self.logger.info("Integrating GCRO Quality of Life data with heat-health datasets")
        self.logger.info("=" * 80)
        
        # Step 1: Discover GCRO datasets
        gcro_datasets_info = self.discover_gcro_datasets()
        
        if not gcro_datasets_info:
            self.logger.error("No GCRO datasets found!")
            return {}
        
        # Step 2: Extract socio-economic features
        se_datasets = {}
        
        for year, dataset_info in gcro_datasets_info.items():
            if dataset_info.get('data_file'):
                se_df = self.extract_socioeconomic_features(dataset_info)
                if not se_df.empty:
                    se_datasets[year] = se_df
        
        if not se_datasets:
            self.logger.error("No SE features extracted!")
            return {}
        
        self.logger.info(f"\\n✅ Extracted SE features from {len(se_datasets)} datasets")
        
        # Step 3: Integrate with XAI datasets
        integrated_datasets = self.integrate_with_xai_datasets(se_datasets)
        
        # Step 4: Save integrated datasets
        if integrated_datasets:
            self.save_integrated_datasets(integrated_datasets)
        
        # Final summary
        total_se_variables = 0
        max_participants = 0
        
        for dataset_name, df in integrated_datasets.items():
            se_vars = len([col for col in df.columns if col.startswith('se_')])
            total_se_variables = max(total_se_variables, se_vars)
            max_participants = max(max_participants, len(df))
        
        self.logger.info("\\n" + "=" * 80)
        self.logger.info("🎉 SOCIO-ECONOMIC INTEGRATION COMPLETE!")
        self.logger.info("=" * 80)
        self.logger.info(f"📊 Integrated datasets: {len(integrated_datasets)}")
        self.logger.info(f"🏠 SE variables added: {total_se_variables}")
        self.logger.info(f"👥 Maximum participants: {max_participants}")
        self.logger.info(f"💾 Output directory: {self.output_path}")
        self.logger.info("🎯 Ready for enhanced heat-health XAI analysis with social determinants!")
        
        return integrated_datasets


def main():
    """Main execution function."""
    print("🏠 SOCIO-ECONOMIC DATA INTEGRATION")
    print("=" * 80)
    print("Integrating GCRO Quality of Life data with heat-health datasets")
    print("Adding social determinants of heat vulnerability")
    print("=" * 80)
    
    integrator = SocioEconomicIntegrator()
    
    # Run complete integration
    results = integrator.run_complete_integration()
    
    total_datasets = len(results)
    max_se_vars = max(len([col for col in df.columns if col.startswith('se_')]) for df in results.values()) if results else 0
    
    print(f"\\n🎉 INTEGRATION COMPLETE!")
    print(f"📊 Enhanced {total_datasets} datasets with socio-economic data")
    print(f"🏠 Maximum SE variables added: {max_se_vars}")
    print(f"💾 Results saved to: heat_analysis_optimized/data/socioeconomic_integrated/")
    print("🎯 Ready for comprehensive heat-health-SE XAI analysis!")
    
    return results


if __name__ == "__main__":
    main()