"""
Comprehensive Dataset Explorer for DPHRU_013 and VIDA_008

Thoroughly explores these specific datasets to ensure we extract all relevant data,
even if sparse. Examines both raw Excel and CSV formats.
"""

import pandas as pd
import numpy as np
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any
import logging
from datetime import datetime
import warnings

warnings.filterwarnings('ignore')

class ComprehensiveDatasetExplorer:
    """
    Comprehensive exploration of DPHRU_013 and VIDA_008 datasets.
    """
    
    def __init__(self, base_path: str = "/home/cparker"):
        self.base_path = Path(base_path)
        self.raw_path = self.base_path / "incoming" / "RP2"
        self.output_path = self.base_path / "heat_analysis_optimized" / "data" / "comprehensive_extracted"
        
        # Create output directory
        self.output_path.mkdir(parents=True, exist_ok=True)
        
        # Setup logging
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)
    
    def explore_dphru_013_comprehensive(self) -> Dict[str, Any]:
        """
        Comprehensive exploration of JHB_DPHRU_013 - Heat Dataset.
        """
        self.logger.info("=" * 80)
        self.logger.info("🔍 COMPREHENSIVE EXPLORATION: JHB_DPHRU_013")
        self.logger.info("=" * 80)
        self.logger.info("🌡️ HEAT EXPOSURE DATASET - This could be highly relevant!")
        
        dataset_path = self.raw_path / "JHB_DPHRU_013"
        
        analysis = {
            'name': 'JHB_DPHRU_013',
            'files_found': [],
            'excel_sheets': {},
            'total_records': 0,
            'variables': [],
            'heat_related_vars': [],
            'biomarker_vars': [],
            'data_sample': {},
            'extraction_success': False
        }
        
        # Check raw directory
        raw_path = dataset_path / "raw"
        if raw_path.exists():
            excel_files = list(raw_path.glob("*.xlsx"))
            self.logger.info(f"Found {len(excel_files)} Excel files:")
            
            for excel_file in excel_files:
                self.logger.info(f"  📊 {excel_file.name}")
                analysis['files_found'].append(excel_file.name)
                
                try:
                    # Read Excel file and examine all sheets
                    excel_data = pd.ExcelFile(excel_file)
                    self.logger.info(f"     Sheets: {excel_data.sheet_names}")
                    
                    for sheet_name in excel_data.sheet_names:
                        self.logger.info(f"\\n     📋 SHEET: {sheet_name}")
                        
                        try:
                            df = pd.read_excel(excel_file, sheet_name=sheet_name)
                            self.logger.info(f"        Records: {len(df)}")
                            self.logger.info(f"        Variables: {len(df.columns)}")
                            
                            # Store sheet info
                            analysis['excel_sheets'][sheet_name] = {
                                'records': len(df),
                                'variables': len(df.columns),
                                'columns': list(df.columns)
                            }
                            
                            # Look for heat-related variables
                            heat_vars = [col for col in df.columns if any(x in col.lower() for x in 
                                       ['temp', 'heat', 'thermal', 'climate', 'weather', 'wbgt', 'utci'])]
                            if heat_vars:
                                self.logger.info(f"        🌡️ Heat variables: {len(heat_vars)}")
                                for var in heat_vars[:5]:  # Show first 5
                                    self.logger.info(f"           - {var}")
                                analysis['heat_related_vars'].extend(heat_vars)
                            
                            # Look for biomarkers
                            biomarker_vars = [col for col in df.columns if any(x in col.lower() for x in 
                                            ['glucose', 'cholesterol', 'bp', 'blood_pressure', 'weight', 'height', 'bmi'])]
                            if biomarker_vars:
                                self.logger.info(f"        🔬 Biomarker variables: {len(biomarker_vars)}")
                                for var in biomarker_vars[:5]:
                                    self.logger.info(f"           - {var}")
                                analysis['biomarker_vars'].extend(biomarker_vars)
                            
                            # Sample data
                            if len(df) > 0:
                                analysis['data_sample'][sheet_name] = df.head(3).to_dict()
                                analysis['total_records'] += len(df)
                            
                            # Show column preview
                            if len(df.columns) > 0:
                                self.logger.info(f"        Sample columns: {list(df.columns[:10])}")
                            
                        except Exception as e:
                            self.logger.error(f"        Error reading sheet {sheet_name}: {e}")
                    
                except Exception as e:
                    self.logger.error(f"     Error reading Excel file: {e}")
        
        # Check study docs
        docs_path = dataset_path / "study_docs"
        if docs_path.exists():
            doc_files = list(docs_path.glob("*"))
            self.logger.info(f"\\nStudy documentation files: {len(doc_files)}")
            for doc_file in doc_files:
                self.logger.info(f"  📄 {doc_file.name}")
                
                # Try to read codebook if Excel
                if doc_file.suffix.lower() == '.xlsx' and 'codebook' in doc_file.name.lower():
                    try:
                        codebook = pd.read_excel(doc_file)
                        self.logger.info(f"     Codebook entries: {len(codebook)}")
                        if len(codebook.columns) > 0:
                            self.logger.info(f"     Codebook columns: {list(codebook.columns[:5])}")
                    except Exception as e:
                        self.logger.error(f"     Error reading codebook: {e}")
        
        analysis['variables'] = list(set(analysis['heat_related_vars'] + analysis['biomarker_vars']))
        
        self.logger.info(f"\\n📊 DPHRU_013 SUMMARY:")
        self.logger.info(f"   Total records across sheets: {analysis['total_records']}")
        self.logger.info(f"   Heat-related variables: {len(analysis['heat_related_vars'])}")
        self.logger.info(f"   Biomarker variables: {len(analysis['biomarker_vars'])}")
        self.logger.info(f"   Total unique variables: {len(analysis['variables'])}")
        
        return analysis
    
    def explore_vida_008_comprehensive(self) -> Dict[str, Any]:
        """
        Comprehensive exploration of JHB_VIDA_008 - COVID Healthcare Worker Study.
        """
        self.logger.info("\\n" + "=" * 80)
        self.logger.info("🔍 COMPREHENSIVE EXPLORATION: JHB_VIDA_008")
        self.logger.info("=" * 80)
        self.logger.info("💉 COVID HEALTHCARE WORKER STUDY - Re-examining for completeness")
        
        dataset_path = self.raw_path / "JHB_VIDA_008"
        
        analysis = {
            'name': 'JHB_VIDA_008',
            'csv_files': [],
            'raw_excel_files': [],
            'total_records': 0,
            'variables': [],
            'covid_vars': [],
            'biomarker_vars': [],
            'data_sample': {},
            'metadata_info': {},
            'extraction_success': False
        }
        
        # Examine CSV files
        csv_path = dataset_path / "csv"
        if csv_path.exists():
            csv_files = list(csv_path.glob("*.csv"))
            self.logger.info(f"CSV files: {len(csv_files)}")
            
            for csv_file in csv_files:
                self.logger.info(f"\\n📄 CSV: {csv_file.name}")
                
                try:
                    df = pd.read_csv(csv_file)
                    self.logger.info(f"   Records: {len(df)}")
                    self.logger.info(f"   Variables: {len(df.columns)}")
                    
                    analysis['csv_files'].append({
                        'name': csv_file.name,
                        'records': len(df),
                        'variables': len(df.columns),
                        'columns': list(df.columns)
                    })
                    
                    # Look for COVID-specific variables
                    covid_vars = [col for col in df.columns if any(x in col.lower() for x in 
                                ['covid', 'vaccine', 'dose', 'adverse', 'symptom', 'pfizer', 'moderna', 'johnson'])]
                    if covid_vars:
                        self.logger.info(f"   💉 COVID variables: {len(covid_vars)}")
                        for var in covid_vars[:5]:
                            self.logger.info(f"      - {var}")
                        analysis['covid_vars'].extend(covid_vars)
                    
                    # Look for biomarkers
                    biomarker_vars = [col for col in df.columns if any(x in col.lower() for x in 
                                    ['glucose', 'cholesterol', 'bp', 'blood_pressure', 'weight', 'height', 'bmi', 
                                     'heart_rate', 'temperature', 'oxygen'])]
                    if biomarker_vars:
                        self.logger.info(f"   🔬 Biomarker variables: {len(biomarker_vars)}")
                        for var in biomarker_vars[:5]:
                            self.logger.info(f"      - {var}")
                        analysis['biomarker_vars'].extend(biomarker_vars)
                    
                    analysis['total_records'] += len(df)
                    
                    # Sample data with non-null values
                    if len(df) > 0:
                        # Find rows with most non-null values
                        non_null_counts = df.notna().sum(axis=1)
                        best_rows = non_null_counts.nlargest(3).index
                        analysis['data_sample'][csv_file.name] = df.loc[best_rows].to_dict()
                    
                except Exception as e:
                    self.logger.error(f"   Error reading CSV: {e}")
        
        # Examine raw Excel files
        raw_path = dataset_path / "raw"
        if raw_path.exists():
            excel_files = list(raw_path.glob("*.xlsx"))
            self.logger.info(f"\\nRaw Excel files: {len(excel_files)}")
            
            for excel_file in excel_files:
                self.logger.info(f"\\n📊 Excel: {excel_file.name}")
                
                try:
                    excel_data = pd.ExcelFile(excel_file)
                    self.logger.info(f"   Sheets: {excel_data.sheet_names}")
                    
                    for sheet_name in excel_data.sheet_names:
                        try:
                            df = pd.read_excel(excel_file, sheet_name=sheet_name)
                            self.logger.info(f"   📋 Sheet '{sheet_name}': {len(df)} records, {len(df.columns)} vars")
                            
                            analysis['raw_excel_files'].append({
                                'file': excel_file.name,
                                'sheet': sheet_name,
                                'records': len(df),
                                'variables': len(df.columns)
                            })
                            
                        except Exception as e:
                            self.logger.error(f"   Error reading sheet {sheet_name}: {e}")
                    
                except Exception as e:
                    self.logger.error(f"   Error reading Excel file: {e}")
        
        # Check metadata
        metadata_path = dataset_path / "metadata"
        if metadata_path.exists():
            metadata_files = list(metadata_path.glob("*"))
            self.logger.info(f"\\nMetadata files: {len(metadata_files)}")
            
            for meta_file in metadata_files:
                self.logger.info(f"📋 {meta_file.name}")
                
                if meta_file.suffix.lower() == '.csv':
                    try:
                        meta_df = pd.read_csv(meta_file)
                        self.logger.info(f"   Metadata entries: {len(meta_df)}")
                        analysis['metadata_info'][meta_file.name] = {
                            'records': len(meta_df),
                            'columns': list(meta_df.columns) if len(meta_df.columns) > 0 else []
                        }
                    except Exception as e:
                        self.logger.error(f"   Error reading metadata: {e}")
        
        analysis['variables'] = list(set(analysis['covid_vars'] + analysis['biomarker_vars']))
        
        self.logger.info(f"\\n📊 VIDA_008 SUMMARY:")
        self.logger.info(f"   Total records across files: {analysis['total_records']}")
        self.logger.info(f"   COVID-related variables: {len(analysis['covid_vars'])}")
        self.logger.info(f"   Biomarker variables: {len(analysis['biomarker_vars'])}")
        self.logger.info(f"   Total unique variables: {len(analysis['variables'])}")
        
        return analysis
    
    def extract_dphru_013_properly(self, analysis: Dict[str, Any]) -> pd.DataFrame:
        """
        Properly extract DPHRU_013 data based on exploration results.
        """
        self.logger.info("\\n" + "=" * 60)
        self.logger.info("📥 EXTRACTING DPHRU_013 DATA")
        self.logger.info("=" * 60)
        
        dataset_path = self.raw_path / "JHB_DPHRU_013" / "raw"
        excel_files = list(dataset_path.glob("*.xlsx"))
        
        if not excel_files:
            self.logger.warning("No Excel files found for extraction")
            return pd.DataFrame()
        
        excel_file = excel_files[0]  # Take the main data file
        
        all_data = []
        
        try:
            excel_data = pd.ExcelFile(excel_file)
            
            for sheet_name in excel_data.sheet_names:
                self.logger.info(f"Extracting sheet: {sheet_name}")
                
                try:
                    df = pd.read_excel(excel_file, sheet_name=sheet_name)
                    
                    if len(df) > 0:
                        # Add sheet identifier
                        df['source_sheet'] = sheet_name
                        df['dataset_name'] = 'jhb_dphru_013'
                        
                        # Create participant IDs if not present
                        if 'participant_id' not in df.columns:
                            id_cols = [col for col in df.columns if 'id' in col.lower()]
                            if id_cols:
                                df['participant_id'] = 'dphru_013_' + df[id_cols[0]].astype(str)
                            else:
                                df['participant_id'] = [f"dphru_013_{sheet_name}_{i:04d}" for i in range(len(df))]
                        
                        all_data.append(df)
                        self.logger.info(f"   Extracted {len(df)} records from {sheet_name}")
                    
                except Exception as e:
                    self.logger.error(f"   Error extracting sheet {sheet_name}: {e}")
            
            if all_data:
                # Combine all sheets
                combined = pd.concat(all_data, ignore_index=True, sort=False)
                
                # Save extracted data
                output_file = self.output_path / "comprehensive_dphru_013.csv"
                combined.to_csv(output_file, index=False)
                
                self.logger.info(f"\\n✅ DPHRU_013 extraction complete:")
                self.logger.info(f"   Total records: {len(combined)}")
                self.logger.info(f"   Total variables: {len(combined.columns)}")
                self.logger.info(f"   Output: {output_file}")
                
                return combined
            
        except Exception as e:
            self.logger.error(f"Error during DPHRU_013 extraction: {e}")
        
        return pd.DataFrame()
    
    def extract_vida_008_properly(self, analysis: Dict[str, Any]) -> pd.DataFrame:
        """
        Properly extract VIDA_008 data based on exploration results.
        """
        self.logger.info("\\n" + "=" * 60)
        self.logger.info("📥 EXTRACTING VIDA_008 DATA")
        self.logger.info("=" * 60)
        
        dataset_path = self.raw_path / "JHB_VIDA_008"
        
        all_data = []
        
        # Extract from CSV files first (these are likely cleaned)
        csv_path = dataset_path / "csv"
        if csv_path.exists():
            csv_files = list(csv_path.glob("*.csv"))
            
            for csv_file in csv_files:
                self.logger.info(f"Extracting CSV: {csv_file.name}")
                
                try:
                    df = pd.read_csv(csv_file)
                    
                    if len(df) > 0:
                        # Add file identifier
                        df['source_file'] = csv_file.name
                        df['dataset_name'] = 'jhb_vida_008'
                        
                        # Create participant IDs if not present
                        if 'participant_id' not in df.columns:
                            id_cols = [col for col in df.columns if 'id' in col.lower() and 'record' in col.lower()]
                            if not id_cols:
                                id_cols = [col for col in df.columns if 'id' in col.lower()]
                            
                            if id_cols:
                                df['participant_id'] = 'vida_008_' + df[id_cols[0]].astype(str)
                            else:
                                df['participant_id'] = [f"vida_008_{csv_file.stem}_{i:04d}" for i in range(len(df))]
                        
                        all_data.append(df)
                        self.logger.info(f"   Extracted {len(df)} records from {csv_file.name}")
                    
                except Exception as e:
                    self.logger.error(f"   Error extracting {csv_file.name}: {e}")
        
        if all_data:
            # Combine all files
            combined = pd.concat(all_data, ignore_index=True, sort=False)
            
            # Remove duplicates based on participant_id if possible
            before = len(combined)
            if 'participant_id' in combined.columns:
                combined = combined.drop_duplicates(subset=['participant_id'], keep='first')
            after = len(combined)
            
            if before != after:
                self.logger.info(f"Removed {before - after} duplicate records")
            
            # Save extracted data
            output_file = self.output_path / "comprehensive_vida_008.csv"
            combined.to_csv(output_file, index=False)
            
            self.logger.info(f"\\n✅ VIDA_008 extraction complete:")
            self.logger.info(f"   Total records: {len(combined)}")
            self.logger.info(f"   Total variables: {len(combined.columns)}")
            self.logger.info(f"   Output: {output_file}")
            
            return combined
        
        return pd.DataFrame()
    
    def run_comprehensive_exploration(self) -> Dict[str, Any]:
        """
        Run comprehensive exploration of both datasets.
        """
        self.logger.info("🔍 COMPREHENSIVE DATASET EXPLORATION")
        self.logger.info("=" * 80)
        self.logger.info("Thoroughly exploring DPHRU_013 and VIDA_008 for all relevant data")
        self.logger.info("=" * 80)
        
        results = {}
        
        # Explore DPHRU_013
        try:
            dphru_analysis = self.explore_dphru_013_comprehensive()
            results['dphru_013_analysis'] = dphru_analysis
            
            # Extract data
            dphru_data = self.extract_dphru_013_properly(dphru_analysis)
            if not dphru_data.empty:
                results['dphru_013_data'] = dphru_data
                
        except Exception as e:
            self.logger.error(f"Error exploring DPHRU_013: {e}")
        
        # Explore VIDA_008
        try:
            vida_analysis = self.explore_vida_008_comprehensive()
            results['vida_008_analysis'] = vida_analysis
            
            # Extract data
            vida_data = self.extract_vida_008_properly(vida_analysis)
            if not vida_data.empty:
                results['vida_008_data'] = vida_data
                
        except Exception as e:
            self.logger.error(f"Error exploring VIDA_008: {e}")
        
        # Summary
        self.logger.info("\\n" + "=" * 80)
        self.logger.info("📊 COMPREHENSIVE EXPLORATION SUMMARY")
        self.logger.info("=" * 80)
        
        for dataset_name, data in results.items():
            if isinstance(data, pd.DataFrame):
                self.logger.info(f"\\n✅ {dataset_name.upper()}:")
                self.logger.info(f"   Records: {len(data)}")
                self.logger.info(f"   Variables: {len(data.columns)}")
                
                # Show sample of interesting variables
                interesting_vars = [col for col in data.columns if any(x in col.lower() for x in 
                                  ['temp', 'heat', 'covid', 'vaccine', 'glucose', 'bp', 'weight'])]
                if interesting_vars:
                    self.logger.info(f"   Key variables found: {len(interesting_vars)}")
                    for var in interesting_vars[:5]:
                        self.logger.info(f"      - {var}")
        
        return results


def main():
    """Main execution function."""
    print("🔍 COMPREHENSIVE DATASET EXPLORATION")
    print("=" * 80)
    print("Thoroughly exploring JHB_DPHRU_013 and JHB_VIDA_008")
    print("Ensuring we extract all relevant data, even if sparse")
    print("=" * 80)
    
    explorer = ComprehensiveDatasetExplorer()
    
    # Run comprehensive exploration
    results = explorer.run_comprehensive_exploration()
    
    print(f"\\n✅ Comprehensive exploration complete!")
    print(f"📊 Results saved to: heat_analysis_optimized/data/comprehensive_extracted/")
    
    return results


if __name__ == "__main__":
    main()