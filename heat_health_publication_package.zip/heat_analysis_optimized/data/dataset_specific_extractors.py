"""
Dataset-Specific Enhanced Extraction System

Builds comprehensive datasets one at a time with proper variable mapping.
Each dataset extractor is tailored to its specific structure and biomarker availability.
"""

import pandas as pd
import numpy as np
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any
import logging
from datetime import datetime
import warnings

warnings.filterwarnings('ignore')

class DatasetSpecificExtractor:
    """
    Master class for dataset-specific extraction with proper variable mapping.
    
    Processes each RP2 dataset individually:
    1. DPHRU053 - MASC study with body composition
    2. WRHI001 - Clinical trial with longitudinal labs  
    3. ACTG studies - Harmonized HIV cohorts
    4. Additional datasets as discovered
    """
    
    def __init__(self, base_path: str = "/home/cparker"):
        self.base_path = Path(base_path)
        self.raw_path = self.base_path / "incoming" / "RP2"
        self.processed_path = self.base_path / "Min_repo_heat_analysis" / "data" / "climate_linked"
        self.output_path = self.base_path / "heat_analysis_optimized" / "data" / "enhanced_individual"
        
        # Create output directory
        self.output_path.mkdir(parents=True, exist_ok=True)
        
        # Setup logging
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)
        
    def extract_enhanced_dphru053_corrected(self) -> pd.DataFrame:
        """
        Extract DPHRU053 with CORRECT variable mapping based on actual CSV structure.
        
        Key features:
        - Body composition (DEXA-like measurements)
        - Metabolic panel with glucose, cholesterol, triglycerides
        - Blood pressure measurements
        - Lifestyle factors (sleep, alcohol, diet)
        - Anthropometric measurements
        """
        self.logger.info("=" * 60)
        self.logger.info("DATASET 1: Enhanced DPHRU053 Extraction (Corrected)")
        self.logger.info("=" * 60)
        
        # Load raw data
        raw_file = self.raw_path / "JHB_DPHRU_053" / "csv" / "JHB_DPHRU_053_MASC_DATA_2023-12-06 TO SHARE.csv"
        
        if not raw_file.exists():
            self.logger.error(f"Raw file not found: {raw_file}")
            return pd.DataFrame()
        
        self.logger.info(f"Loading DPHRU053 raw data...")
        df = pd.read_csv(raw_file)
        self.logger.info(f"✅ Loaded: {len(df)} participants, {len(df.columns)} variables")
        
        # Create standardized dataset with proper variable mapping
        enhanced_data = {}
        
        # 1. IDENTIFIERS AND DEMOGRAPHICS
        demographic_mapping = {
            'gsk_id': 'participant_id',
            'gsk_date': 'visit_date',
            'age': 'demographic_age',
            'gender': 'demographic_sex',
            'marital_status': 'demographic_marital_status',
            'currently_employed': 'demographic_employed'
        }
        
        # 2. METABOLIC PATHWAY - Correct variable names
        metabolic_mapping = {
            'glucose_0': 'metabolic_glucose',
            'total_cholesterol': 'metabolic_total_cholesterol',
            'triglycerides': 'metabolic_triglycerides',
            'lab_calculated_ldl': 'metabolic_ldl_cholesterol',
            # Note: HDL not directly available, but can calculate from total, LDL, triglycerides
        }
        
        # 3. CARDIOVASCULAR PATHWAY
        cardiovascular_mapping = {
            'systolic_bp_average': 'cardiovascular_systolic_bp',
            'diastolic_bp_average': 'cardiovascular_diastolic_bp',
            'high_blood_pressure': 'cardiovascular_hypertension_history',
            'hbp_med': 'cardiovascular_bp_medication',
            'family_high_blood_pressure': 'cardiovascular_family_history'
        }
        
        # 4. ANTHROPOMETRIC MEASUREMENTS
        anthropometric_mapping = {
            'height': 'anthropometric_height',
            'weight': 'anthropometric_weight', 
            'bmi': 'anthropometric_bmi',
            'waist_circumference_average': 'anthropometric_waist',
            'hip_circumference_average': 'anthropometric_hip'
        }
        
        # 5. BODY COMPOSITION - DEXA-like measurements (UNIQUE TO DPHRU053!)
        body_composition_mapping = {
            'fat_mass_index': 'body_composition_fat_mass_index',
            'total_lean': 'body_composition_lean_mass',
            'android_pfat': 'body_composition_android_fat_pct',
            'trunk_pfat': 'body_composition_trunk_fat_pct',
            'arm_fat': 'body_composition_arm_fat',
            'arm_pfat': 'body_composition_arm_fat_pct',
            'leg_fat': 'body_composition_leg_fat',
            'leg_pfat': 'body_composition_leg_fat_pct',
            'peripheral_fat': 'body_composition_peripheral_fat',
            'peripheral_fat_asm_ratio': 'body_composition_peripheral_asm_ratio'
        }
        
        # 6. LIFESTYLE FACTORS
        lifestyle_mapping = {
            'hours_actual_sleep': 'lifestyle_sleep_hours',
            'sleep_mins_consolidated': 'lifestyle_sleep_minutes',
            'sleep_disturbances': 'lifestyle_sleep_disturbances',
            'drink_alcohol': 'lifestyle_alcohol_use',
            'drink_alcohol_weekday': 'lifestyle_alcohol_weekday',
            'drink_alcohol_weekend_day': 'lifestyle_alcohol_weekend',
            'currently_smoke_tobacco_products': 'lifestyle_smoking',
            'currently_smoke_tobacco_products_daily': 'lifestyle_smoking_daily'
        }
        
        # 7. DIETARY FACTORS
        dietary_mapping = {
            'totalfatg': 'dietary_total_fat_g',
            'totaldietaryfibreg': 'dietary_fiber_g',
            'monounsaturatedfag': 'dietary_monounsaturated_fat_g'
        }
        
        # Apply all mappings
        all_mappings = [
            demographic_mapping, metabolic_mapping, cardiovascular_mapping,
            anthropometric_mapping, body_composition_mapping, lifestyle_mapping,
            dietary_mapping
        ]
        
        extraction_summary = {}
        
        for mapping_idx, mapping in enumerate(all_mappings):
            pathway_names = ['demographic', 'metabolic', 'cardiovascular', 'anthropometric', 
                           'body_composition', 'lifestyle', 'dietary']
            pathway = pathway_names[mapping_idx]
            
            found = 0
            missing = []
            
            for raw_col, std_col in mapping.items():
                if raw_col in df.columns:
                    enhanced_data[std_col] = df[raw_col].copy()
                    found += 1
                else:
                    missing.append(raw_col)
                    enhanced_data[std_col] = np.nan
            
            extraction_summary[pathway] = {
                'found': found,
                'total': len(mapping),
                'completeness': f"{found/len(mapping)*100:.1f}%",
                'missing': missing
            }
        
        # Create enhanced DataFrame
        enhanced_df = pd.DataFrame(enhanced_data)
        
        # Add calculated features
        enhanced_df = self._add_dphru053_calculated_features(enhanced_df)
        
        # Data quality processing
        enhanced_df = self._apply_dphru053_quality_controls(enhanced_df)
        
        # Save enhanced dataset
        output_file = self.output_path / "enhanced_dphru053_corrected.csv"
        enhanced_df.to_csv(output_file, index=False)
        
        # Report extraction summary
        self.logger.info("\n📊 DPHRU053 Extraction Summary:")
        for pathway, stats in extraction_summary.items():
            self.logger.info(f"  {pathway.upper()}: {stats['found']}/{stats['total']} variables ({stats['completeness']})")
            if stats['missing']:
                self.logger.warning(f"    Missing: {', '.join(stats['missing'])}")
        
        self.logger.info(f"\n✅ Enhanced DPHRU053 saved: {output_file}")
        self.logger.info(f"   Participants: {len(enhanced_df)}")
        self.logger.info(f"   Variables: {len(enhanced_df.columns)}")
        
        # Key unique features
        self.logger.info("\n🌟 Unique DPHRU053 Features:")
        self.logger.info("   - Body composition (DEXA-like): 10 variables")
        self.logger.info("   - Lifestyle factors: 8 variables")
        self.logger.info("   - Dietary assessment: 3 variables")
        
        return enhanced_df
    
    def extract_enhanced_wrhi001(self) -> Dict[str, pd.DataFrame]:
        """
        Extract WRHI001 clinical trial data with multi-table structure.
        
        Key features:
        - Longitudinal design (multiple visits)
        - Comprehensive lab panels
        - HIV-specific biomarkers
        - Treatment arm information
        """
        self.logger.info("\n" + "=" * 60)
        self.logger.info("DATASET 2: Enhanced WRHI001 Extraction")
        self.logger.info("=" * 60)
        
        wrhi_path = self.raw_path / "JHB_WRHI_001" / "csv"
        
        # Check for all expected tables
        table_files = {
            'subjects': 'JHB_WRHI_001_ADSL.csv',     # Subject demographics
            'laboratory': 'JHB_WRHI_001_ADLB.csv',   # Lab results
            'vitals': 'JHB_WRHI_001_ADVS.csv',       # Vital signs
            'adverse_events': 'JHB_WRHI_001_ADAE.csv' # Safety data
        }
        
        extracted_tables = {}
        
        for table_name, filename in table_files.items():
            file_path = wrhi_path / filename
            if file_path.exists():
                self.logger.info(f"Loading {table_name} table...")
                df = pd.read_csv(file_path)
                self.logger.info(f"✅ {table_name}: {len(df)} records, {len(df.columns)} columns")
                extracted_tables[table_name] = df
            else:
                self.logger.warning(f"❌ {table_name} table not found: {filename}")
        
        # Process laboratory data to extract biomarkers
        if 'laboratory' in extracted_tables:
            self.logger.info("\n🔬 Processing laboratory biomarkers...")
            lab_wide = self._process_wrhi001_laboratory(extracted_tables['laboratory'])
            extracted_tables['biomarkers_wide'] = lab_wide
            
            # Save wide format biomarkers
            output_file = self.output_path / "enhanced_wrhi001_biomarkers.csv"
            lab_wide.to_csv(output_file, index=False)
            self.logger.info(f"✅ Biomarkers saved: {output_file}")
        
        # Process vital signs
        if 'vitals' in extracted_tables:
            self.logger.info("\n💓 Processing vital signs...")
            vitals_wide = self._process_wrhi001_vitals(extracted_tables['vitals'])
            extracted_tables['vitals_wide'] = vitals_wide
            
            # Save vital signs
            output_file = self.output_path / "enhanced_wrhi001_vitals.csv"
            vitals_wide.to_csv(output_file, index=False)
            self.logger.info(f"✅ Vitals saved: {output_file}")
        
        # Create integrated dataset if possible
        if 'subjects' in extracted_tables and 'biomarkers_wide' in extracted_tables:
            self.logger.info("\n🔗 Creating integrated WRHI001 dataset...")
            integrated = self._integrate_wrhi001_tables(extracted_tables)
            
            output_file = self.output_path / "enhanced_wrhi001_integrated.csv"
            integrated.to_csv(output_file, index=False)
            self.logger.info(f"✅ Integrated dataset saved: {output_file}")
            
            # Summary statistics
            self.logger.info("\n📊 WRHI001 Summary:")
            self.logger.info(f"   Unique participants: {integrated['participant_id'].nunique()}")
            self.logger.info(f"   Total records: {len(integrated)}")
            self.logger.info(f"   Variables: {len(integrated.columns)}")
            self.logger.info(f"   Visit structure: Longitudinal with multiple timepoints")
        
        self.logger.info("\n🌟 Unique WRHI001 Features:")
        self.logger.info("   - Longitudinal design with 4-8 visits per participant")
        self.logger.info("   - Comprehensive chemistry and hematology panels")
        self.logger.info("   - HIV-specific biomarkers (CD4, viral load)")
        self.logger.info("   - Treatment arm stratification")
        
        return extracted_tables
    
    def extract_actg_studies(self) -> pd.DataFrame:
        """
        Extract and harmonize ACTG HIV studies (015, 016, 017).
        
        Key features:
        - Standardized biomarker panels
        - Cross-study harmonization
        - HIV-specific endpoints
        """
        self.logger.info("\n" + "=" * 60)
        self.logger.info("DATASET 3: ACTG Studies Harmonization")
        self.logger.info("=" * 60)
        
        actg_studies = ['JHB_ACTG_015', 'JHB_ACTG_016', 'JHB_ACTG_017']
        all_actg_data = []
        
        for study_id in actg_studies:
            self.logger.info(f"\n📁 Processing {study_id}...")
            study_path = self.raw_path / study_id / "csv"
            
            if not study_path.exists():
                self.logger.warning(f"Study path not found: {study_path}")
                continue
            
            # Look for CSV files
            csv_files = list(study_path.glob("*.csv"))
            
            if not csv_files:
                self.logger.warning(f"No CSV files found in {study_path}")
                continue
            
            # Process each CSV file
            for csv_file in csv_files:
                self.logger.info(f"  Loading: {csv_file.name}")
                df = pd.read_csv(csv_file)
                
                # Add study identifier
                df['study_id'] = study_id
                df['source_file'] = csv_file.name
                
                self.logger.info(f"  ✅ Loaded: {len(df)} records, {len(df.columns)} columns")
                
                # Standardize if it looks like subject-level data
                if len(df) < 1000 and len(df) > 10:  # Likely subject-level
                    standardized = self._standardize_actg_data(df, study_id)
                    all_actg_data.append(standardized)
        
        # Harmonize across studies
        if all_actg_data:
            self.logger.info("\n🔄 Harmonizing ACTG studies...")
            harmonized = pd.concat(all_actg_data, ignore_index=True)
            
            # Remove duplicates if any
            before = len(harmonized)
            harmonized = harmonized.drop_duplicates(subset=['participant_id', 'study_id'])
            after = len(harmonized)
            
            if before != after:
                self.logger.info(f"Removed {before - after} duplicate records")
            
            # Save harmonized dataset
            output_file = self.output_path / "enhanced_actg_harmonized.csv"
            harmonized.to_csv(output_file, index=False)
            
            self.logger.info(f"\n✅ ACTG harmonized dataset saved: {output_file}")
            self.logger.info(f"   Total participants: {len(harmonized)}")
            self.logger.info(f"   Studies included: {harmonized['study_id'].nunique()}")
            self.logger.info(f"   Variables: {len(harmonized.columns)}")
            
            # Study breakdown
            self.logger.info("\n📊 ACTG Study Breakdown:")
            for study in harmonized['study_id'].unique():
                count = len(harmonized[harmonized['study_id'] == study])
                self.logger.info(f"   {study}: {count} participants")
            
            return harmonized
        else:
            self.logger.warning("No ACTG data successfully extracted")
            return pd.DataFrame()
    
    def analyze_additional_datasets(self) -> Dict[str, Dict]:
        """
        Analyze all other datasets in RP2 folder for potential extraction.
        """
        self.logger.info("\n" + "=" * 60)
        self.logger.info("ADDITIONAL DATASETS ANALYSIS")
        self.logger.info("=" * 60)
        
        # Get all directories in RP2
        rp2_dirs = [d for d in self.raw_path.iterdir() if d.is_dir()]
        
        # Already processed
        processed = ['JHB_DPHRU_053', 'JHB_WRHI_001', 'JHB_ACTG_015', 'JHB_ACTG_016', 'JHB_ACTG_017']
        
        additional_datasets = {}
        
        for dataset_dir in sorted(rp2_dirs):
            if dataset_dir.name not in processed:
                self.logger.info(f"\n📂 Analyzing: {dataset_dir.name}")
                
                # Check for CSV files
                csv_path = dataset_dir / "csv"
                if csv_path.exists():
                    csv_files = list(csv_path.glob("*.csv"))
                    
                    if csv_files:
                        dataset_info = {
                            'csv_files': len(csv_files),
                            'file_names': [f.name for f in csv_files[:5]],  # First 5
                            'total_size_mb': sum(f.stat().st_size for f in csv_files) / (1024*1024)
                        }
                        
                        # Sample first file to check size
                        sample_df = pd.read_csv(csv_files[0], nrows=5)
                        dataset_info['sample_rows'] = len(pd.read_csv(csv_files[0]))
                        dataset_info['sample_cols'] = len(sample_df.columns)
                        
                        additional_datasets[dataset_dir.name] = dataset_info
                        
                        self.logger.info(f"   Files: {dataset_info['csv_files']}")
                        self.logger.info(f"   Sample size: {dataset_info['sample_rows']} rows, {dataset_info['sample_cols']} cols")
                        self.logger.info(f"   Total size: {dataset_info['total_size_mb']:.1f} MB")
        
        # Identify promising datasets
        self.logger.info("\n🎯 Promising Additional Datasets:")
        for dataset, info in additional_datasets.items():
            if info['sample_rows'] > 50:  # Substantial participant count
                self.logger.info(f"   - {dataset}: {info['sample_rows']} records, {info['csv_files']} files")
        
        return additional_datasets
    
    # Helper methods for dataset-specific processing
    
    def _add_dphru053_calculated_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Add calculated features specific to DPHRU053."""
        
        # Calculate HDL if we have total cholesterol, LDL, and triglycerides
        if all(col in df.columns for col in ['metabolic_total_cholesterol', 'metabolic_ldl_cholesterol', 'metabolic_triglycerides']):
            # Friedewald equation: HDL = Total - LDL - (Triglycerides/2.2)
            df['metabolic_hdl_cholesterol_calculated'] = (
                df['metabolic_total_cholesterol'] - 
                df['metabolic_ldl_cholesterol'] - 
                (df['metabolic_triglycerides'] / 2.2)
            )
        
        # Calculate waist-hip ratio
        if all(col in df.columns for col in ['anthropometric_waist', 'anthropometric_hip']):
            df['anthropometric_waist_hip_ratio'] = df['anthropometric_waist'] / df['anthropometric_hip']
        
        # Calculate pulse pressure
        if all(col in df.columns for col in ['cardiovascular_systolic_bp', 'cardiovascular_diastolic_bp']):
            df['cardiovascular_pulse_pressure'] = df['cardiovascular_systolic_bp'] - df['cardiovascular_diastolic_bp']
            df['cardiovascular_mean_arterial_pressure'] = (
                df['cardiovascular_diastolic_bp'] + (df['cardiovascular_pulse_pressure'] / 3)
            )
        
        # Body composition ratios
        if 'body_composition_android_fat_pct' in df.columns:
            # Android/gynoid ratio would need gynoid data
            df['body_composition_central_adiposity'] = df['body_composition_android_fat_pct'] > 30  # Binary indicator
        
        # Sleep quality index
        if all(col in df.columns for col in ['lifestyle_sleep_hours', 'lifestyle_sleep_disturbances']):
            # Simple sleep quality score
            df['lifestyle_sleep_quality_index'] = (
                (df['lifestyle_sleep_hours'].between(7, 9).astype(int) * 50) +  # Optimal sleep hours
                ((10 - df['lifestyle_sleep_disturbances'].fillna(0)) * 5)  # Fewer disturbances is better
            )
        
        # Alcohol risk category
        if 'lifestyle_alcohol_weekday' in df.columns and 'lifestyle_alcohol_weekend' in df.columns:
            df['lifestyle_weekly_alcohol_units'] = (
                df['lifestyle_alcohol_weekday'].fillna(0) * 5 +  # Weekdays
                df['lifestyle_alcohol_weekend'].fillna(0) * 2    # Weekend
            )
        
        return df
    
    def _apply_dphru053_quality_controls(self, df: pd.DataFrame) -> pd.DataFrame:
        """Apply quality controls specific to DPHRU053 data."""
        
        # Clinical range validation
        ranges = {
            'metabolic_glucose': (2.0, 30.0),  # mmol/L
            'metabolic_total_cholesterol': (2.0, 15.0),  # mmol/L
            'cardiovascular_systolic_bp': (70, 250),  # mmHg
            'cardiovascular_diastolic_bp': (40, 150),  # mmHg
            'anthropometric_bmi': (12, 60),  # kg/m²
            'anthropometric_height': (120, 220),  # cm
            'anthropometric_weight': (30, 200),  # kg
            'lifestyle_sleep_hours': (0, 24),  # hours
        }
        
        for col, (min_val, max_val) in ranges.items():
            if col in df.columns:
                out_of_range = (df[col] < min_val) | (df[col] > max_val)
                if out_of_range.any():
                    self.logger.warning(f"  {col}: {out_of_range.sum()} values out of range [{min_val}, {max_val}]")
                    df.loc[out_of_range, col] = np.nan
        
        # Logical consistency checks
        if all(col in df.columns for col in ['cardiovascular_systolic_bp', 'cardiovascular_diastolic_bp']):
            invalid = df['cardiovascular_systolic_bp'] <= df['cardiovascular_diastolic_bp']
            if invalid.any():
                self.logger.warning(f"  Blood pressure: {invalid.sum()} illogical values (systolic <= diastolic)")
                df.loc[invalid, ['cardiovascular_systolic_bp', 'cardiovascular_diastolic_bp']] = np.nan
        
        return df
    
    def _process_wrhi001_laboratory(self, lab_df: pd.DataFrame) -> pd.DataFrame:
        """Process WRHI001 laboratory data from long to wide format."""
        
        # Expected columns in ADLB format
        if 'PARAM' in lab_df.columns and 'LBORRESN' in lab_df.columns:
            # Get unique parameters
            unique_params = lab_df['PARAM'].unique()
            self.logger.info(f"  Found {len(unique_params)} unique laboratory parameters")
            
            # Key biomarkers to extract
            key_biomarkers = {
                'GLUCOSE': 'metabolic_glucose',
                'CHOLESTEROL': 'metabolic_total_cholesterol',
                'TRIGLYCERIDES': 'metabolic_triglycerides',
                'HDL': 'metabolic_hdl_cholesterol',
                'LDL': 'metabolic_ldl_cholesterol',
                'CREATININE': 'renal_creatinine',
                'ALT': 'hepatic_alt',
                'AST': 'hepatic_ast',
                'WBC': 'inflammatory_wbc',
                'HEMOGLOBIN': 'hematologic_hemoglobin',
                'PLATELETS': 'hematologic_platelets',
                'CD4': 'immunologic_cd4_count',
                'CD4%': 'immunologic_cd4_percent',
                'HIV RNA': 'immunologic_viral_load'
            }
            
            # Extract biomarkers that exist
            found_biomarkers = {}
            for param in unique_params:
                for key, std_name in key_biomarkers.items():
                    if key in param.upper():
                        found_biomarkers[param] = std_name
                        break
            
            self.logger.info(f"  Mapped {len(found_biomarkers)} biomarkers")
            
            # Pivot to wide format
            if 'PT' in lab_df.columns and 'AVISIT' in lab_df.columns:
                # Filter to mapped biomarkers
                lab_filtered = lab_df[lab_df['PARAM'].isin(found_biomarkers.keys())].copy()
                lab_filtered['biomarker_name'] = lab_filtered['PARAM'].map(found_biomarkers)
                
                # Pivot
                lab_wide = lab_filtered.pivot_table(
                    index=['PT', 'AVISIT'],
                    columns='biomarker_name',
                    values='LBORRESN',
                    aggfunc='mean'  # Handle duplicates
                ).reset_index()
                
                # Rename PT to participant_id
                lab_wide.rename(columns={'PT': 'participant_id', 'AVISIT': 'visit'}, inplace=True)
                
                self.logger.info(f"  Created wide format: {len(lab_wide)} records, {len(lab_wide.columns)} columns")
                return lab_wide
            else:
                self.logger.warning("  Required columns PT/AVISIT not found")
                return pd.DataFrame()
        else:
            self.logger.warning("  ADLB format columns not found")
            return pd.DataFrame()
    
    def _process_wrhi001_vitals(self, vitals_df: pd.DataFrame) -> pd.DataFrame:
        """Process WRHI001 vital signs data."""
        
        if 'PARAM' in vitals_df.columns and 'VSORRESN' in vitals_df.columns:
            # Key vital signs
            vital_mapping = {
                'SYSBP': 'cardiovascular_systolic_bp',
                'DIABP': 'cardiovascular_diastolic_bp',
                'PULSE': 'cardiovascular_pulse',
                'TEMP': 'vital_temperature',
                'WEIGHT': 'anthropometric_weight',
                'HEIGHT': 'anthropometric_height'
            }
            
            # Similar pivoting logic as laboratory
            found_vitals = {}
            for param in vitals_df['PARAM'].unique():
                for key, std_name in vital_mapping.items():
                    if key in param.upper():
                        found_vitals[param] = std_name
                        break
            
            if 'PT' in vitals_df.columns and 'AVISIT' in vitals_df.columns:
                vitals_filtered = vitals_df[vitals_df['PARAM'].isin(found_vitals.keys())].copy()
                vitals_filtered['vital_name'] = vitals_filtered['PARAM'].map(found_vitals)
                
                vitals_wide = vitals_filtered.pivot_table(
                    index=['PT', 'AVISIT'],
                    columns='vital_name',
                    values='VSORRESN',
                    aggfunc='mean'
                ).reset_index()
                
                vitals_wide.rename(columns={'PT': 'participant_id', 'AVISIT': 'visit'}, inplace=True)
                
                # Calculate BMI if height and weight available
                if all(col in vitals_wide.columns for col in ['anthropometric_height', 'anthropometric_weight']):
                    vitals_wide['anthropometric_bmi'] = (
                        vitals_wide['anthropometric_weight'] / 
                        (vitals_wide['anthropometric_height'] / 100) ** 2
                    )
                
                return vitals_wide
            else:
                return pd.DataFrame()
        else:
            return pd.DataFrame()
    
    def _integrate_wrhi001_tables(self, tables: Dict[str, pd.DataFrame]) -> pd.DataFrame:
        """Integrate WRHI001 tables into unified dataset."""
        
        # Start with subjects table
        integrated = tables['subjects'].copy()
        integrated.rename(columns={'PT': 'participant_id'}, inplace=True)
        
        # Add biomarkers
        if 'biomarkers_wide' in tables and not tables['biomarkers_wide'].empty:
            # Aggregate to participant level (using baseline or mean)
            biomarkers_agg = tables['biomarkers_wide'].groupby('participant_id').first().reset_index()
            integrated = pd.merge(integrated, biomarkers_agg, on='participant_id', how='left')
        
        # Add vitals
        if 'vitals_wide' in tables and not tables['vitals_wide'].empty:
            vitals_agg = tables['vitals_wide'].groupby('participant_id').first().reset_index()
            integrated = pd.merge(integrated, vitals_agg, on='participant_id', how='left', suffixes=('', '_vitals'))
        
        return integrated
    
    def _standardize_actg_data(self, df: pd.DataFrame, study_id: str) -> pd.DataFrame:
        """Standardize ACTG study data to common format."""
        
        standardized = pd.DataFrame()
        
        # Common ID mapping
        id_columns = ['gsk_id', 'id', 'participant_id', 'subject_id', 'pt', 'pid']
        for id_col in id_columns:
            if id_col in df.columns:
                standardized['participant_id'] = study_id + "_" + df[id_col].astype(str)
                break
        
        # Date mapping
        date_columns = ['date', 'visit_date', 'gsk_date', 'collection_date']
        for date_col in date_columns:
            if date_col in df.columns:
                standardized['visit_date'] = pd.to_datetime(df[date_col], errors='coerce')
                break
        
        # Age/demographics
        if 'age' in df.columns:
            standardized['demographic_age'] = df['age']
        
        # Look for biomarkers with flexible naming
        biomarker_patterns = {
            'metabolic_glucose': ['glucose', 'gluc'],
            'metabolic_cholesterol': ['cholesterol', 'chol', 'tc'],
            'renal_creatinine': ['creatinine', 'creat', 'cr'],
            'inflammatory_wbc': ['wbc', 'white_blood', 'leucocytes'],
            'immunologic_cd4': ['cd4', 'cd4_count', 'cd4count']
        }
        
        for std_name, patterns in biomarker_patterns.items():
            for col in df.columns:
                if any(pattern in col.lower() for pattern in patterns):
                    standardized[std_name] = pd.to_numeric(df[col], errors='coerce')
                    break
        
        # Add study identifier
        standardized['study_id'] = study_id
        
        return standardized


def run_dataset_by_dataset_extraction():
    """
    Main function to run dataset-by-dataset extraction process.
    """
    print("=" * 80)
    print("🚀 ENHANCED DATASET-BY-DATASET EXTRACTION SYSTEM")
    print("=" * 80)
    print("Building comprehensive datasets one at a time with proper variable mapping")
    print("=" * 80)
    
    extractor = DatasetSpecificExtractor()
    
    all_datasets = {}
    
    # 1. Extract DPHRU053 with correct mapping
    print("\n📊 STEP 1: DPHRU053 Extraction")
    dphru053 = extractor.extract_enhanced_dphru053_corrected()
    if not dphru053.empty:
        all_datasets['dphru053'] = {
            'data': dphru053,
            'participants': len(dphru053),
            'variables': len(dphru053.columns),
            'unique_features': ['body_composition', 'lifestyle', 'dietary']
        }
    
    # 2. Extract WRHI001 multi-table data
    print("\n📊 STEP 2: WRHI001 Extraction")
    wrhi001_tables = extractor.extract_enhanced_wrhi001()
    if wrhi001_tables:
        all_datasets['wrhi001'] = {
            'tables': wrhi001_tables,
            'table_count': len(wrhi001_tables),
            'unique_features': ['longitudinal', 'hiv_biomarkers', 'clinical_trial']
        }
    
    # 3. Extract and harmonize ACTG studies
    print("\n📊 STEP 3: ACTG Studies Harmonization")
    actg_harmonized = extractor.extract_actg_studies()
    if not actg_harmonized.empty:
        all_datasets['actg'] = {
            'data': actg_harmonized,
            'participants': len(actg_harmonized),
            'studies': actg_harmonized['study_id'].nunique() if 'study_id' in actg_harmonized.columns else 0,
            'unique_features': ['multi_study', 'standardized_panels', 'hiv_cohorts']
        }
    
    # 4. Analyze additional datasets
    print("\n📊 STEP 4: Additional Datasets Analysis")
    additional = extractor.analyze_additional_datasets()
    
    # Final summary
    print("\n" + "=" * 80)
    print("📋 DATASET EXTRACTION SUMMARY")
    print("=" * 80)
    
    for dataset_name, dataset_info in all_datasets.items():
        print(f"\n✅ {dataset_name.upper()}:")
        if 'participants' in dataset_info:
            print(f"   - Participants: {dataset_info['participants']}")
        if 'variables' in dataset_info:
            print(f"   - Variables: {dataset_info['variables']}")
        if 'table_count' in dataset_info:
            print(f"   - Tables: {dataset_info['table_count']}")
        if 'studies' in dataset_info:
            print(f"   - Studies: {dataset_info['studies']}")
        print(f"   - Unique features: {', '.join(dataset_info['unique_features'])}")
    
    if additional:
        print(f"\n📂 Additional datasets identified: {len(additional)}")
        print("   Ready for extraction in subsequent phases")
    
    print("\n🎯 All datasets extracted and saved to:")
    print("   heat_analysis_optimized/data/enhanced_individual/")
    
    return all_datasets


if __name__ == "__main__":
    run_dataset_by_dataset_extraction()