#!/usr/bin/env python
"""
Heat-Health XAI Framework - Data Loading Module

Scalable data loading and validation for multiple datasets.
"""

import pandas as pd
import numpy as np
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any
import warnings
from ..core.config import DatasetConfig

class DataQualityValidator:
    """Validates data quality and structure."""
    
    def __init__(self):
        self.validation_results = {}
    
    def validate_dataset(self, df: pd.DataFrame, config: DatasetConfig) -> Dict[str, Any]:
        """
        Comprehensive data validation.
        
        Args:
            df: Dataset to validate
            config: Dataset configuration
            
        Returns:
            Validation results dictionary
        """
        results = {
            'shape': df.shape,
            'columns': list(df.columns),
            'missing_data': self._check_missing_data(df),
            'data_types': self._check_data_types(df),
            'climate_features': self._validate_climate_features(df, config),
            'health_features': self._validate_health_features(df, config),
            'temporal_structure': self._validate_temporal_structure(df, config),
            'quality_score': 0,
            'recommendations': []
        }
        
        # Calculate overall quality score
        results['quality_score'] = self._calculate_quality_score(results)
        
        # Generate recommendations
        results['recommendations'] = self._generate_recommendations(results)
        
        return results
    
    def _check_missing_data(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Check missing data patterns."""
        missing_pct = (df.isnull().sum() / len(df) * 100).round(2)
        
        return {
            'total_missing': df.isnull().sum().sum(),
            'missing_percentage': missing_pct.to_dict(),
            'high_missing_vars': missing_pct[missing_pct > 50].index.tolist(),
            'complete_cases': len(df.dropna()),
            'complete_case_pct': (len(df.dropna()) / len(df) * 100).round(2)
        }
    
    def _check_data_types(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Check data types and identify potential issues."""
        numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
        categorical_cols = df.select_dtypes(include=['object']).columns.tolist()
        datetime_cols = df.select_dtypes(include=['datetime64']).columns.tolist()
        
        # Check for potential numeric columns stored as strings
        potential_numeric = []
        for col in categorical_cols:
            try:
                pd.to_numeric(df[col], errors='coerce')
                potential_numeric.append(col)
            except:
                pass
        
        return {
            'numeric_columns': numeric_cols,
            'categorical_columns': categorical_cols,
            'datetime_columns': datetime_cols,
            'potential_numeric': potential_numeric,
            'data_type_summary': df.dtypes.to_dict()
        }
    
    def _validate_climate_features(self, df: pd.DataFrame, config: DatasetConfig) -> Dict[str, Any]:
        """Validate climate feature availability and quality."""
        climate_cols = [col for col in df.columns if col.startswith(config.climate_prefix)]
        
        expected_climate = [
            'temperature', 'humidity', 'heat_index', 'pressure'
        ]
        
        available_climate = []
        for expected in expected_climate:
            matching_cols = [col for col in climate_cols if expected in col.lower()]
            if matching_cols:
                available_climate.append({
                    'type': expected,
                    'columns': matching_cols,
                    'data_quality': self._assess_column_quality(df[matching_cols])
                })
        
        return {
            'total_climate_columns': len(climate_cols),
            'available_types': available_climate,
            'climate_columns': climate_cols,
            'coverage_score': len(available_climate) / len(expected_climate)
        }
    
    def _validate_health_features(self, df: pd.DataFrame, config: DatasetConfig) -> Dict[str, Any]:
        """Validate health biomarker availability."""
        health_cols = [col for col in df.columns if col.startswith(config.health_prefix)]
        
        expected_pathways = {
            'cardiovascular': ['bp', 'systolic', 'diastolic', 'heart_rate'],
            'metabolic': ['glucose', 'cholesterol', 'triglycerides', 'hba1c'],
            'inflammatory': ['crp', 'wbc', 'neutrophil', 'lymphocyte'],
            'renal': ['creatinine', 'egfr', 'bun']
        }
        
        pathway_coverage = {}
        for pathway, markers in expected_pathways.items():
            matching_cols = []
            for marker in markers:
                matching = [col for col in health_cols if marker.lower() in col.lower()]
                matching_cols.extend(matching)
            
            pathway_coverage[pathway] = {
                'available_markers': list(set(matching_cols)),
                'coverage_score': len(set(matching_cols)) / len(markers)
            }
        
        return {
            'total_health_columns': len(health_cols),
            'pathway_coverage': pathway_coverage,
            'health_columns': health_cols
        }
    
    def _validate_temporal_structure(self, df: pd.DataFrame, config: DatasetConfig) -> Dict[str, Any]:
        """Validate temporal data structure."""
        temporal_info = {'has_date_column': False}
        
        if config.date_column and config.date_column in df.columns:
            temporal_info['has_date_column'] = True
            date_col = df[config.date_column]
            
            try:
                dates = pd.to_datetime(date_col, errors='coerce')
                temporal_info.update({
                    'date_range': f"{dates.min()} to {dates.max()}",
                    'date_span_days': (dates.max() - dates.min()).days,
                    'valid_dates': dates.notna().sum(),
                    'invalid_dates': dates.isna().sum(),
                    'unique_dates': dates.nunique()
                })
            except Exception as e:
                temporal_info['date_parsing_error'] = str(e)
        
        return temporal_info
    
    def _assess_column_quality(self, cols_df: pd.DataFrame) -> Dict[str, float]:
        """Assess quality of specific columns."""
        quality = {}
        for col in cols_df.columns:
            data = cols_df[col]
            quality[col] = {
                'missing_pct': (data.isna().sum() / len(data) * 100).round(2),
                'zero_pct': ((data == 0).sum() / len(data) * 100).round(2) if data.dtype in [np.number] else 0,
                'unique_values': data.nunique(),
                'outlier_pct': self._detect_outliers(data) if data.dtype in [np.number] else 0
            }
        return quality
    
    def _detect_outliers(self, data: pd.Series, method: str = 'iqr') -> float:
        """Detect outliers using IQR method."""
        try:
            clean_data = data.dropna()
            if len(clean_data) < 10:
                return 0
            
            Q1 = clean_data.quantile(0.25)
            Q3 = clean_data.quantile(0.75)
            IQR = Q3 - Q1
            
            lower_bound = Q1 - 1.5 * IQR
            upper_bound = Q3 + 1.5 * IQR
            
            outliers = ((clean_data < lower_bound) | (clean_data > upper_bound)).sum()
            return (outliers / len(clean_data) * 100).round(2)
        except:
            return 0
    
    def _calculate_quality_score(self, results: Dict[str, Any]) -> float:
        """Calculate overall data quality score (0-100)."""
        scores = []
        
        # Missing data score (0-25)
        complete_case_pct = results['missing_data']['complete_case_pct']
        missing_score = min(25, complete_case_pct / 4)
        scores.append(missing_score)
        
        # Climate coverage score (0-25)
        climate_score = results['climate_features']['coverage_score'] * 25
        scores.append(climate_score)
        
        # Health coverage score (0-25)
        health_coverage = np.mean([
            pathway['coverage_score'] 
            for pathway in results['health_features']['pathway_coverage'].values()
        ])
        health_score = health_coverage * 25
        scores.append(health_score)
        
        # Temporal structure score (0-25)
        temporal_score = 25 if results['temporal_structure']['has_date_column'] else 10
        scores.append(temporal_score)
        
        return sum(scores)
    
    def _generate_recommendations(self, results: Dict[str, Any]) -> List[str]:
        """Generate data quality recommendations."""
        recommendations = []
        
        # Missing data recommendations
        missing_data = results['missing_data']
        if missing_data['complete_case_pct'] < 50:
            recommendations.append(
                f"Only {missing_data['complete_case_pct']:.1f}% complete cases. "
                "Consider imputation strategies or additional data collection."
            )
        
        if missing_data['high_missing_vars']:
            recommendations.append(
                f"Variables with >50% missing data: {', '.join(missing_data['high_missing_vars'])}. "
                "Consider excluding or using specialized missing data techniques."
            )
        
        # Climate coverage recommendations
        climate_score = results['climate_features']['coverage_score']
        if climate_score < 0.5:
            recommendations.append(
                "Limited climate feature coverage. Consider additional climate data sources."
            )
        
        # Temporal structure recommendations
        if not results['temporal_structure']['has_date_column']:
            recommendations.append(
                "No temporal structure detected. Temporal lag features cannot be created."
            )
        
        return recommendations

class DataLoader:
    """Main data loading and preprocessing class."""
    
    def __init__(self):
        self.validator = DataQualityValidator()
        self.loaded_datasets = {}
    
    def load_dataset(self, config: DatasetConfig) -> pd.DataFrame:
        """
        Load dataset using configuration.
        
        Args:
            config: Dataset configuration object
            
        Returns:
            Loaded and validated DataFrame
        """
        print(f"📂 Loading dataset: {config.name}")
        
        # Load data file
        file_path = Path(config.file_path)
        if not file_path.exists():
            raise FileNotFoundError(f"Data file not found: {file_path}")
        
        # Load based on file extension
        if file_path.suffix.lower() == '.csv':
            df = pd.read_csv(file_path)
        elif file_path.suffix.lower() in ['.parquet', '.pq']:
            df = pd.read_parquet(file_path)
        elif file_path.suffix.lower() in ['.xlsx', '.xls']:
            df = pd.read_excel(file_path)
        else:
            raise ValueError(f"Unsupported file format: {file_path.suffix}")
        
        print(f"   Raw data shape: {df.shape}")
        
        # Basic preprocessing
        df = self._basic_preprocessing(df, config)
        
        # Validate data quality
        validation_results = self.validator.validate_dataset(df, config)
        
        print(f"   Data quality score: {validation_results['quality_score']:.1f}/100")
        
        if validation_results['recommendations']:
            print("   ⚠️  Recommendations:")
            for rec in validation_results['recommendations'][:3]:  # Show top 3
                print(f"      • {rec}")
        
        # Store validation results
        self.loaded_datasets[config.name] = {
            'data': df,
            'config': config,
            'validation': validation_results
        }
        
        return df
    
    def load_csv(self, file_path: str, **kwargs) -> pd.DataFrame:
        """Load CSV file directly."""
        df = pd.read_csv(file_path, **kwargs)
        print(f"📂 CSV loaded: {df.shape}")
        return df
    
    def _basic_preprocessing(self, df: pd.DataFrame, config: DatasetConfig) -> pd.DataFrame:
        """Apply basic preprocessing steps."""
        # Convert date column if specified
        if config.date_column and config.date_column in df.columns:
            try:
                df[config.date_column] = pd.to_datetime(df[config.date_column], errors='coerce')
                print(f"   ✅ Date column converted: {config.date_column}")
            except Exception as e:
                print(f"   ⚠️  Date conversion failed: {e}")
        
        # Remove completely empty columns
        empty_cols = df.columns[df.isnull().all()].tolist()
        if empty_cols:
            df = df.drop(columns=empty_cols)
            print(f"   🧹 Removed {len(empty_cols)} empty columns")
        
        # Remove duplicate rows
        n_duplicates = df.duplicated().sum()
        if n_duplicates > 0:
            df = df.drop_duplicates()
            print(f"   🧹 Removed {n_duplicates} duplicate rows")
        
        return df
    
    def get_feature_groups(self, dataset_name: str) -> Dict[str, List[str]]:
        """Get organized feature groups for a loaded dataset."""
        if dataset_name not in self.loaded_datasets:
            raise ValueError(f"Dataset {dataset_name} not loaded")
        
        df = self.loaded_datasets[dataset_name]['data']
        config = self.loaded_datasets[dataset_name]['config']
        
        feature_groups = {
            'climate': [col for col in df.columns if col.startswith(config.climate_prefix)],
            'health': [col for col in df.columns if col.startswith(config.health_prefix)],
            'demographic': [col for col in df.columns if col.startswith(config.demographic_prefix)],
            'other': []
        }
        
        # Classify remaining columns
        all_classified = set()
        for group_cols in feature_groups.values():
            all_classified.update(group_cols)
        
        feature_groups['other'] = [
            col for col in df.columns 
            if col not in all_classified and col != config.date_column
        ]
        
        return feature_groups
    
    def get_validation_report(self, dataset_name: str) -> Dict[str, Any]:
        """Get detailed validation report for a dataset."""
        if dataset_name not in self.loaded_datasets:
            raise ValueError(f"Dataset {dataset_name} not loaded")
        
        return self.loaded_datasets[dataset_name]['validation']