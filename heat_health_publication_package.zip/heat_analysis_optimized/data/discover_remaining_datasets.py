"""
Comprehensive Discovery of Remaining RP2 Datasets

Analyzes all remaining datasets in RP2 folder to identify high-value additions
for comprehensive heat-health XAI analysis.
"""

import pandas as pd
import numpy as np
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any
import logging
from datetime import datetime
import warnings

warnings.filterwarnings('ignore')

class RemainingDatasetDiscovery:
    """
    Comprehensive analysis of all remaining RP2 datasets.
    """
    
    def __init__(self, base_path: str = "/home/cparker"):
        self.base_path = Path(base_path)
        self.raw_path = self.base_path / "incoming" / "RP2"
        
        # Setup logging
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)
        
        # Already processed datasets
        self.processed_datasets = {
            'JHB_DPHRU_053', 'JHB_WRHI_001', 'JHB_Ezin_002', 
            'JHB_IMPAACT_010', 'JHB_SCHARP_006', 'JHB_VIDA_007', 'JHB_WRHI_003'
        }
    
    def discover_all_remaining_datasets(self) -> Dict[str, Dict]:
        """
        Comprehensive discovery of all remaining datasets.
        """
        self.logger.info("="*80)
        self.logger.info("🔍 COMPREHENSIVE REMAINING DATASET DISCOVERY")
        self.logger.info("="*80)
        
        # Get all directories
        all_dirs = [d for d in self.raw_path.iterdir() if d.is_dir()]
        remaining_dirs = [d for d in all_dirs if d.name not in self.processed_datasets]
        
        self.logger.info(f"Total RP2 directories: {len(all_dirs)}")
        self.logger.info(f"Already processed: {len(self.processed_datasets)}")
        self.logger.info(f"Remaining to analyze: {len(remaining_dirs)}")
        
        dataset_analyses = {}
        
        for dataset_dir in sorted(remaining_dirs, key=lambda x: x.name):
            self.logger.info(f"\n{'='*60}")
            self.logger.info(f"📊 ANALYZING: {dataset_dir.name}")
            self.logger.info(f"{'='*60}")
            
            analysis = self._analyze_dataset_comprehensive(dataset_dir)
            if analysis['potential_value'] > 0:
                dataset_analyses[dataset_dir.name] = analysis
        
        # Rank datasets by value
        self._rank_and_recommend_datasets(dataset_analyses)
        
        return dataset_analyses
    
    def _analyze_dataset_comprehensive(self, dataset_dir: Path) -> Dict[str, Any]:
        """
        Comprehensive analysis of a single dataset.
        """
        analysis = {
            'name': dataset_dir.name,
            'csv_files': [],
            'total_records': 0,
            'max_columns': 0,
            'study_type': 'unknown',
            'biomarkers_found': [],
            'unique_features': [],
            'potential_value': 0,
            'file_details': {},
            'sample_data': {},
            'recommendations': []
        }
        
        csv_path = dataset_dir / "csv"
        
        if not csv_path.exists():
            self.logger.warning(f"   No CSV folder found")
            return analysis
        
        csv_files = list(csv_path.glob("*.csv"))
        
        if not csv_files:
            self.logger.warning(f"   No CSV files found")
            return analysis
        
        self.logger.info(f"   Found {len(csv_files)} CSV files")
        analysis['csv_files'] = [f.name for f in csv_files]
        
        # Analyze each CSV file
        total_records = 0
        max_columns = 0
        all_biomarkers = set()
        file_details = {}
        
        for csv_file in csv_files[:10]:  # Analyze first 10 files
            try:
                # Quick analysis
                df_sample = pd.read_csv(csv_file, nrows=5)
                df_full_count = len(pd.read_csv(csv_file))
                
                total_records += df_full_count
                max_columns = max(max_columns, len(df_sample.columns))
                
                # Biomarker detection
                biomarkers = self._detect_biomarkers(df_sample.columns)
                all_biomarkers.update(biomarkers)
                
                file_details[csv_file.name] = {
                    'records': df_full_count,
                    'columns': len(df_sample.columns),
                    'biomarkers': biomarkers,
                    'sample_columns': list(df_sample.columns[:10])
                }
                
                self.logger.info(f"      {csv_file.name}: {df_full_count} records, {len(df_sample.columns)} cols")
                
            except Exception as e:
                self.logger.error(f"      Error analyzing {csv_file.name}: {e}")
        
        analysis['total_records'] = total_records
        analysis['max_columns'] = max_columns
        analysis['biomarkers_found'] = list(all_biomarkers)
        analysis['file_details'] = file_details
        
        # Determine study type and unique features
        analysis = self._classify_study_type(analysis)
        analysis = self._calculate_potential_value(analysis)
        
        # Generate recommendations
        analysis['recommendations'] = self._generate_recommendations(analysis)
        
        # Log summary
        self.logger.info(f"\n   📊 SUMMARY:")
        self.logger.info(f"      Total records: {total_records:,}")
        self.logger.info(f"      Max columns: {max_columns}")
        self.logger.info(f"      Biomarkers found: {len(all_biomarkers)}")
        self.logger.info(f"      Study type: {analysis['study_type']}")
        self.logger.info(f"      Potential value: {analysis['potential_value']}/10")
        
        return analysis
    
    def _detect_biomarkers(self, columns: List[str]) -> List[str]:
        """Detect biomarkers in column names."""
        
        biomarker_patterns = {
            'glucose': ['glucose', 'gluc', 'blood_sugar', 'fbs'],
            'cholesterol': ['cholesterol', 'chol', 'tc', 'total_chol'],
            'triglycerides': ['triglyceride', 'trig', 'tg'],
            'hdl': ['hdl', 'hdl_c', 'hdl_chol', 'high_density'],
            'ldl': ['ldl', 'ldl_c', 'ldl_chol', 'low_density'],
            'creatinine': ['creatinine', 'creat', 'cr', 'scr'],
            'hemoglobin': ['hemoglobin', 'hgb', 'hb', 'haemoglobin'],
            'wbc': ['wbc', 'white_blood', 'leucocyte', 'leukocyte'],
            'cd4': ['cd4', 'cd4_count', 'cd4count', 'cd4_cells'],
            'viral_load': ['viral_load', 'vl', 'hiv_rna', 'hivrna'],
            'blood_pressure': ['bp', 'blood_pressure', 'systolic', 'diastolic'],
            'weight': ['weight', 'wt', 'body_weight'],
            'height': ['height', 'ht', 'stature'],
            'bmi': ['bmi', 'body_mass_index'],
            'temperature': ['temp', 'temperature', 'fever'],
            'oxygen_saturation': ['spo2', 'oxygen', 'sat'],
            'heart_rate': ['heart_rate', 'hr', 'pulse']
        }
        
        found_biomarkers = []
        
        for biomarker_type, patterns in biomarker_patterns.items():
            for col in columns:
                if any(pattern in col.lower() for pattern in patterns):
                    found_biomarkers.append(biomarker_type)
                    break
        
        return found_biomarkers
    
    def _classify_study_type(self, analysis: Dict) -> Dict:
        """Classify study type based on dataset characteristics."""
        
        name = analysis['name'].upper()
        
        # Study type classification
        if 'ACTG' in name:
            analysis['study_type'] = 'HIV Clinical Trial'
            analysis['unique_features'].extend(['hiv_treatment', 'clinical_trial', 'standardized_protocol'])
        elif 'IMPAACT' in name:
            analysis['study_type'] = 'Pediatric HIV Study'
            analysis['unique_features'].extend(['pediatric', 'maternal_child', 'hiv_prevention'])
        elif 'WRHI' in name:
            analysis['study_type'] = 'Reproductive Health Study'
            analysis['unique_features'].extend(['womens_health', 'reproductive', 'hiv_prevention'])
        elif 'DPHRU' in name:
            analysis['study_type'] = 'Population Health Study'
            analysis['unique_features'].extend(['population_based', 'comprehensive_health'])
        elif 'SCHARP' in name:
            analysis['study_type'] = 'HIV Vaccine/Prevention Study'
            analysis['unique_features'].extend(['vaccine', 'prevention', 'immunology'])
        elif 'VIDA' in name:
            analysis['study_type'] = 'Vaccine Study'
            analysis['unique_features'].extend(['vaccine', 'safety', 'immunology'])
        elif 'EZIN' in name:
            analysis['study_type'] = 'HIV Cohort Study'
            analysis['unique_features'].extend(['hiv_cohort', 'longitudinal'])
        elif 'AURUM' in name:
            analysis['study_type'] = 'Mining/Occupational Health'
            analysis['unique_features'].extend(['occupational', 'mining', 'respiratory'])
        elif 'JHSPH' in name:
            analysis['study_type'] = 'Johns Hopkins Public Health'
            analysis['unique_features'].extend(['public_health', 'epidemiology'])
        elif 'PACCI' in name:
            analysis['study_type'] = 'Pan-African Clinical Trial'
            analysis['unique_features'].extend(['multi_country', 'clinical_trial'])
        
        # Add biomarker-based features
        biomarkers = analysis['biomarkers_found']
        if 'cd4' in biomarkers or 'viral_load' in biomarkers:
            analysis['unique_features'].append('hiv_biomarkers')
        if 'glucose' in biomarkers and 'cholesterol' in biomarkers:
            analysis['unique_features'].append('metabolic_panel')
        if 'hemoglobin' in biomarkers and 'wbc' in biomarkers:
            analysis['unique_features'].append('hematology_panel')
        
        return analysis
    
    def _calculate_potential_value(self, analysis: Dict) -> Dict:
        """Calculate potential value score for dataset."""
        
        score = 0
        
        # Sample size scoring
        if analysis['total_records'] > 5000:
            score += 3
        elif analysis['total_records'] > 1000:
            score += 2
        elif analysis['total_records'] > 100:
            score += 1
        
        # Variable richness scoring
        if analysis['max_columns'] > 100:
            score += 2
        elif analysis['max_columns'] > 50:
            score += 1
        
        # Biomarker scoring
        biomarker_count = len(analysis['biomarkers_found'])
        if biomarker_count > 10:
            score += 3
        elif biomarker_count > 5:
            score += 2
        elif biomarker_count > 0:
            score += 1
        
        # Unique features scoring
        unique_features = len(analysis['unique_features'])
        if unique_features > 3:
            score += 2
        elif unique_features > 0:
            score += 1
        
        analysis['potential_value'] = min(score, 10)  # Cap at 10
        
        return analysis
    
    def _generate_recommendations(self, analysis: Dict) -> List[str]:
        """Generate extraction recommendations."""
        
        recommendations = []
        
        if analysis['potential_value'] >= 8:
            recommendations.append("🟢 HIGH PRIORITY - Immediate extraction recommended")
        elif analysis['potential_value'] >= 5:
            recommendations.append("🟡 MEDIUM PRIORITY - Extract after high priority datasets")
        elif analysis['potential_value'] >= 2:
            recommendations.append("🟠 LOW PRIORITY - Consider for completeness")
        else:
            recommendations.append("🔴 SKIP - Limited value for current analysis")
        
        # Specific recommendations
        if analysis['total_records'] > 3000:
            recommendations.append("✅ Large sample size - excellent statistical power")
        
        if len(analysis['biomarkers_found']) > 8:
            recommendations.append("✅ Rich biomarker panel - high analytical value")
        
        if 'hiv_biomarkers' in analysis['unique_features']:
            recommendations.append("✅ HIV biomarkers - complements existing HIV studies")
        
        if 'clinical_trial' in analysis['unique_features']:
            recommendations.append("✅ Clinical trial design - high data quality expected")
        
        if analysis['study_type'] not in ['HIV Clinical Trial', 'Reproductive Health Study', 'Vaccine Study']:
            recommendations.append("✅ Novel study type - adds diversity to collection")
        
        return recommendations
    
    def _rank_and_recommend_datasets(self, analyses: Dict[str, Dict]) -> None:
        """Rank datasets and provide final recommendations."""
        
        self.logger.info("\n" + "="*80)
        self.logger.info("🏆 DATASET RANKING & RECOMMENDATIONS")
        self.logger.info("="*80)
        
        # Sort by potential value
        ranked = sorted(analyses.items(), key=lambda x: x[1]['potential_value'], reverse=True)
        
        high_priority = []
        medium_priority = []
        low_priority = []
        
        for name, analysis in ranked:
            if analysis['potential_value'] >= 8:
                high_priority.append((name, analysis))
            elif analysis['potential_value'] >= 5:
                medium_priority.append((name, analysis))
            else:
                low_priority.append((name, analysis))
        
        # Report high priority
        if high_priority:
            self.logger.info(f"\n🟢 HIGH PRIORITY DATASETS ({len(high_priority)}):")
            self.logger.info("-" * 50)
            for name, analysis in high_priority:
                self.logger.info(f"✅ {name}:")
                self.logger.info(f"   - Records: {analysis['total_records']:,}")
                self.logger.info(f"   - Biomarkers: {len(analysis['biomarkers_found'])}")
                self.logger.info(f"   - Type: {analysis['study_type']}")
                self.logger.info(f"   - Value Score: {analysis['potential_value']}/10")
        
        # Report medium priority
        if medium_priority:
            self.logger.info(f"\n🟡 MEDIUM PRIORITY DATASETS ({len(medium_priority)}):")
            self.logger.info("-" * 50)
            for name, analysis in medium_priority:
                self.logger.info(f"○ {name}: {analysis['total_records']:,} records, {analysis['study_type']}")
        
        # Report low priority
        if low_priority:
            self.logger.info(f"\n🟠 LOW PRIORITY DATASETS ({len(low_priority)}):")
            self.logger.info("-" * 50)
            for name, analysis in low_priority:
                self.logger.info(f"• {name}: {analysis['total_records']:,} records")
        
        # Summary recommendations
        total_additional_records = sum(a['total_records'] for a in analyses.values())
        high_priority_records = sum(a['total_records'] for _, a in high_priority)
        
        self.logger.info(f"\n📊 EXTRACTION IMPACT SUMMARY:")
        self.logger.info(f"   - Total additional datasets available: {len(analyses)}")
        self.logger.info(f"   - Total additional records: {total_additional_records:,}")
        self.logger.info(f"   - High priority records: {high_priority_records:,}")
        self.logger.info(f"   - Current collection: 15,923 participants")
        self.logger.info(f"   - Potential new total: {15923 + total_additional_records:,} participants")
        
        if high_priority:
            self.logger.info(f"\n🎯 RECOMMENDATION:")
            self.logger.info(f"   Extract {len(high_priority)} high-priority datasets first")
            self.logger.info(f"   This would add {high_priority_records:,} participants")
            self.logger.info(f"   New total would be: {15923 + high_priority_records:,} participants")


def main():
    """Main execution function."""
    print("🔍 COMPREHENSIVE REMAINING DATASET DISCOVERY")
    print("="*80)
    print("Analyzing all remaining RP2 datasets for potential extraction")
    print("="*80)
    
    discoverer = RemainingDatasetDiscovery()
    
    # Discover all remaining datasets
    analyses = discoverer.discover_all_remaining_datasets()
    
    print(f"\n✅ Discovery complete!")
    print(f"📊 Analyzed {len(analyses)} additional datasets")
    print(f"🎯 Ready for targeted high-value extraction")
    
    return analyses


if __name__ == "__main__":
    main()