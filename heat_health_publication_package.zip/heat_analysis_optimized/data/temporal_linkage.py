"""
Temporal Linkage System for Precise Visit-Level Climate Matching

Advanced temporal matching system that links health biomarker visit dates
with precise climate exposure windows from multiple sources.
"""

import pandas as pd
import numpy as np
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any, Union
import logging
from datetime import datetime, timedelta
import warnings

warnings.filterwarnings('ignore')

class TemporalLinkageSystem:
    """
    Precise temporal matching system for health-climate data integration.
    
    Key Features:
    - Visit-date precision: Match climate to exact visit dates
    - Multi-window exposure: 1-90 day exposure windows  
    - Lag effect modeling: Account for delayed health responses
    - Missing data handling: Interpolation and forward/backward fill
    - Quality validation: Temporal consistency checks
    """
    
    def __init__(self, base_path: str = "/home/cparker"):
        self.base_path = Path(base_path)
        self.output_path = self.base_path / "heat_analysis_optimized" / "data" / "temporal_linked"
        
        # Create output directory
        self.output_path.mkdir(parents=True, exist_ok=True)
        
        # Setup logging
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)
        
        # Default exposure windows (days before visit)
        self.default_windows = {
            'acute': [1, 3, 7],           # Immediate effects
            'subacute': [14, 21, 28],     # Short-term adaptation
            'chronic': [30, 60, 90]       # Long-term effects
        }
        
    def create_temporal_linkage(self, 
                              health_data: pd.DataFrame,
                              climate_data: pd.DataFrame,
                              date_column: str = 'visit_date',
                              id_column: str = 'participant_id',
                              exposure_windows: Optional[Dict[str, List[int]]] = None) -> pd.DataFrame:
        """
        Create comprehensive temporal linkage between health and climate data.
        
        Args:
            health_data: DataFrame with health biomarkers and visit dates
            climate_data: DataFrame with climate variables and dates
            date_column: Name of date column in health_data
            id_column: Name of participant ID column
            exposure_windows: Custom exposure windows, uses defaults if None
            
        Returns:
            DataFrame with temporally-matched health and climate data
        """
        if exposure_windows is None:
            exposure_windows = self.default_windows
            
        self.logger.info("Starting comprehensive temporal linkage...")
        self.logger.info(f"Health data: {len(health_data)} visits")
        self.logger.info(f"Climate data: {len(climate_data)} time points")
        
        # Validate input data
        self._validate_temporal_data(health_data, climate_data, date_column, id_column)
        
        # Prepare data for temporal matching
        health_prepared = self._prepare_health_data(health_data, date_column, id_column)
        climate_prepared = self._prepare_climate_data(climate_data)
        
        # Create temporal matches for each exposure window
        temporal_features = []
        
        for window_type, windows in exposure_windows.items():
            self.logger.info(f"Processing {window_type} exposure windows: {windows} days")
            
            for window_days in windows:
                window_features = self._create_window_features(
                    health_prepared, climate_prepared, window_days, window_type
                )
                temporal_features.append(window_features)
        
        # Combine all temporal features
        if temporal_features:
            # Start with health data
            linked_data = health_prepared.copy()
            
            # Merge each temporal window
            for features in temporal_features:
                linked_data = pd.merge(linked_data, features, 
                                     on=[id_column, date_column], 
                                     how='left')
            
            # Generate temporal interaction features
            linked_data = self._create_temporal_interactions(linked_data)
            
            # Quality validation and reporting
            quality_report = self._validate_temporal_linkage(linked_data)
            self._log_quality_report(quality_report)
            
            self.logger.info(f"✅ Temporal linkage completed: {len(linked_data.columns)} features")
            
            # Save temporally-linked dataset
            output_file = self.output_path / "temporal_linked_dataset.csv"
            linked_data.to_csv(output_file, index=False)
            self.logger.info(f"Temporal linked data saved to: {output_file}")
            
            return linked_data
        else:
            self.logger.error("No temporal features generated")
            return pd.DataFrame()
    
    def create_longitudinal_linkage(self, 
                                   multi_visit_data: pd.DataFrame,
                                   climate_data: pd.DataFrame,
                                   participant_col: str = 'participant_id',
                                   visit_col: str = 'visit_number',
                                   date_col: str = 'visit_date') -> pd.DataFrame:
        """
        Create temporal linkage for longitudinal data with multiple visits per participant.
        
        Specialized for datasets like WRHI001 with repeated measurements.
        
        Args:
            multi_visit_data: DataFrame with multiple visits per participant
            climate_data: Climate data with temporal resolution
            participant_col: Participant identifier column
            visit_col: Visit number/sequence column  
            date_col: Visit date column
            
        Returns:
            DataFrame with visit-level temporal climate linkage
        """
        self.logger.info("Creating longitudinal temporal linkage...")
        self.logger.info(f"Processing {len(multi_visit_data)} participant-visits")
        
        # Group by participant to handle longitudinal structure
        participant_groups = multi_visit_data.groupby(participant_col)
        
        longitudinal_features = []
        
        for participant_id, participant_data in participant_groups:
            # Sort visits chronologically
            participant_data = participant_data.sort_values(date_col)
            
            # Create temporal features for each visit
            for _, visit_row in participant_data.iterrows():
                visit_date = pd.to_datetime(visit_row[date_col])
                
                # Extract climate features for this visit
                visit_climate = self._extract_visit_climate(climate_data, visit_date, participant_id)
                
                # Add visit-specific identifiers
                visit_climate[participant_col] = participant_id
                visit_climate[visit_col] = visit_row[visit_col]
                visit_climate[date_col] = visit_date
                
                longitudinal_features.append(visit_climate)
        
        # Combine all visit-level features
        if longitudinal_features:
            longitudinal_linked = pd.concat(longitudinal_features, ignore_index=True)
            
            # Merge with original multi-visit data
            linked_data = pd.merge(multi_visit_data, longitudinal_linked,
                                 on=[participant_col, visit_col, date_col],
                                 how='left')
            
            # Create longitudinal-specific features
            linked_data = self._create_longitudinal_features(linked_data, participant_col, visit_col)
            
            self.logger.info(f"✅ Longitudinal linkage completed: {len(linked_data)} visits")
            
            # Save longitudinal linked dataset
            output_file = self.output_path / "longitudinal_temporal_linked.csv"
            linked_data.to_csv(output_file, index=False)
            
            return linked_data
        else:
            self.logger.error("No longitudinal features generated")
            return pd.DataFrame()
    
    def _prepare_health_data(self, health_data: pd.DataFrame, date_col: str, id_col: str) -> pd.DataFrame:
        """Prepare health data for temporal matching."""
        prepared = health_data.copy()
        
        # Ensure date column is datetime
        prepared[date_col] = pd.to_datetime(prepared[date_col])
        
        # Sort by participant and date
        prepared = prepared.sort_values([id_col, date_col])
        
        # Remove duplicates if any
        before_dedup = len(prepared)
        prepared = prepared.drop_duplicates(subset=[id_col, date_col])
        after_dedup = len(prepared)
        
        if before_dedup != after_dedup:
            self.logger.warning(f"Removed {before_dedup - after_dedup} duplicate health records")
        
        self.logger.info(f"Health data prepared: {len(prepared)} unique visit records")
        return prepared
    
    def _prepare_climate_data(self, climate_data: pd.DataFrame) -> pd.DataFrame:
        """Prepare climate data for temporal matching."""
        prepared = climate_data.copy()
        
        # Identify date column (flexible naming)
        date_columns = [col for col in prepared.columns if any(x in col.lower() for x in ['date', 'time'])]
        
        if date_columns:
            date_col = date_columns[0]
            prepared['climate_date'] = pd.to_datetime(prepared[date_col])
        else:
            self.logger.error("No date column found in climate data")
            return pd.DataFrame()
        
        # Sort by date
        prepared = prepared.sort_values('climate_date')
        
        # Remove duplicates by date
        before_dedup = len(prepared)
        prepared = prepared.drop_duplicates(subset=['climate_date'])
        after_dedup = len(prepared)
        
        if before_dedup != after_dedup:
            self.logger.warning(f"Removed {before_dedup - after_dedup} duplicate climate records")
        
        self.logger.info(f"Climate data prepared: {len(prepared)} unique time points")
        return prepared
    
    def _create_window_features(self, 
                               health_data: pd.DataFrame,
                               climate_data: pd.DataFrame,
                               window_days: int,
                               window_type: str) -> pd.DataFrame:
        """Create climate features for specific exposure window."""
        
        window_features = []
        
        for _, health_row in health_data.iterrows():
            participant_id = health_row['participant_id']
            visit_date = health_row['visit_date']
            
            # Define exposure window
            window_end = visit_date
            window_start = visit_date - timedelta(days=window_days)
            
            # Extract climate data for this window
            window_climate = climate_data[
                (climate_data['climate_date'] >= window_start) & 
                (climate_data['climate_date'] <= window_end)
            ].copy()
            
            if len(window_climate) > 0:
                # Calculate aggregated statistics for the window
                climate_stats = self._calculate_window_statistics(window_climate, window_days, window_type)
                
                # Add identifiers
                climate_stats['participant_id'] = participant_id
                climate_stats['visit_date'] = visit_date
                
                window_features.append(climate_stats)
            else:
                # Handle missing climate data
                self.logger.warning(f"No climate data for participant {participant_id}, date {visit_date}, window {window_days}d")
                empty_stats = self._create_empty_window_stats(window_days, window_type)
                empty_stats['participant_id'] = participant_id
                empty_stats['visit_date'] = visit_date
                window_features.append(empty_stats)
        
        if window_features:
            return pd.DataFrame(window_features)
        else:
            return pd.DataFrame()
    
    def _calculate_window_statistics(self, 
                                   window_climate: pd.DataFrame,
                                   window_days: int,
                                   window_type: str) -> Dict[str, float]:
        """Calculate comprehensive statistics for climate exposure window."""
        
        stats = {}
        
        # Find numeric climate variables
        numeric_cols = window_climate.select_dtypes(include=[np.number]).columns
        numeric_cols = [col for col in numeric_cols if col != 'climate_date']
        
        for climate_var in numeric_cols:
            var_data = window_climate[climate_var].dropna()
            
            if len(var_data) > 0:
                # Basic statistics
                stats[f'{climate_var}_{window_days}d_{window_type}_mean'] = var_data.mean()
                stats[f'{climate_var}_{window_days}d_{window_type}_max'] = var_data.max()
                stats[f'{climate_var}_{window_days}d_{window_type}_min'] = var_data.min()
                stats[f'{climate_var}_{window_days}d_{window_type}_std'] = var_data.std()
                
                # Additional statistics for longer windows
                if window_days >= 7:
                    stats[f'{climate_var}_{window_days}d_{window_type}_q75'] = var_data.quantile(0.75)
                    stats[f'{climate_var}_{window_days}d_{window_type}_q25'] = var_data.quantile(0.25)
                    stats[f'{climate_var}_{window_days}d_{window_type}_range'] = var_data.max() - var_data.min()
                
                # Heat stress indicators
                if 'temperature' in climate_var.lower():
                    stats[f'{climate_var}_{window_days}d_{window_type}_heat_days'] = (var_data > 30).sum()
                    stats[f'{climate_var}_{window_days}d_{window_type}_extreme_days'] = (var_data > 35).sum()
                    stats[f'{climate_var}_{window_days}d_{window_type}_heat_degree_days'] = np.maximum(var_data - 18, 0).sum()
            else:
                # Fill with NaN for missing data
                for stat_type in ['mean', 'max', 'min', 'std']:
                    stats[f'{climate_var}_{window_days}d_{window_type}_{stat_type}'] = np.nan
        
        return stats
    
    def _create_empty_window_stats(self, window_days: int, window_type: str) -> Dict[str, float]:
        """Create empty statistics structure for missing climate data."""
        
        # Default climate variables (will be replaced with actual variables)
        default_vars = ['temperature', 'humidity', 'pressure']
        stats = {}
        
        for var in default_vars:
            for stat_type in ['mean', 'max', 'min', 'std']:
                stats[f'{var}_{window_days}d_{window_type}_{stat_type}'] = np.nan
        
        return stats
    
    def _extract_visit_climate(self, climate_data: pd.DataFrame, visit_date: datetime, participant_id: str) -> Dict[str, Any]:
        """Extract climate features for a specific visit date."""
        
        # Default exposure windows for visit-level extraction
        windows = [1, 3, 7, 14, 30]
        
        visit_features = {}
        
        for window_days in windows:
            window_start = visit_date - timedelta(days=window_days)
            window_end = visit_date
            
            # Extract climate data for window
            window_data = climate_data[
                (climate_data['climate_date'] >= window_start) &
                (climate_data['climate_date'] <= window_end)
            ]
            
            if len(window_data) > 0:
                # Calculate statistics
                numeric_cols = window_data.select_dtypes(include=[np.number]).columns
                for col in numeric_cols:
                    if col != 'climate_date':
                        visit_features[f'{col}_{window_days}d_mean'] = window_data[col].mean()
                        visit_features[f'{col}_{window_days}d_max'] = window_data[col].max()
            else:
                # Handle missing data
                for col in ['temperature', 'humidity']:  # Default variables
                    visit_features[f'{col}_{window_days}d_mean'] = np.nan
                    visit_features[f'{col}_{window_days}d_max'] = np.nan
        
        return visit_features
    
    def _create_temporal_interactions(self, linked_data: pd.DataFrame) -> pd.DataFrame:
        """Create interaction features between different temporal windows."""
        self.logger.info("Creating temporal interaction features...")
        
        # Find temperature features across different windows
        temp_cols = [col for col in linked_data.columns if 'temperature' in col and 'mean' in col]
        
        # Create ratios between short-term and long-term exposures
        short_term_cols = [col for col in temp_cols if any(f'{d}d' in col for d in [1, 3, 7])]
        long_term_cols = [col for col in temp_cols if any(f'{d}d' in col for d in [30, 60, 90])]
        
        for short_col in short_term_cols[:3]:  # Limit to avoid too many features
            for long_col in long_term_cols[:2]:
                if short_col != long_col:
                    # Create ratio feature
                    ratio_name = f"{short_col.split('_')[1]}_{short_col.split('_')[2]}_vs_{long_col.split('_')[2]}_ratio"
                    linked_data[ratio_name] = linked_data[short_col] / (linked_data[long_col] + 0.1)  # Avoid division by zero
        
        # Temperature change velocity (recent vs. historical)
        recent_temp = [col for col in temp_cols if '7d' in col and 'mean' in col]
        historical_temp = [col for col in temp_cols if '30d' in col and 'mean' in col]
        
        if recent_temp and historical_temp:
            linked_data['temperature_velocity_7d_vs_30d'] = linked_data[recent_temp[0]] - linked_data[historical_temp[0]]
        
        # Heat accumulation index (sum of heat degree days across windows)
        heat_day_cols = [col for col in linked_data.columns if 'heat_degree_days' in col]
        if heat_day_cols:
            linked_data['cumulative_heat_exposure'] = linked_data[heat_day_cols].sum(axis=1)
        
        interaction_features = len([c for c in linked_data.columns if any(x in c for x in ['ratio', 'velocity', 'cumulative'])])
        self.logger.info(f"Temporal interactions created: {interaction_features} features")
        
        return linked_data
    
    def _create_longitudinal_features(self, 
                                    linked_data: pd.DataFrame,
                                    participant_col: str,
                                    visit_col: str) -> pd.DataFrame:
        """Create longitudinal-specific temporal features."""
        self.logger.info("Creating longitudinal temporal features...")
        
        # Sort by participant and visit
        linked_data = linked_data.sort_values([participant_col, visit_col])
        
        # Find climate variables for longitudinal analysis
        climate_cols = [col for col in linked_data.columns if any(x in col for x in ['temperature', 'humidity', 'heat'])]
        
        # Create visit-to-visit changes
        for climate_var in climate_cols[:10]:  # Limit to key variables
            # Calculate change from previous visit
            linked_data[f'{climate_var}_change_from_prev'] = linked_data.groupby(participant_col)[climate_var].diff()
            
            # Calculate rolling mean across visits
            linked_data[f'{climate_var}_visit_rolling_mean'] = linked_data.groupby(participant_col)[climate_var].rolling(3, min_periods=1).mean().values
        
        # Baseline establishment for each participant
        baseline_cols = [col for col in climate_cols if '30d' in col and 'mean' in col][:5]
        for baseline_col in baseline_cols:
            # First visit baseline
            baseline_values = linked_data.groupby(participant_col)[baseline_col].first()
            linked_data[f'{baseline_col}_vs_baseline'] = linked_data[baseline_col] - linked_data[participant_col].map(baseline_values)
        
        longitudinal_features = len([c for c in linked_data.columns if any(x in c for x in ['change_from', 'rolling', 'vs_baseline'])])
        self.logger.info(f"Longitudinal features created: {longitudinal_features} features")
        
        return linked_data
    
    def _validate_temporal_data(self, health_data: pd.DataFrame, climate_data: pd.DataFrame, 
                               date_col: str, id_col: str) -> None:
        """Validate temporal data quality and consistency."""
        
        # Check required columns
        if date_col not in health_data.columns:
            raise ValueError(f"Date column '{date_col}' not found in health data")
        if id_col not in health_data.columns:
            raise ValueError(f"ID column '{id_col}' not found in health data")
        
        # Check date formats
        try:
            pd.to_datetime(health_data[date_col])
        except:
            raise ValueError(f"Cannot convert health data '{date_col}' to datetime")
        
        # Check for reasonable date ranges
        health_dates = pd.to_datetime(health_data[date_col])
        if health_dates.min() < datetime(1900, 1, 1) or health_dates.max() > datetime(2030, 12, 31):
            self.logger.warning("Health data contains unusual date ranges")
        
        self.logger.info("✅ Temporal data validation passed")
    
    def _validate_temporal_linkage(self, linked_data: pd.DataFrame) -> Dict[str, Any]:
        """Validate quality of temporal linkage results."""
        
        report = {}
        
        # Missing data assessment
        climate_cols = [col for col in linked_data.columns if any(x in col for x in ['temperature', 'humidity', 'heat'])]
        missing_pct = linked_data[climate_cols].isnull().mean() * 100
        
        report['missing_data'] = {
            'high_missing_vars': list(missing_pct[missing_pct > 50].index),
            'avg_missing_pct': missing_pct.mean(),
            'total_climate_vars': len(climate_cols)
        }
        
        # Temporal coverage
        if 'visit_date' in linked_data.columns:
            visit_dates = pd.to_datetime(linked_data['visit_date'])
            report['temporal_coverage'] = {
                'date_range': f"{visit_dates.min().date()} to {visit_dates.max().date()}",
                'total_days': (visit_dates.max() - visit_dates.min()).days,
                'unique_dates': len(visit_dates.unique())
            }
        
        # Data completeness by exposure window
        window_types = ['acute', 'subacute', 'chronic']
        for window_type in window_types:
            window_cols = [col for col in climate_cols if window_type in col]
            if window_cols:
                completeness = linked_data[window_cols].notna().all(axis=1).mean() * 100
                report[f'{window_type}_completeness'] = f"{completeness:.1f}%"
        
        return report
    
    def _log_quality_report(self, report: Dict[str, Any]) -> None:
        """Log temporal linkage quality report."""
        self.logger.info("📊 Temporal Linkage Quality Report:")
        
        if 'missing_data' in report:
            missing = report['missing_data']
            self.logger.info(f"   - Average missing data: {missing['avg_missing_pct']:.1f}%")
            self.logger.info(f"   - Total climate variables: {missing['total_climate_vars']}")
            if missing['high_missing_vars']:
                self.logger.warning(f"   - High missing (>50%): {len(missing['high_missing_vars'])} variables")
        
        if 'temporal_coverage' in report:
            coverage = report['temporal_coverage']
            self.logger.info(f"   - Temporal range: {coverage['date_range']}")
            self.logger.info(f"   - Unique dates: {coverage['unique_dates']}")
        
        window_types = ['acute', 'subacute', 'chronic']
        for window_type in window_types:
            if f'{window_type}_completeness' in report:
                completeness = report[f'{window_type}_completeness']
                self.logger.info(f"   - {window_type.capitalize()} window completeness: {completeness}")


def main():
    """Main execution function for temporal linkage system."""
    temporal_system = TemporalLinkageSystem()
    
    print("⏰ Temporal Linkage System for Heat-Health Analysis")
    print("=" * 55)
    
    # Create sample data for demonstration
    print("\n📅 Creating sample temporal linkage...")
    
    # Sample health data
    sample_health = pd.DataFrame({
        'participant_id': [f'P{i:04d}' for i in range(1, 51)],
        'visit_date': pd.date_range('2020-01-01', periods=50, freq='7D'),
        'biomarker_glucose': np.random.normal(5.5, 1.2, 50),
        'biomarker_crp': np.random.lognormal(1, 0.8, 50),
        'biomarker_systolic_bp': np.random.normal(125, 15, 50)
    })
    
    # Sample climate data
    date_range = pd.date_range('2019-12-01', '2020-12-31', freq='D')
    sample_climate = pd.DataFrame({
        'date': date_range,
        'temperature': np.random.normal(20, 8, len(date_range)),
        'humidity': np.random.normal(65, 15, len(date_range)),
        'heat_index': np.random.normal(22, 9, len(date_range))
    })
    
    # Create comprehensive temporal linkage
    linked_data = temporal_system.create_temporal_linkage(
        health_data=sample_health,
        climate_data=sample_climate,
        date_column='visit_date',
        id_column='participant_id'
    )
    
    if not linked_data.empty:
        print(f"\n✅ Temporal linkage completed:")
        print(f"   - Linked records: {len(linked_data)}")
        print(f"   - Total features: {len(linked_data.columns)}")
        
        # Feature breakdown by window type
        window_types = ['acute', 'subacute', 'chronic']
        for window_type in window_types:
            window_cols = [col for col in linked_data.columns if window_type in col]
            print(f"   - {window_type.capitalize()} window: {len(window_cols)} features")
        
        # Temporal interaction features
        interaction_cols = [col for col in linked_data.columns if any(x in col for x in ['ratio', 'velocity', 'cumulative'])]
        print(f"   - Temporal interactions: {len(interaction_cols)} features")
    
    print("\n🎯 Temporal linkage system ready for enhanced XAI analysis!")
    print("Integration with raw biomarker extraction creates comprehensive dataset")


if __name__ == "__main__":
    main()