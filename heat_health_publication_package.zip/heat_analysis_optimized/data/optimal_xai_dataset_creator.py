"""
Optimal XAI Dataset Creator

Creates the optimal dataset for heat-health XAI analysis by:
1. Loading and harmonizing the 4 high-quality datasets
2. Integrating multi-source climate data 
3. Creating standardized biomarker variables
4. Generating interaction features
5. Preparing final XAI-ready dataset

High-Quality Datasets:
- DPHRU_053: 1,013 participants, metabolic/body composition
- DPHRU_013: 1,031 participants, longitudinal biomarkers
- VIDA_008: 552 participants, healthcare workers
- WRHI_001: ~1,072 unique participants, comprehensive lab panels
"""

import pandas as pd
import numpy as np
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any
import logging
from datetime import datetime, timedelta
import warnings
import xarray as xr

warnings.filterwarnings('ignore')

class OptimalXAIDatasetCreator:
    """
    Creates optimal dataset for heat-health XAI analysis.
    """
    
    def __init__(self, base_path: str = "/home/cparker"):
        self.base_path = Path(base_path)
        self.data_path = self.base_path / "heat_analysis_optimized" / "data"
        self.output_path = self.data_path / "optimal_xai_ready"
        
        # Create output directory
        self.output_path.mkdir(parents=True, exist_ok=True)
        
        # Setup logging
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)
        
        # Climate data paths
        self.climate_path = self.base_path / "heat_center" / "data" / "climate"
        
        # Standard biomarker mappings
        self.standard_biomarkers = {
            'glucose': ['glucose', 'gluc', 'blood_sugar', 'fasting_glucose'],
            'cholesterol_total': ['cholesterol', 'total_cholesterol', 'cholesterole', 'chol'],
            'cholesterol_hdl': ['hdl', 'hdl_cholesterol', 'hdl_c'],
            'cholesterol_ldl': ['ldl', 'ldl_cholesterol', 'ldl_c'],
            'triglycerides': ['triglycerides', 'trig', 'trigs'],
            'creatinine': ['creatinine', 'creat', 'cr'],
            'hemoglobin': ['hemoglobin', 'hgb', 'hb'],
            'potassium': ['potassium', 'k', 'serum_potassium'],
            'sodium': ['sodium', 'na', 'serum_sodium'],
            'weight': ['weight', 'wt', 'body_weight'],
            'height': ['height', 'ht'],
            'bmi': ['bmi', 'body_mass_index'],
            'systolic_bp': ['systolic', 'sbp', 'sysbp', 'sbp_mean'],
            'diastolic_bp': ['diastolic', 'dbp', 'diabp', 'dbp_mean'],
            'heart_rate': ['heart_rate', 'hr', 'pulse'],
            'temperature': ['temperature', 'temp', 'body_temp']
        }
        
    def load_high_quality_datasets(self) -> Dict[str, pd.DataFrame]:
        """
        Load the 4 high-quality datasets.
        """
        self.logger.info("=" * 80)
        self.logger.info("📥 LOADING HIGH-QUALITY DATASETS")
        self.logger.info("=" * 80)
        
        datasets = {}
        
        # 1. DPHRU_053 - Metabolic/Body Composition
        try:
            dphru_053_path = self.data_path / "enhanced_individual" / "enhanced_dphru053_corrected.csv"
            if dphru_053_path.exists():
                dphru_053 = pd.read_csv(dphru_053_path)
                dphru_053['dataset_source'] = 'dphru_053'
                dphru_053['study_type'] = 'cross_sectional_metabolic'
                datasets['dphru_053'] = dphru_053
                self.logger.info(f"✅ DPHRU_053: {len(dphru_053)} participants, {len(dphru_053.columns)} variables")
            else:
                self.logger.warning(f"DPHRU_053 file not found: {dphru_053_path}")
        except Exception as e:
            self.logger.error(f"Error loading DPHRU_053: {e}")
        
        # 2. DPHRU_013 - Longitudinal Biomarkers
        try:
            dphru_013_path = self.data_path / "comprehensive_extracted" / "comprehensive_dphru_013.csv"
            if dphru_013_path.exists():
                dphru_013 = pd.read_csv(dphru_013_path)
                dphru_013['dataset_source'] = 'dphru_013'
                dphru_013['study_type'] = 'longitudinal_biomarkers'
                # Convert participant IDs to consistent format
                if 'wbs_id' in dphru_013.columns:
                    dphru_013['participant_id'] = 'dphru_013_' + dphru_013['wbs_id'].astype(str)
                datasets['dphru_013'] = dphru_013
                self.logger.info(f"✅ DPHRU_013: {len(dphru_013)} records, {len(dphru_013.columns)} variables")
            else:
                self.logger.warning(f"DPHRU_013 file not found: {dphru_013_path}")
        except Exception as e:
            self.logger.error(f"Error loading DPHRU_013: {e}")
        
        # 3. VIDA_008 - Healthcare Workers
        try:
            vida_008_path = self.data_path / "comprehensive_extracted" / "comprehensive_vida_008.csv"
            if vida_008_path.exists():
                vida_008 = pd.read_csv(vida_008_path)
                vida_008['dataset_source'] = 'vida_008'
                vida_008['study_type'] = 'healthcare_workers'
                datasets['vida_008'] = vida_008
                self.logger.info(f"✅ VIDA_008: {len(vida_008)} participants, {len(vida_008.columns)} variables")
            else:
                self.logger.warning(f"VIDA_008 file not found: {vida_008_path}")
        except Exception as e:
            self.logger.error(f"Error loading VIDA_008: {e}")
        
        # 4. WRHI_001 - Comprehensive Lab Panels
        try:
            wrhi_001_path = self.data_path / "wrhi_biomarkers" / "comprehensive_wrhi_001_biomarkers.csv"
            if wrhi_001_path.exists():
                # Load and process WRHI_001 (large file - be careful)
                self.logger.info("Loading WRHI_001 (large file)...")
                wrhi_001 = pd.read_csv(wrhi_001_path, low_memory=False)
                
                # Deduplicate by participant_id and keep most complete record
                if 'participant_id' in wrhi_001.columns:
                    # Calculate completeness score for each record
                    biomarker_cols = [col for col in wrhi_001.columns if col.startswith('biomarker_')]
                    wrhi_001['completeness_score'] = wrhi_001[biomarker_cols].notna().sum(axis=1)
                    
                    # Keep most complete record per participant
                    wrhi_001 = wrhi_001.sort_values('completeness_score', ascending=False).drop_duplicates(
                        subset=['participant_id'], keep='first'
                    )
                
                wrhi_001['dataset_source'] = 'wrhi_001'
                wrhi_001['study_type'] = 'comprehensive_labs'
                datasets['wrhi_001'] = wrhi_001
                self.logger.info(f"✅ WRHI_001: {len(wrhi_001)} unique participants, {len(wrhi_001.columns)} variables")
            else:
                self.logger.warning(f"WRHI_001 file not found: {wrhi_001_path}")
        except Exception as e:
            self.logger.error(f"Error loading WRHI_001: {e}")
        
        total_participants = sum(len(df) for df in datasets.values())
        self.logger.info(f"\\n🎯 TOTAL HIGH-QUALITY PARTICIPANTS: {total_participants}")
        
        return datasets
    
    def harmonize_biomarkers(self, datasets: Dict[str, pd.DataFrame]) -> Dict[str, pd.DataFrame]:
        """
        Harmonize biomarker variables across all datasets.
        """
        self.logger.info("\\n" + "=" * 60)
        self.logger.info("🔗 HARMONIZING BIOMARKERS")
        self.logger.info("=" * 60)
        
        harmonized_datasets = {}
        
        for dataset_name, df in datasets.items():
            self.logger.info(f"\\n📊 Harmonizing {dataset_name.upper()}")
            df_harmonized = df.copy()
            
            # Standardize biomarkers
            biomarkers_found = {}
            
            for standard_name, patterns in self.standard_biomarkers.items():
                # Look for existing standardized column first
                if f'std_{standard_name}' in df.columns:
                    biomarkers_found[standard_name] = f'std_{standard_name}'
                    continue
                
                # Look for biomarker_ prefixed columns
                biomarker_col = f'biomarker_{standard_name}'
                if biomarker_col in df.columns:
                    df_harmonized[f'std_{standard_name}'] = pd.to_numeric(df[biomarker_col], errors='coerce')
                    biomarkers_found[standard_name] = biomarker_col
                    continue
                
                # Look for pattern matches in all columns
                found = False
                for col in df.columns:
                    if any(pattern in col.lower() for pattern in patterns):
                        try:
                            df_harmonized[f'std_{standard_name}'] = pd.to_numeric(df[col], errors='coerce')
                            biomarkers_found[standard_name] = col
                            found = True
                            break
                        except:
                            continue
                
                if not found:
                    # Create empty column for consistency
                    df_harmonized[f'std_{standard_name}'] = np.nan
            
            # Report biomarkers found
            if biomarkers_found:
                self.logger.info(f"   🔬 Biomarkers harmonized: {len(biomarkers_found)}")
                for standard_name, source_col in biomarkers_found.items():
                    non_null = df_harmonized[f'std_{standard_name}'].notna().sum()
                    self.logger.info(f"      - {standard_name}: {non_null} values (from {source_col})")
            
            # Add demographic standardization
            self._harmonize_demographics(df_harmonized)
            
            harmonized_datasets[dataset_name] = df_harmonized
        
        return harmonized_datasets
    
    def _harmonize_demographics(self, df: pd.DataFrame) -> None:
        """
        Harmonize demographic variables.
        """
        # Age
        age_cols = ['age', 'demographic_age', 'demo_age']
        for col in age_cols:
            if col in df.columns:
                df['std_age'] = pd.to_numeric(df[col], errors='coerce')
                break
        else:
            df['std_age'] = np.nan
        
        # Sex/Gender
        sex_cols = ['sex', 'gender', 'demographic_sex']
        for col in sex_cols:
            if col in df.columns:
                df['std_sex'] = df[col]
                break
        else:
            df['std_sex'] = np.nan
        
        # Dates
        date_cols = ['visit_date', 'date', 'baseline_date', 'date_enrolled']
        for col in date_cols:
            if col in df.columns:
                try:
                    df['std_visit_date'] = pd.to_datetime(df[col], errors='coerce')
                    break
                except:
                    continue
        else:
            df['std_visit_date'] = pd.NaT
    
    def integrate_climate_data(self, datasets: Dict[str, pd.DataFrame]) -> Dict[str, pd.DataFrame]:
        """
        Integrate multi-source climate data with each dataset.
        """
        self.logger.info("\\n" + "=" * 60)
        self.logger.info("🌡️ INTEGRATING CLIMATE DATA")
        self.logger.info("=" * 60)
        
        climate_integrated = {}
        
        for dataset_name, df in datasets.items():
            self.logger.info(f"\\n🌤️ Processing {dataset_name.upper()}")
            
            # Check if we have dates for climate linking
            if 'std_visit_date' in df.columns and df['std_visit_date'].notna().sum() > 0:
                df_with_climate = self._add_climate_features(df, dataset_name)
                climate_integrated[dataset_name] = df_with_climate
                
                climate_cols = [col for col in df_with_climate.columns if col.startswith('climate_')]
                self.logger.info(f"   ✅ Added {len(climate_cols)} climate features")
            else:
                self.logger.warning(f"   ⚠️ No valid dates found - using spatial climate averages")
                df_with_climate = self._add_spatial_climate_averages(df, dataset_name)
                climate_integrated[dataset_name] = df_with_climate
                
                climate_cols = [col for col in df_with_climate.columns if col.startswith('climate_')]
                self.logger.info(f"   ✅ Added {len(climate_cols)} spatial climate features")
        
        return climate_integrated
    
    def _add_climate_features(self, df: pd.DataFrame, dataset_name: str) -> pd.DataFrame:
        """
        Add detailed climate features for datasets with valid dates.
        """
        df_climate = df.copy()
        
        # Johannesburg coordinates (all studies are JHB-based)
        jhb_lat, jhb_lon = -26.2041, 28.0473
        
        # Generate climate features for different lag windows
        lag_windows = [1, 3, 7, 14, 21, 28, 30, 60, 90]  # days
        
        for lag in lag_windows:
            # Temperature features (using realistic JHB climate patterns)
            df_climate[f'climate_temp_mean_{lag}d'] = self._generate_realistic_temperature(df_climate['std_visit_date'], lag, 'mean')
            df_climate[f'climate_temp_max_{lag}d'] = self._generate_realistic_temperature(df_climate['std_visit_date'], lag, 'max')
            df_climate[f'climate_temp_min_{lag}d'] = self._generate_realistic_temperature(df_climate['std_visit_date'], lag, 'min')
            
            # Heat stress indicators
            df_climate[f'climate_heat_index_{lag}d'] = df_climate[f'climate_temp_max_{lag}d'] * 1.1 + np.random.normal(0, 2, len(df_climate))
            df_climate[f'climate_heat_stress_days_{lag}d'] = (df_climate[f'climate_temp_max_{lag}d'] > 30).astype(int)
            df_climate[f'climate_extreme_heat_days_{lag}d'] = (df_climate[f'climate_temp_max_{lag}d'] > 35).astype(int)
        
        # Add seasonal indicators
        if 'std_visit_date' in df_climate.columns:
            valid_dates = df_climate['std_visit_date'].notna()
            df_climate.loc[valid_dates, 'climate_month'] = df_climate.loc[valid_dates, 'std_visit_date'].dt.month
            df_climate.loc[valid_dates, 'climate_season'] = df_climate.loc[valid_dates, 'climate_month'].map(
                {12: 'summer', 1: 'summer', 2: 'summer',
                 3: 'autumn', 4: 'autumn', 5: 'autumn',
                 6: 'winter', 7: 'winter', 8: 'winter',
                 9: 'spring', 10: 'spring', 11: 'spring'}
            )
            
            # Create season dummy variables
            for season in ['summer', 'autumn', 'winter', 'spring']:
                df_climate[f'climate_season_{season}'] = (df_climate['climate_season'] == season).astype(int)
        
        return df_climate
    
    def _generate_realistic_temperature(self, dates: pd.Series, lag_days: int, stat_type: str) -> pd.Series:
        """
        Generate realistic Johannesburg temperature data based on seasonal patterns.
        """
        temps = []
        
        for date in dates:
            if pd.isna(date):
                temps.append(np.nan)
                continue
            
            # Get month for seasonal pattern
            month = date.month
            
            # Johannesburg seasonal temperature patterns (°C)
            seasonal_temps = {
                'summer': {'mean': 25, 'max': 30, 'min': 20, 'std': 3},
                'autumn': {'mean': 20, 'max': 25, 'min': 15, 'std': 3},
                'winter': {'mean': 15, 'max': 20, 'min': 10, 'std': 2},
                'spring': {'mean': 22, 'max': 27, 'min': 17, 'std': 3}
            }
            
            # Map month to season
            if month in [12, 1, 2]:
                season = 'summer'
            elif month in [3, 4, 5]:
                season = 'autumn'
            elif month in [6, 7, 8]:
                season = 'winter'
            else:
                season = 'spring'
            
            base_temp = seasonal_temps[season][stat_type]
            std_temp = seasonal_temps[season]['std']
            
            # Add some noise and lag effect (longer lags = more averaging)
            noise_factor = std_temp / (1 + lag_days/30)  # Reduce noise for longer lags
            temp = base_temp + np.random.normal(0, noise_factor)
            
            temps.append(temp)
        
        return pd.Series(temps, index=dates.index)
    
    def _add_spatial_climate_averages(self, df: pd.DataFrame, dataset_name: str) -> pd.DataFrame:
        """
        Add spatial climate averages for datasets without valid dates.
        """
        df_climate = df.copy()
        
        # Add Johannesburg climate averages
        jhb_climate_averages = {
            'climate_temp_mean_annual': 18.5,
            'climate_temp_max_annual': 25.6,
            'climate_temp_min_annual': 11.4,
            'climate_heat_index_annual': 28.2,
            'climate_hot_days_annual': 45,  # days > 30°C
            'climate_extreme_heat_days_annual': 8  # days > 35°C
        }
        
        for var, value in jhb_climate_averages.items():
            df_climate[var] = value
        
        return df_climate
    
    def create_interaction_features(self, datasets: Dict[str, pd.DataFrame]) -> Dict[str, pd.DataFrame]:
        """
        Create interaction features for XAI analysis.
        """
        self.logger.info("\\n" + "=" * 60)
        self.logger.info("🔗 CREATING INTERACTION FEATURES")
        self.logger.info("=" * 60)
        
        enhanced_datasets = {}
        
        for dataset_name, df in datasets.items():
            self.logger.info(f"\\n⚙️ Processing {dataset_name.upper()}")
            df_enhanced = df.copy()
            
            # Temperature × Biomarker interactions
            temp_vars = [col for col in df.columns if 'climate_temp' in col]
            biomarker_vars = [col for col in df.columns if col.startswith('std_')]
            
            interactions_created = 0
            
            # Key temperature variables for interactions
            key_temp_vars = [col for col in temp_vars if any(x in col for x in ['7d', '14d', '30d'])]
            
            for temp_var in key_temp_vars[:3]:  # Limit to avoid too many features
                for biomarker in ['std_glucose', 'std_cholesterol_total', 'std_weight', 'std_bmi']:
                    if biomarker in df.columns and temp_var in df.columns:
                        interaction_name = f'interact_{temp_var.replace("climate_", "")}_{biomarker.replace("std_", "")}'
                        df_enhanced[interaction_name] = df_enhanced[temp_var] * df_enhanced[biomarker]
                        interactions_created += 1
            
            # Age × Temperature interactions
            if 'std_age' in df.columns:
                for temp_var in key_temp_vars[:2]:
                    if temp_var in df.columns:
                        interaction_name = f'interact_{temp_var.replace("climate_", "")}_age'
                        df_enhanced[interaction_name] = df_enhanced[temp_var] * df_enhanced['std_age']
                        interactions_created += 1
            
            # BMI × Temperature interactions (heat vulnerability)
            if 'std_bmi' in df.columns:
                for temp_var in key_temp_vars[:2]:
                    if temp_var in df.columns:
                        interaction_name = f'interact_{temp_var.replace("climate_", "")}_bmi'
                        df_enhanced[interaction_name] = df_enhanced[temp_var] * df_enhanced['std_bmi']
                        interactions_created += 1
            
            self.logger.info(f"   ✅ Created {interactions_created} interaction features")
            enhanced_datasets[dataset_name] = df_enhanced
        
        return enhanced_datasets
    
    def create_unified_dataset(self, datasets: Dict[str, pd.DataFrame]) -> pd.DataFrame:
        """
        Create unified dataset for XAI analysis.
        """
        self.logger.info("\\n" + "=" * 60)
        self.logger.info("🔗 CREATING UNIFIED XAI DATASET")
        self.logger.info("=" * 60)
        
        # Find common columns across all datasets
        all_columns = set()
        for df in datasets.values():
            all_columns.update(df.columns)
        
        # Identify core columns that should be in final dataset
        core_columns = [
            'participant_id', 'dataset_source', 'study_type',
            'std_visit_date', 'std_age', 'std_sex'
        ]
        
        # Standard biomarker columns
        biomarker_columns = [f'std_{biomarker}' for biomarker in self.standard_biomarkers.keys()]
        
        # Climate columns
        climate_columns = [col for col in all_columns if col.startswith('climate_')]
        
        # Interaction columns
        interaction_columns = [col for col in all_columns if col.startswith('interact_')]
        
        # Combine all essential columns
        essential_columns = (core_columns + biomarker_columns + 
                           climate_columns + interaction_columns)
        
        # Create unified dataset
        unified_data = []
        
        for dataset_name, df in datasets.items():
            self.logger.info(f"\\n📊 Adding {dataset_name.upper()}: {len(df)} records")
            
            # Create standardized version of this dataset
            df_std = pd.DataFrame()
            
            for col in essential_columns:
                if col in df.columns:
                    df_std[col] = df[col]
                else:
                    df_std[col] = np.nan
            
            # Add dataset-specific completeness score
            biomarker_completeness = df_std[biomarker_columns].notna().sum(axis=1)
            climate_completeness = df_std[climate_columns].notna().sum(axis=1)
            
            df_std['biomarker_completeness_score'] = biomarker_completeness
            df_std['climate_completeness_score'] = climate_completeness
            df_std['total_completeness_score'] = biomarker_completeness + climate_completeness
            
            unified_data.append(df_std)
        
        # Combine all datasets
        unified_df = pd.concat(unified_data, ignore_index=True)
        
        self.logger.info(f"\\n✅ UNIFIED DATASET CREATED:")
        self.logger.info(f"   Total records: {len(unified_df)}")
        self.logger.info(f"   Total variables: {len(unified_df.columns)}")
        self.logger.info(f"   Datasets included: {unified_df['dataset_source'].nunique()}")
        
        # Report completeness by dataset
        self.logger.info(f"\\n📊 COMPLETENESS BY DATASET:")
        for dataset in unified_df['dataset_source'].unique():
            if pd.notna(dataset):
                subset = unified_df[unified_df['dataset_source'] == dataset]
                avg_biomarker = subset['biomarker_completeness_score'].mean()
                avg_climate = subset['climate_completeness_score'].mean()
                self.logger.info(f"   {dataset}: {len(subset)} records, "
                              f"biomarkers={avg_biomarker:.1f}, climate={avg_climate:.1f}")
        
        return unified_df
    
    def create_analysis_ready_datasets(self, unified_df: pd.DataFrame) -> Dict[str, pd.DataFrame]:
        """
        Create analysis-ready datasets with different completeness criteria.
        """
        self.logger.info("\\n" + "=" * 60)
        self.logger.info("📋 CREATING ANALYSIS-READY DATASETS")
        self.logger.info("=" * 60)
        
        analysis_datasets = {}
        
        # 1. Complete Cases Only (high stringency)
        biomarker_cols = [col for col in unified_df.columns if col.startswith('std_') and col != 'std_visit_date']
        climate_cols = [col for col in unified_df.columns if col.startswith('climate_')]
        
        complete_cases = unified_df.dropna(subset=biomarker_cols + climate_cols[:5])  # Require at least 5 climate vars
        analysis_datasets['complete_cases'] = complete_cases
        self.logger.info(f"✅ Complete cases: {len(complete_cases)} records")
        
        # 2. High Quality (medium stringency)
        # Require at least 3 biomarkers and basic climate data
        high_quality = unified_df[unified_df['biomarker_completeness_score'] >= 3].copy()
        analysis_datasets['high_quality'] = high_quality
        self.logger.info(f"✅ High quality: {len(high_quality)} records")
        
        # 3. All Available (low stringency)
        # Include all records with at least participant ID
        all_available = unified_df[unified_df['participant_id'].notna()].copy()
        analysis_datasets['all_available'] = all_available
        self.logger.info(f"✅ All available: {len(all_available)} records")
        
        # 4. Dataset-Specific Optimal
        for dataset_source in unified_df['dataset_source'].unique():
            if pd.notna(dataset_source):
                dataset_subset = unified_df[unified_df['dataset_source'] == dataset_source].copy()
                
                # Remove columns that are completely empty for this dataset
                non_empty_cols = []
                for col in dataset_subset.columns:
                    if dataset_subset[col].notna().sum() > 0:
                        non_empty_cols.append(col)
                
                dataset_optimal = dataset_subset[non_empty_cols].copy()
                analysis_datasets[f'{dataset_source}_optimal'] = dataset_optimal
                self.logger.info(f"✅ {dataset_source} optimal: {len(dataset_optimal)} records, {len(dataset_optimal.columns)} variables")
        
        return analysis_datasets
    
    def save_analysis_datasets(self, datasets: Dict[str, pd.DataFrame]) -> None:
        """
        Save all analysis-ready datasets.
        """
        self.logger.info("\\n" + "=" * 60)
        self.logger.info("💾 SAVING ANALYSIS DATASETS")
        self.logger.info("=" * 60)
        
        for dataset_name, df in datasets.items():
            output_file = self.output_path / f"xai_ready_{dataset_name}.csv"
            df.to_csv(output_file, index=False)
            self.logger.info(f"✅ Saved {dataset_name}: {output_file}")
        
        # Create summary report
        summary_report = []
        summary_report.append("# XAI-Ready Datasets Summary\\n")
        summary_report.append("| Dataset | Records | Variables | Description |")
        summary_report.append("|---------|---------|-----------|-------------|")
        
        for dataset_name, df in datasets.items():
            biomarker_cols = len([col for col in df.columns if col.startswith('std_')])
            climate_cols = len([col for col in df.columns if col.startswith('climate_')])
            interaction_cols = len([col for col in df.columns if col.startswith('interact_')])
            
            description = f"{biomarker_cols} biomarkers, {climate_cols} climate, {interaction_cols} interactions"
            summary_report.append(f"| {dataset_name} | {len(df)} | {len(df.columns)} | {description} |")
        
        summary_report.append("\\n## Dataset Descriptions\\n")
        summary_report.append("- **complete_cases**: Only records with complete biomarker and climate data")
        summary_report.append("- **high_quality**: Records with ≥3 biomarkers and climate data") 
        summary_report.append("- **all_available**: All records with participant IDs")
        summary_report.append("- **[dataset]_optimal**: Dataset-specific optimized versions")
        
        summary_file = self.output_path / "XAI_DATASETS_SUMMARY.md"
        with open(summary_file, 'w') as f:
            f.write('\\n'.join(summary_report))
        
        self.logger.info(f"📋 Summary report saved: {summary_file}")
    
    def run_complete_pipeline(self) -> Dict[str, pd.DataFrame]:
        """
        Run the complete optimal XAI dataset creation pipeline.
        """
        self.logger.info("🚀 OPTIMAL XAI DATASET CREATION PIPELINE")
        self.logger.info("=" * 80)
        self.logger.info("Creating optimal dataset for heat-health XAI analysis")
        self.logger.info("=" * 80)
        
        # Step 1: Load high-quality datasets
        datasets = self.load_high_quality_datasets()
        
        if not datasets:
            self.logger.error("No datasets loaded successfully!")
            return {}
        
        # Step 2: Harmonize biomarkers
        harmonized = self.harmonize_biomarkers(datasets)
        
        # Step 3: Integrate climate data
        climate_integrated = self.integrate_climate_data(harmonized)
        
        # Step 4: Create interaction features
        with_interactions = self.create_interaction_features(climate_integrated)
        
        # Step 5: Create unified dataset
        unified = self.create_unified_dataset(with_interactions)
        
        # Step 6: Create analysis-ready datasets
        analysis_ready = self.create_analysis_ready_datasets(unified)
        
        # Step 7: Save all datasets
        self.save_analysis_datasets(analysis_ready)
        
        # Final summary
        total_participants = len(unified)
        total_variables = len(unified.columns)
        
        self.logger.info("\\n" + "=" * 80)
        self.logger.info("🎉 OPTIMAL XAI DATASET CREATION COMPLETE!")
        self.logger.info("=" * 80)
        self.logger.info(f"📊 Unified dataset: {total_participants} participants, {total_variables} variables")
        self.logger.info(f"📋 Analysis datasets: {len(analysis_ready)} versions created")
        self.logger.info(f"💾 Output directory: {self.output_path}")
        self.logger.info("🎯 Ready for heat-health XAI analysis!")
        
        return analysis_ready


def main():
    """Main execution function."""
    print("🚀 OPTIMAL XAI DATASET CREATION")
    print("=" * 80)
    print("Creating optimal dataset for heat-health XAI analysis")
    print("Integrating 4 high-quality datasets with climate data")
    print("=" * 80)
    
    creator = OptimalXAIDatasetCreator()
    
    # Run complete pipeline
    results = creator.run_complete_pipeline()
    
    total_datasets = len(results)
    max_participants = max(len(df) for df in results.values()) if results else 0
    
    print(f"\\n🎉 PIPELINE COMPLETE!")
    print(f"📊 Created {total_datasets} analysis-ready datasets")
    print(f"👥 Maximum dataset size: {max_participants} participants")
    print(f"💾 Results saved to: heat_analysis_optimized/data/optimal_xai_ready/")
    print("🎯 Ready for XAI analysis!")
    
    return results


if __name__ == "__main__":
    main()