"""
Medium Priority Dataset Extraction

Extracts the remaining medium-priority datasets identified in the discovery phase:
- JHB_ACTG_015 (6,220 records)
- JHB_ACTG_019 (7,479 records)
- JHB_SCHARP_004 (4,402 records)
- Additional ACTG studies (multiple)

These add significant value to the collection while maintaining quality standards.
"""

import pandas as pd
import numpy as np
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any
import logging
from datetime import datetime
import warnings

warnings.filterwarnings('ignore')

class MediumPriorityDatasetExtractor:
    """
    Extracts medium-priority datasets with substantial value for XAI analysis.
    """
    
    def __init__(self, base_path: str = "/home/cparker"):
        self.base_path = Path(base_path)
        self.raw_path = self.base_path / "incoming" / "RP2"
        self.output_path = self.base_path / "heat_analysis_optimized" / "data" / "enhanced_medium_priority"
        
        # Create output directory
        self.output_path.mkdir(parents=True, exist_ok=True)
        
        # Setup logging
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)
        
        # Medium priority datasets identified from discovery
        self.medium_priority_datasets = [
            'JHB_ACTG_015',
            'JHB_ACTG_019', 
            'JHB_SCHARP_004',
            'JHB_ACTG_014',
            'JHB_ACTG_016',
            'JHB_ACTG_017',
            'JHB_ACTG_018'
        ]
        
        # Biomarker patterns for standardization
        self.biomarker_patterns = {
            'glucose': ['glucose', 'gluc', 'blood_sugar', 'fbs'],
            'cholesterol': ['cholesterol', 'chol', 'tc', 'total_chol'],
            'triglycerides': ['triglyceride', 'trig', 'tg'],
            'hdl': ['hdl', 'hdl_c', 'hdl_chol', 'high_density'],
            'ldl': ['ldl', 'ldl_c', 'ldl_chol', 'low_density'],
            'creatinine': ['creatinine', 'creat', 'cr', 'scr'],
            'hemoglobin': ['hemoglobin', 'hgb', 'hb', 'haemoglobin'],
            'wbc': ['wbc', 'white_blood', 'leucocyte', 'leukocyte'],
            'cd4': ['cd4', 'cd4_count', 'cd4count', 'cd4_cells'],
            'viral_load': ['viral_load', 'vl', 'hiv_rna', 'hivrna'],
            'blood_pressure': ['bp', 'blood_pressure', 'systolic', 'diastolic'],
            'weight': ['weight', 'wt', 'body_weight'],
            'height': ['height', 'ht', 'stature'],
            'bmi': ['bmi', 'body_mass_index'],
            'temperature': ['temp', 'temperature', 'fever'],
            'oxygen_saturation': ['spo2', 'oxygen', 'sat'],
            'heart_rate': ['heart_rate', 'hr', 'pulse']
        }
    
    def extract_all_medium_priority_datasets(self) -> Dict[str, pd.DataFrame]:
        """Extract all medium-priority datasets."""
        
        self.logger.info("=" * 80)
        self.logger.info("🟡 MEDIUM PRIORITY DATASET EXTRACTION")
        self.logger.info("=" * 80)
        self.logger.info("Extracting medium-priority datasets to maximize collection:")
        for dataset in self.medium_priority_datasets:
            self.logger.info(f"  - {dataset}")
        self.logger.info("=" * 80)
        
        results = {}
        total_added = 0
        
        for dataset_name in self.medium_priority_datasets:
            self.logger.info(f"\n{'=' * 60}")
            self.logger.info(f"📊 PROCESSING: {dataset_name}")
            self.logger.info(f"{'=' * 60}")
            
            try:
                if dataset_name.startswith('JHB_ACTG'):
                    df = self._extract_actg_dataset(dataset_name)
                elif dataset_name.startswith('JHB_SCHARP'):
                    df = self._extract_scharp_dataset(dataset_name)
                else:
                    df = self._extract_generic_dataset(dataset_name)
                
                if not df.empty:
                    results[dataset_name.lower()] = df
                    total_added += len(df)
                    self.logger.info(f"✅ {dataset_name}: {len(df)} participants extracted")
                else:
                    self.logger.warning(f"⚠️ {dataset_name}: No data extracted")
                    
            except Exception as e:
                self.logger.error(f"❌ {dataset_name}: Extraction failed - {e}")
        
        # Summary
        self.logger.info("\n" + "=" * 80)
        self.logger.info("📊 MEDIUM PRIORITY EXTRACTION SUMMARY")
        self.logger.info("=" * 80)
        
        for dataset_name, df in results.items():
            biomarker_cols = [col for col in df.columns if col.startswith('biomarker_')]
            self.logger.info(f"✅ {dataset_name}:")
            self.logger.info(f"   - Records: {len(df)}")
            self.logger.info(f"   - Variables: {len(df.columns)}")
            self.logger.info(f"   - Biomarkers: {len(biomarker_cols)}")
        
        self.logger.info(f"\n🎯 IMPACT:")
        self.logger.info(f"   - Medium priority datasets extracted: {len(results)}")
        self.logger.info(f"   - Total new participants: {total_added:,}")
        self.logger.info(f"   - Previous collection: 30,065")
        self.logger.info(f"   - NEW TOTAL: {30065 + total_added:,} participants")
        
        return results
    
    def _extract_actg_dataset(self, dataset_name: str) -> pd.DataFrame:
        """Extract ACTG (HIV clinical trial) dataset."""
        
        dataset_path = self.raw_path / dataset_name / "csv"
        
        if not dataset_path.exists():
            self.logger.warning(f"Dataset path not found: {dataset_path}")
            return pd.DataFrame()
        
        csv_files = sorted(dataset_path.glob("*.csv"))
        self.logger.info(f"Found {len(csv_files)} CSV files")
        
        all_data = []
        
        for csv_file in csv_files:
            self.logger.info(f"📄 Processing: {csv_file.name}")
            
            try:
                df = pd.read_csv(csv_file)
                self.logger.info(f"   Loaded: {len(df)} records, {len(df.columns)} columns")
                
                # Check for HIV-specific columns
                hiv_cols = [col for col in df.columns if any(x in col.lower() for x in 
                          ['cd4', 'viral', 'hiv', 'art', 'treatment'])]
                if hiv_cols:
                    self.logger.info(f"   🦠 HIV-specific columns: {len(hiv_cols)}")
                
                # Standardize this file
                standardized = self._standardize_actg_data(df, csv_file.name, dataset_name)
                
                if not standardized.empty and len(standardized) > 10:
                    all_data.append(standardized)
                    
            except Exception as e:
                self.logger.error(f"   Error processing {csv_file.name}: {e}")
        
        # Combine all data
        if all_data:
            combined = pd.concat(all_data, ignore_index=True)
            
            # Remove duplicates
            before = len(combined)
            if 'participant_id' in combined.columns:
                combined = combined.drop_duplicates(subset=['participant_id'])
            after = len(combined)
            
            if before != after:
                self.logger.info(f"Removed {before - after} duplicate records")
            
            # Add ACTG-specific features
            combined = self._add_actg_features(combined)
            
            # Save dataset
            output_file = self.output_path / f"enhanced_{dataset_name.lower()}.csv"
            combined.to_csv(output_file, index=False)
            
            self.logger.info(f"✅ {dataset_name} extraction complete:")
            self.logger.info(f"   Total records: {len(combined)}")
            self.logger.info(f"   Variables: {len(combined.columns)}")
            self.logger.info(f"   Output: {output_file}")
            
            self._report_biomarkers_found(combined)
            
            return combined
        else:
            self.logger.warning(f"No data successfully extracted from {dataset_name}")
            return pd.DataFrame()
    
    def _extract_scharp_dataset(self, dataset_name: str) -> pd.DataFrame:
        """Extract SCHARP (vaccine/prevention) dataset."""
        
        dataset_path = self.raw_path / dataset_name / "csv"
        
        if not dataset_path.exists():
            self.logger.warning(f"Dataset path not found: {dataset_path}")
            return pd.DataFrame()
        
        csv_files = sorted(dataset_path.glob("*.csv"))
        self.logger.info(f"Found {len(csv_files)} CSV files")
        
        all_data = []
        
        for csv_file in csv_files:
            self.logger.info(f"📄 Processing: {csv_file.name}")
            
            try:
                df = pd.read_csv(csv_file)
                self.logger.info(f"   Loaded: {len(df)} records, {len(df.columns)} columns")
                
                # Check for vaccine/immunology columns
                vaccine_cols = [col for col in df.columns if any(x in col.lower() for x in 
                              ['vaccine', 'immun', 'antibody', 'response'])]
                if vaccine_cols:
                    self.logger.info(f"   💉 Vaccine/immunology columns: {len(vaccine_cols)}")
                
                # Standardize this file  
                standardized = self._standardize_scharp_data(df, csv_file.name, dataset_name)
                
                if not standardized.empty and len(standardized) > 10:
                    all_data.append(standardized)
                    
            except Exception as e:
                self.logger.error(f"   Error processing {csv_file.name}: {e}")
        
        # Combine all data
        if all_data:
            combined = pd.concat(all_data, ignore_index=True)
            
            # Remove duplicates
            before = len(combined)
            if 'participant_id' in combined.columns:
                combined = combined.drop_duplicates(subset=['participant_id'])
            after = len(combined)
            
            if before != after:
                self.logger.info(f"Removed {before - after} duplicate records")
            
            # Add SCHARP-specific features
            combined = self._add_scharp_features(combined)
            
            # Save dataset
            output_file = self.output_path / f"enhanced_{dataset_name.lower()}.csv"
            combined.to_csv(output_file, index=False)
            
            self.logger.info(f"✅ {dataset_name} extraction complete:")
            self.logger.info(f"   Total records: {len(combined)}")
            self.logger.info(f"   Variables: {len(combined.columns)}")
            self.logger.info(f"   Output: {output_file}")
            
            self._report_biomarkers_found(combined)
            
            return combined
        else:
            self.logger.warning(f"No data successfully extracted from {dataset_name}")
            return pd.DataFrame()
    
    def _extract_generic_dataset(self, dataset_name: str) -> pd.DataFrame:
        """Extract generic dataset with standard approach."""
        
        dataset_path = self.raw_path / dataset_name / "csv"
        
        if not dataset_path.exists():
            self.logger.warning(f"Dataset path not found: {dataset_path}")
            return pd.DataFrame()
        
        csv_files = sorted(dataset_path.glob("*.csv"))
        self.logger.info(f"Found {len(csv_files)} CSV files")
        
        all_data = []
        
        for csv_file in csv_files:
            self.logger.info(f"📄 Processing: {csv_file.name}")
            
            try:
                df = pd.read_csv(csv_file)
                self.logger.info(f"   Loaded: {len(df)} records, {len(df.columns)} columns")
                
                # Standardize this file
                standardized = self._standardize_generic_data(df, csv_file.name, dataset_name)
                
                if not standardized.empty and len(standardized) > 10:
                    all_data.append(standardized)
                    
            except Exception as e:
                self.logger.error(f"   Error processing {csv_file.name}: {e}")
        
        # Combine all data
        if all_data:
            combined = pd.concat(all_data, ignore_index=True)
            
            # Remove duplicates
            before = len(combined)
            if 'participant_id' in combined.columns:
                combined = combined.drop_duplicates(subset=['participant_id'])
            after = len(combined)
            
            if before != after:
                self.logger.info(f"Removed {before - after} duplicate records")
            
            # Save dataset
            output_file = self.output_path / f"enhanced_{dataset_name.lower()}.csv"
            combined.to_csv(output_file, index=False)
            
            self.logger.info(f"✅ {dataset_name} extraction complete:")
            self.logger.info(f"   Total records: {len(combined)}")
            self.logger.info(f"   Variables: {len(combined.columns)}")
            self.logger.info(f"   Output: {output_file}")
            
            self._report_biomarkers_found(combined)
            
            return combined
        else:
            self.logger.warning(f"No data successfully extracted from {dataset_name}")
            return pd.DataFrame()
    
    def _standardize_actg_data(self, df: pd.DataFrame, source_file: str, dataset_name: str) -> pd.DataFrame:
        """Standardize ACTG HIV clinical trial data."""
        standardized = pd.DataFrame()
        
        # Add metadata
        standardized['dataset_name'] = dataset_name.lower()
        standardized['source_file'] = source_file
        
        # Participant ID
        id_found = False
        for id_pattern in ['id', 'pid', 'participant', 'subject', 'usubjid']:
            matching_cols = [col for col in df.columns if id_pattern in col.lower() and 'date' not in col.lower()]
            if matching_cols:
                standardized['participant_id'] = f"{dataset_name.lower()}_" + df[matching_cols[0]].astype(str)
                id_found = True
                break
        
        if not id_found:
            standardized['participant_id'] = [f"{dataset_name.lower()}_{i:05d}" for i in range(len(df))]
        
        # Date standardization
        for date_pattern in ['date', 'visit', 'lbdtc', 'rfstdtc']:
            matching_cols = [col for col in df.columns if date_pattern in col.lower()]
            if matching_cols:
                try:
                    standardized['visit_date'] = pd.to_datetime(df[matching_cols[0]], errors='coerce')
                    break
                except:
                    pass
        
        # Demographics
        if 'age' in df.columns:
            standardized['demographic_age'] = pd.to_numeric(df['age'], errors='coerce')
        
        for gender_col in ['gender', 'sex']:
            if gender_col in df.columns:
                standardized['demographic_sex'] = df[gender_col]
                break
        
        # Standardize biomarkers using patterns
        for biomarker_type, patterns in self.biomarker_patterns.items():
            for col in df.columns:
                if any(pattern in col.lower() for pattern in patterns):
                    std_name = f'biomarker_{biomarker_type}'
                    try:
                        standardized[std_name] = pd.to_numeric(df[col], errors='coerce')
                        break
                    except:
                        pass
        
        # HIV-specific indicators
        for col in df.columns:
            if any(x in col.lower() for x in ['cd4', 'viral', 'hiv', 'art']):
                try:
                    standardized[f'hiv_{col.lower()}'] = pd.to_numeric(df[col], errors='coerce')
                except:
                    standardized[f'hiv_{col.lower()}'] = df[col]
        
        return standardized
    
    def _standardize_scharp_data(self, df: pd.DataFrame, source_file: str, dataset_name: str) -> pd.DataFrame:
        """Standardize SCHARP vaccine/prevention data."""
        standardized = pd.DataFrame()
        
        # Add metadata
        standardized['dataset_name'] = dataset_name.lower()
        standardized['source_file'] = source_file
        
        # Participant ID
        id_found = False
        for id_pattern in ['id', 'pid', 'participant', 'subject']:
            matching_cols = [col for col in df.columns if id_pattern in col.lower() and 'date' not in col.lower()]
            if matching_cols:
                standardized['participant_id'] = f"{dataset_name.lower()}_" + df[matching_cols[0]].astype(str)
                id_found = True
                break
        
        if not id_found:
            standardized['participant_id'] = [f"{dataset_name.lower()}_{i:05d}" for i in range(len(df))]
        
        # Date standardization
        for date_pattern in ['date', 'visit', 'vaccination']:
            matching_cols = [col for col in df.columns if date_pattern in col.lower()]
            if matching_cols:
                try:
                    standardized['visit_date'] = pd.to_datetime(df[matching_cols[0]], errors='coerce')
                    break
                except:
                    pass
        
        # Demographics
        if 'age' in df.columns:
            standardized['demographic_age'] = pd.to_numeric(df['age'], errors='coerce')
        
        for gender_col in ['gender', 'sex']:
            if gender_col in df.columns:
                standardized['demographic_sex'] = df[gender_col]
                break
        
        # Standardize biomarkers
        for biomarker_type, patterns in self.biomarker_patterns.items():
            for col in df.columns:
                if any(pattern in col.lower() for pattern in patterns):
                    std_name = f'biomarker_{biomarker_type}'
                    try:
                        standardized[std_name] = pd.to_numeric(df[col], errors='coerce')
                        break
                    except:
                        pass
        
        # Vaccine-specific indicators
        for col in df.columns:
            if any(x in col.lower() for x in ['vaccine', 'immun', 'antibody', 'response']):
                try:
                    standardized[f'vaccine_{col.lower()}'] = pd.to_numeric(df[col], errors='coerce')
                except:
                    standardized[f'vaccine_{col.lower()}'] = df[col]
        
        return standardized
    
    def _standardize_generic_data(self, df: pd.DataFrame, source_file: str, dataset_name: str) -> pd.DataFrame:
        """Standardize generic dataset."""
        standardized = pd.DataFrame()
        
        # Add metadata
        standardized['dataset_name'] = dataset_name.lower()
        standardized['source_file'] = source_file
        
        # Participant ID
        id_found = False
        for id_pattern in ['id', 'pid', 'participant', 'subject']:
            matching_cols = [col for col in df.columns if id_pattern in col.lower() and 'date' not in col.lower()]
            if matching_cols:
                standardized['participant_id'] = f"{dataset_name.lower()}_" + df[matching_cols[0]].astype(str)
                id_found = True
                break
        
        if not id_found:
            standardized['participant_id'] = [f"{dataset_name.lower()}_{i:05d}" for i in range(len(df))]
        
        # Date standardization
        for date_pattern in ['date', 'visit']:
            matching_cols = [col for col in df.columns if date_pattern in col.lower()]
            if matching_cols:
                try:
                    standardized['visit_date'] = pd.to_datetime(df[matching_cols[0]], errors='coerce')
                    break
                except:
                    pass
        
        # Demographics
        if 'age' in df.columns:
            standardized['demographic_age'] = pd.to_numeric(df['age'], errors='coerce')
        
        for gender_col in ['gender', 'sex']:
            if gender_col in df.columns:
                standardized['demographic_sex'] = df[gender_col]
                break
        
        # Standardize biomarkers
        for biomarker_type, patterns in self.biomarker_patterns.items():
            for col in df.columns:
                if any(pattern in col.lower() for pattern in patterns):
                    std_name = f'biomarker_{biomarker_type}'
                    try:
                        standardized[std_name] = pd.to_numeric(df[col], errors='coerce')
                        break
                    except:
                        pass
        
        return standardized
    
    def _add_actg_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Add ACTG-specific features."""
        
        # HIV clinical trial indicators
        df['study_type_hiv_clinical_trial'] = 1
        df['study_design_randomized'] = 1  # ACTG studies are typically randomized
        
        # Treatment response indicators
        hiv_cols = [col for col in df.columns if col.startswith('hiv_')]
        if hiv_cols:
            df['hiv_biomarkers_available'] = df[hiv_cols].notna().sum(axis=1)
        
        return df
    
    def _add_scharp_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Add SCHARP-specific features."""
        
        # Vaccine/prevention study indicators
        df['study_type_vaccine_prevention'] = 1
        
        # Immunology indicators
        vaccine_cols = [col for col in df.columns if col.startswith('vaccine_')]
        if vaccine_cols:
            df['vaccine_biomarkers_available'] = df[vaccine_cols].notna().sum(axis=1)
        
        return df
    
    def _report_biomarkers_found(self, df: pd.DataFrame) -> None:
        """Report biomarkers found in dataset."""
        biomarker_cols = [col for col in df.columns if col.startswith('biomarker_')]
        
        if biomarker_cols:
            self.logger.info(f"🔬 Biomarkers found: {len(biomarker_cols)}")
            for col in sorted(biomarker_cols):
                non_missing = df[col].notna().sum()
                if non_missing > 0:
                    self.logger.info(f"   - {col}: {non_missing} values")


def main():
    """Main execution function."""
    print("🟡 MEDIUM PRIORITY DATASET EXTRACTION")
    print("=" * 80)
    print("Extracting remaining medium-priority datasets to maximize collection")
    print("=" * 80)
    
    extractor = MediumPriorityDatasetExtractor()
    
    # Extract all medium-priority datasets
    results = extractor.extract_all_medium_priority_datasets()
    
    total_added = sum(len(df) for df in results.values())
    
    print(f"\n🎉 MEDIUM PRIORITY EXTRACTION COMPLETE!")
    print(f"📊 Successfully extracted {len(results)} additional datasets")
    print(f"👥 Added {total_added:,} participants")
    print(f"🎯 New total collection: {30065 + total_added:,} participants")
    print(f"💾 Files saved to: heat_analysis_optimized/data/enhanced_medium_priority/")
    
    return results


if __name__ == "__main__":
    main()