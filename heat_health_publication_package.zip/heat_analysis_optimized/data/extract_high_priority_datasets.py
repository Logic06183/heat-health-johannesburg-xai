"""
High Priority Dataset Extraction

Extracts the two highest-value additional datasets discovered:
1. JHB_Aurum_009 - Mining/Occupational Health (19,561 records, 8 biomarkers)
2. JHB_VIDA_008 - COVID Vaccine Study (22,883 records, 9 biomarkers)

These add 42,444 participants to our collection, increasing total to 58,367!
"""

import pandas as pd
import numpy as np
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any
import logging
from datetime import datetime
import warnings

warnings.filterwarnings('ignore')

class HighPriorityDatasetExtractor:
    """
    Extracts high-priority datasets with maximum value for XAI analysis.
    """
    
    def __init__(self, base_path: str = "/home/cparker"):
        self.base_path = Path(base_path)
        self.raw_path = self.base_path / "incoming" / "RP2"
        self.output_path = self.base_path / "heat_analysis_optimized" / "data" / "enhanced_high_priority"
        
        # Create output directory
        self.output_path.mkdir(parents=True, exist_ok=True)
        
        # Setup logging
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)
        
        # Biomarker patterns for standardization
        self.biomarker_patterns = {
            'glucose': ['glucose', 'gluc', 'blood_sugar', 'fbs'],
            'cholesterol': ['cholesterol', 'chol', 'tc', 'total_chol'],
            'triglycerides': ['triglyceride', 'trig', 'tg'],
            'hdl': ['hdl', 'hdl_c', 'hdl_chol', 'high_density'],
            'ldl': ['ldl', 'ldl_c', 'ldl_chol', 'low_density'],
            'creatinine': ['creatinine', 'creat', 'cr', 'scr'],
            'hemoglobin': ['hemoglobin', 'hgb', 'hb', 'haemoglobin'],
            'wbc': ['wbc', 'white_blood', 'leucocyte', 'leukocyte'],
            'cd4': ['cd4', 'cd4_count', 'cd4count', 'cd4_cells'],
            'viral_load': ['viral_load', 'vl', 'hiv_rna', 'hivrna'],
            'blood_pressure': ['bp', 'blood_pressure', 'systolic', 'diastolic'],
            'weight': ['weight', 'wt', 'body_weight'],
            'height': ['height', 'ht', 'stature'],
            'bmi': ['bmi', 'body_mass_index'],
            'temperature': ['temp', 'temperature', 'fever'],
            'oxygen_saturation': ['spo2', 'oxygen', 'sat'],
            'heart_rate': ['heart_rate', 'hr', 'pulse']
        }
    
    def extract_jhb_aurum_009(self) -> pd.DataFrame:
        """
        Extract JHB_Aurum_009 - Mining/Occupational Health Study.
        
        Aurum Institute - Mining health focus
        19,561 records across 22 CSV files
        8 biomarkers identified
        Unique: Occupational health, respiratory health, mining exposure
        """
        self.logger.info("\n" + "="*60)
        self.logger.info("DATASET: JHB_Aurum_009 - Mining/Occupational Health")
        self.logger.info("="*60)
        self.logger.info("🏭 UNIQUE FEATURES: Occupational health, mining exposure, respiratory data")
        
        dataset_path = self.raw_path / "JHB_Aurum_009" / "csv"
        
        if not dataset_path.exists():
            self.logger.error(f"Dataset path not found: {dataset_path}")
            return pd.DataFrame()
        
        csv_files = sorted(dataset_path.glob("*.csv"))
        self.logger.info(f"Found {len(csv_files)} CSV files")
        
        all_data = []
        file_summaries = {}
        
        for csv_file in csv_files:
            self.logger.info(f"\n📄 Processing: {csv_file.name}")
            
            try:
                df = pd.read_csv(csv_file)
                self.logger.info(f"   Loaded: {len(df)} records, {len(df.columns)} columns")
                
                # Analyze for occupational health indicators
                occupational_cols = [col for col in df.columns if any(x in col.lower() for x in 
                                   ['mining', 'dust', 'exposure', 'respiratory', 'lung', 'silica', 'occupational'])]
                if occupational_cols:
                    self.logger.info(f"   🏭 Occupational health columns: {len(occupational_cols)}")
                
                # Standardize this file
                standardized = self._standardize_aurum_data(df, csv_file.name)
                
                if not standardized.empty and len(standardized) > 50:  # Only substantial files
                    all_data.append(standardized)
                    file_summaries[csv_file.name] = {
                        'records': len(df),
                        'occupational_features': len(occupational_cols),
                        'biomarkers': len([col for col in standardized.columns if col.startswith('biomarker_')])
                    }
                    
            except Exception as e:
                self.logger.error(f"   Error processing {csv_file.name}: {e}")
        
        # Combine all data
        if all_data:
            combined = pd.concat(all_data, ignore_index=True)
            
            # Remove duplicates
            before = len(combined)
            if 'participant_id' in combined.columns:
                combined = combined.drop_duplicates(subset=['participant_id'])
            after = len(combined)
            
            if before != after:
                self.logger.info(f"Removed {before - after} duplicate records")
            
            # Add occupational-specific features
            combined = self._add_occupational_features(combined)
            
            # Save dataset
            output_file = self.output_path / "enhanced_jhb_aurum_009.csv"
            combined.to_csv(output_file, index=False)
            
            self.logger.info(f"\n✅ JHB_Aurum_009 extraction complete:")
            self.logger.info(f"   Total records: {len(combined)}")
            self.logger.info(f"   Variables: {len(combined.columns)}")
            self.logger.info(f"   Output: {output_file}")
            
            # Report unique occupational features
            occupational_features = [col for col in combined.columns if any(x in col.lower() for x in 
                                   ['mining', 'occupational', 'respiratory', 'exposure'])]
            if occupational_features:
                self.logger.info(f"   🏭 Occupational features: {len(occupational_features)}")
            
            self._report_biomarkers_found(combined)
            
            return combined
        else:
            self.logger.warning("No data successfully extracted from JHB_Aurum_009")
            return pd.DataFrame()
    
    def extract_jhb_vida_008(self) -> pd.DataFrame:
        """
        Extract JHB_VIDA_008 - COVID Healthcare Worker Study.
        
        VIDA COVID vaccine study in healthcare workers
        22,883 records across 4 CSV files (largest single file: 19,531 records!)
        9 biomarkers identified
        Unique: COVID vaccine research, healthcare workers, comprehensive safety data
        """
        self.logger.info("\n" + "="*60)
        self.logger.info("DATASET: JHB_VIDA_008 - COVID Healthcare Worker Study")
        self.logger.info("="*60)
        self.logger.info("💉 UNIQUE FEATURES: COVID vaccine research, healthcare workers, safety monitoring")
        
        dataset_path = self.raw_path / "JHB_VIDA_008" / "csv"
        
        if not dataset_path.exists():
            self.logger.error(f"Dataset path not found: {dataset_path}")
            return pd.DataFrame()
        
        csv_files = sorted(dataset_path.glob("*.csv"))
        self.logger.info(f"Found {len(csv_files)} CSV files")
        
        all_data = []
        
        for csv_file in csv_files:
            self.logger.info(f"\n📄 Processing: {csv_file.name}")
            
            try:
                df = pd.read_csv(csv_file)
                self.logger.info(f"   Loaded: {len(df)} records, {len(df.columns)} columns")
                
                # Check for COVID/vaccine specific columns
                covid_cols = [col for col in df.columns if any(x in col.lower() for x in 
                            ['covid', 'vaccine', 'dose', 'pfizer', 'moderna', 'johnson', 'astrazeneca', 'adverse'])]
                if covid_cols:
                    self.logger.info(f"   💉 COVID/vaccine columns: {len(covid_cols)}")
                
                # Check for healthcare worker indicators
                hcw_cols = [col for col in df.columns if any(x in col.lower() for x in 
                          ['healthcare', 'worker', 'staff', 'nurse', 'doctor', 'hospital'])]
                if hcw_cols:
                    self.logger.info(f"   🏥 Healthcare worker columns: {len(hcw_cols)}")
                
                # Standardize
                standardized = self._standardize_vida_data(df, csv_file.name)
                
                if not standardized.empty:
                    all_data.append(standardized)
                    
            except Exception as e:
                self.logger.error(f"   Error processing {csv_file.name}: {e}")
        
        # Combine all data
        if all_data:
            combined = pd.concat(all_data, ignore_index=True)
            
            # Remove duplicates
            before = len(combined)
            if 'participant_id' in combined.columns:
                combined = combined.drop_duplicates(subset=['participant_id'])
            after = len(combined)
            
            if before != after:
                self.logger.info(f"Removed {before - after} duplicate records")
            
            # Add COVID/vaccine-specific features
            combined = self._add_covid_vaccine_features(combined)
            
            # Save dataset
            output_file = self.output_path / "enhanced_jhb_vida_008.csv"
            combined.to_csv(output_file, index=False)
            
            self.logger.info(f"\n✅ JHB_VIDA_008 extraction complete:")
            self.logger.info(f"   Total records: {len(combined)}")
            self.logger.info(f"   Variables: {len(combined.columns)}")
            self.logger.info(f"   Output: {output_file}")
            
            # Report unique COVID features
            covid_features = [col for col in combined.columns if any(x in col.lower() for x in 
                            ['covid', 'vaccine', 'dose', 'adverse'])]
            if covid_features:
                self.logger.info(f"   💉 COVID/vaccine features: {len(covid_features)}")
            
            self._report_biomarkers_found(combined)
            
            return combined
        else:
            self.logger.warning("No data successfully extracted from JHB_VIDA_008")
            return pd.DataFrame()
    
    def _standardize_aurum_data(self, df: pd.DataFrame, source_file: str) -> pd.DataFrame:
        """Standardize Aurum occupational health data."""
        standardized = pd.DataFrame()
        
        # Add metadata
        standardized['dataset_name'] = 'jhb_aurum_009'
        standardized['source_file'] = source_file
        
        # Participant ID
        id_found = False
        for id_pattern in ['id', 'pid', 'participant', 'subject', 'patient', 'worker']:
            matching_cols = [col for col in df.columns if id_pattern in col.lower() and 'date' not in col.lower()]
            if matching_cols:
                standardized['participant_id'] = 'aurum_009_' + df[matching_cols[0]].astype(str)
                id_found = True
                break
        
        if not id_found:
            standardized['participant_id'] = [f"aurum_009_{i:05d}" for i in range(len(df))]
        
        # Date standardization
        date_found = False
        for date_pattern in ['date', 'visit', 'collection', 'exam']:
            matching_cols = [col for col in df.columns if date_pattern in col.lower()]
            if matching_cols:
                try:
                    standardized['visit_date'] = pd.to_datetime(df[matching_cols[0]], errors='coerce')
                    date_found = True
                    break
                except:
                    pass
        
        # Demographics
        if 'age' in df.columns:
            standardized['demographic_age'] = pd.to_numeric(df['age'], errors='coerce')
        
        for gender_col in ['gender', 'sex']:
            if gender_col in df.columns:
                standardized['demographic_sex'] = df[gender_col]
                break
        
        # Standardize biomarkers using patterns
        for biomarker_type, patterns in self.biomarker_patterns.items():
            for col in df.columns:
                if any(pattern in col.lower() for pattern in patterns):
                    std_name = f'biomarker_{biomarker_type}'
                    try:
                        standardized[std_name] = pd.to_numeric(df[col], errors='coerce')
                        break
                    except:
                        pass
        
        # Occupational health indicators
        for col in df.columns:
            if any(x in col.lower() for x in ['mining', 'dust', 'exposure', 'respiratory', 'lung']):
                try:
                    standardized[f'occupational_{col.lower()}'] = pd.to_numeric(df[col], errors='coerce')
                except:
                    standardized[f'occupational_{col.lower()}'] = df[col]
        
        return standardized
    
    def _standardize_vida_data(self, df: pd.DataFrame, source_file: str) -> pd.DataFrame:
        """Standardize VIDA COVID vaccine data."""
        standardized = pd.DataFrame()
        
        # Add metadata
        standardized['dataset_name'] = 'jhb_vida_008'
        standardized['source_file'] = source_file
        
        # Participant ID
        id_found = False
        for id_pattern in ['id', 'pid', 'participant', 'subject', 'record']:
            matching_cols = [col for col in df.columns if id_pattern in col.lower() and 'date' not in col.lower()]
            if matching_cols:
                standardized['participant_id'] = 'vida_008_' + df[matching_cols[0]].astype(str)
                id_found = True
                break
        
        if not id_found:
            standardized['participant_id'] = [f"vida_008_{i:05d}" for i in range(len(df))]
        
        # Date standardization
        for date_pattern in ['date', 'visit', 'vaccination', 'timestamp']:
            matching_cols = [col for col in df.columns if date_pattern in col.lower()]
            if matching_cols:
                try:
                    standardized['visit_date'] = pd.to_datetime(df[matching_cols[0]], errors='coerce')
                    break
                except:
                    pass
        
        # Demographics
        if 'age' in df.columns:
            standardized['demographic_age'] = pd.to_numeric(df['age'], errors='coerce')
        
        for gender_col in ['gender', 'sex']:
            if gender_col in df.columns:
                standardized['demographic_sex'] = df[gender_col]
                break
        
        # Standardize biomarkers
        for biomarker_type, patterns in self.biomarker_patterns.items():
            for col in df.columns:
                if any(pattern in col.lower() for pattern in patterns):
                    std_name = f'biomarker_{biomarker_type}'
                    try:
                        standardized[std_name] = pd.to_numeric(df[col], errors='coerce')
                        break
                    except:
                        pass
        
        # COVID/vaccine specific indicators
        for col in df.columns:
            if any(x in col.lower() for x in ['covid', 'vaccine', 'dose', 'adverse', 'symptom']):
                col_name = f'covid_{col.lower().replace(" ", "_")}'
                try:
                    standardized[col_name] = pd.to_numeric(df[col], errors='coerce')
                except:
                    standardized[col_name] = df[col]
        
        return standardized
    
    def _add_occupational_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Add occupational health-specific features."""
        
        # Mining exposure categories
        exposure_cols = [col for col in df.columns if any(x in col.lower() for x in ['dust', 'exposure', 'mining'])]
        if exposure_cols:
            df['occupational_exposure_score'] = df[exposure_cols].notna().sum(axis=1)
        
        # Respiratory health indicators  
        respiratory_cols = [col for col in df.columns if any(x in col.lower() for x in ['lung', 'respiratory', 'breathing'])]
        if respiratory_cols:
            df['respiratory_health_indicators'] = respiratory_cols[0] if len(respiratory_cols) == 1 else df[respiratory_cols].mean(axis=1)
        
        # Years of mining exposure (if available)
        years_cols = [col for col in df.columns if 'year' in col.lower() and any(x in col.lower() for x in ['work', 'employment', 'mining'])]
        if years_cols:
            df['occupational_years_exposure'] = df[years_cols[0]]
        
        return df
    
    def _add_covid_vaccine_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Add COVID vaccine-specific features."""
        
        # Vaccine dose indicators
        dose_cols = [col for col in df.columns if 'dose' in col.lower()]
        if dose_cols:
            df['covid_total_doses'] = df[dose_cols].notna().sum(axis=1)
        
        # Adverse event indicators
        adverse_cols = [col for col in df.columns if any(x in col.lower() for x in ['adverse', 'side_effect', 'reaction'])]
        if adverse_cols:
            df['covid_adverse_events_count'] = df[adverse_cols].notna().sum(axis=1)
        
        # Healthcare worker category
        df['covid_healthcare_worker'] = 1  # All participants are healthcare workers
        
        # Vaccine type (if determinable from data)
        vaccine_cols = [col for col in df.columns if any(x in col.lower() for x in ['pfizer', 'moderna', 'johnson', 'astrazeneca'])]
        if vaccine_cols:
            df['covid_vaccine_type_available'] = 1
        
        return df
    
    def _report_biomarkers_found(self, df: pd.DataFrame) -> None:
        """Report biomarkers found in dataset."""
        biomarker_cols = [col for col in df.columns if col.startswith('biomarker_')]
        
        if biomarker_cols:
            self.logger.info(f"\n🔬 Biomarkers found: {len(biomarker_cols)}")
            for col in sorted(biomarker_cols):
                non_missing = df[col].notna().sum()
                if non_missing > 0:
                    self.logger.info(f"   - {col}: {non_missing} values")
    
    def extract_both_high_priority_datasets(self) -> Dict[str, pd.DataFrame]:
        """Extract both high-priority datasets."""
        
        self.logger.info("="*80)
        self.logger.info("🚀 HIGH PRIORITY DATASET EXTRACTION")
        self.logger.info("="*80)
        self.logger.info("Extracting 2 highest-value datasets:")
        self.logger.info("- JHB_Aurum_009: 19,561 records (Mining/Occupational)")
        self.logger.info("- JHB_VIDA_008: 22,883 records (COVID Vaccine)")
        self.logger.info("Total addition: 42,444 participants!")
        self.logger.info("="*80)
        
        results = {}
        
        # Extract Aurum (Mining/Occupational Health)
        try:
            aurum = self.extract_jhb_aurum_009()
            if not aurum.empty:
                results['jhb_aurum_009'] = aurum
        except Exception as e:
            self.logger.error(f"Aurum extraction failed: {e}")
        
        # Extract VIDA (COVID Vaccine)
        try:
            vida = self.extract_jhb_vida_008()
            if not vida.empty:
                results['jhb_vida_008'] = vida
        except Exception as e:
            self.logger.error(f"VIDA extraction failed: {e}")
        
        # Summary
        total_participants = sum(len(df) for df in results.values())
        
        self.logger.info("\n" + "="*80)
        self.logger.info("📊 HIGH PRIORITY EXTRACTION SUMMARY")
        self.logger.info("="*80)
        
        for dataset_name, df in results.items():
            biomarker_cols = [col for col in df.columns if col.startswith('biomarker_')]
            unique_cols = [col for col in df.columns if any(x in col.lower() for x in 
                         ['occupational', 'covid', 'mining', 'vaccine'])]
            
            self.logger.info(f"\n✅ {dataset_name}:")
            self.logger.info(f"   - Records: {len(df)}")
            self.logger.info(f"   - Variables: {len(df.columns)}")
            self.logger.info(f"   - Biomarkers: {len(biomarker_cols)}")
            self.logger.info(f"   - Unique features: {len(unique_cols)}")
        
        self.logger.info(f"\n🎯 IMPACT:")
        self.logger.info(f"   - High priority datasets extracted: {len(results)}")
        self.logger.info(f"   - Total new participants: {total_participants:,}")
        self.logger.info(f"   - Previous collection: 15,923")
        self.logger.info(f"   - NEW TOTAL: {15923 + total_participants:,} participants")
        
        return results


def main():
    """Main execution function."""
    print("🚀 HIGH PRIORITY DATASET EXTRACTION")
    print("="*80)
    print("Extracting highest-value datasets:")
    print("- JHB_Aurum_009: Mining/Occupational Health")  
    print("- JHB_VIDA_008: COVID Vaccine Study")
    print("Target: 42,444 additional participants!")
    print("="*80)
    
    extractor = HighPriorityDatasetExtractor()
    
    # Extract both high-priority datasets
    results = extractor.extract_both_high_priority_datasets()
    
    total_added = sum(len(df) for df in results.values())
    
    print(f"\n🎉 HIGH PRIORITY EXTRACTION COMPLETE!")
    print(f"📊 Successfully extracted {len(results)} datasets")
    print(f"👥 Added {total_added:,} participants")
    print(f"🎯 New total collection: {15923 + total_added:,} participants")
    print(f"💾 Files saved to: heat_analysis_optimized/data/enhanced_high_priority/")
    
    return results


if __name__ == "__main__":
    main()