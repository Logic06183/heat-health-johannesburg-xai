"""
Enhanced Socio-Economic Extractor

Extracts GCRO data from all available years with better encoding handling
and creates comprehensive SE integration with heat-health data.
"""

import pandas as pd
import numpy as np
from pathlib import Path
import logging
import warnings
from typing import Dict, List, Optional, Tuple, Any

warnings.filterwarnings('ignore')

class EnhancedSEExtractor:
    """
    Enhanced extractor for GCRO socio-economic data.
    """
    
    def __init__(self, base_path: str = "/home/cparker"):
        self.base_path = Path(base_path)
        self.se_path = self.base_path / "selected_data_all" / "data" / "socio-economic" / "RP2" / "JHB" / "GCRO" / "quailty_of_life"
        self.output_path = self.base_path / "heat_analysis_optimized" / "data" / "enhanced_se_integrated"
        
        # Create output directory
        self.output_path.mkdir(parents=True, exist_ok=True)
        
        # Setup logging
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)
    
    def extract_all_gcro_data(self) -> Dict[str, pd.DataFrame]:
        """
        Extract GCRO data from all available years with better handling.
        """
        self.logger.info("=" * 80)
        self.logger.info("🔍 ENHANCED GCRO DATA EXTRACTION")
        self.logger.info("=" * 80)
        
        gcro_datasets = {}
        
        # Define known file locations
        data_files = {
            '2013-2014': self.se_path / "2013-2014" / "native" / "qols-iii-2013-2014-v1-csv" / "qol-iii-2013-2014-v1.csv",
            '2017-2018': self.se_path / "2017-2018" / "native" / "gcro-qols-v-v1.1" / "qols-v-2017-2018-v1.1.csv",
            '2020-2021': self.se_path / "2020-2021" / "native" / "qols-2020-2021-v1" / "qols-2020-2021-new-weights-v1.csv"
        }
        
        for year, file_path in data_files.items():
            self.logger.info(f"\\n📅 EXTRACTING: {year}")
            
            if file_path.exists():
                try:
                    # Try different encodings
                    for encoding in ['utf-8', 'latin-1', 'cp1252', 'iso-8859-1']:
                        try:
                            df = pd.read_csv(file_path, encoding=encoding, low_memory=False)
                            self.logger.info(f"   ✅ Loaded with {encoding}: {len(df)} records, {len(df.columns)} variables")
                            
                            # Extract key SE features
                            se_df = self._extract_comprehensive_se_features(df, year)
                            if not se_df.empty:
                                gcro_datasets[year] = se_df
                                self.logger.info(f"   📊 SE features: {len(se_df.columns)} variables")
                            break
                            
                        except UnicodeDecodeError:
                            continue
                        except Exception as e:
                            self.logger.error(f"   Error with {encoding}: {e}")
                            continue
                    else:
                        self.logger.error(f"   Could not read file with any encoding")
                        
                except Exception as e:
                    self.logger.error(f"   Error loading {year}: {e}")
            else:
                self.logger.warning(f"   File not found: {file_path}")
        
        self.logger.info(f"\\n✅ Successfully extracted {len(gcro_datasets)} GCRO datasets")
        return gcro_datasets
    
    def _extract_comprehensive_se_features(self, df: pd.DataFrame, year: str) -> pd.DataFrame:
        """
        Extract comprehensive socio-economic features from GCRO data.
        """
        se_df = pd.DataFrame()
        
        # Basic metadata
        se_df['participant_id'] = [f"gcro_{year}_{i:05d}" for i in range(len(df))]
        se_df['se_survey_year'] = year
        se_df['se_data_source'] = 'gcro_qols'
        
        # Income variables (multiple approaches)
        income_patterns = ['income', 'earn', 'wage', 'salary', 'household_income', 'personal_income']
        income_found = 0
        
        for col in df.columns:
            col_lower = col.lower()
            if any(pattern in col_lower for pattern in income_patterns):
                try:
                    # Try to extract numeric income
                    if df[col].dtype in ['int64', 'float64']:
                        se_df[f'se_income_{income_found}'] = df[col]
                        income_found += 1
                    elif 'income' in col_lower:
                        # Try to convert categorical income to numeric
                        income_numeric = self._convert_categorical_income(df[col])
                        if income_numeric is not None:
                            se_df[f'se_income_cat_{income_found}'] = income_numeric
                            income_found += 1
                except:
                    pass
        
        # Employment variables
        employment_patterns = ['employ', 'job', 'work', 'occupation', 'unemployed']
        employment_found = 0
        
        for col in df.columns:
            col_lower = col.lower()
            if any(pattern in col_lower for pattern in employment_patterns):
                try:
                    if df[col].dtype in ['int64', 'float64']:
                        se_df[f'se_employment_{employment_found}'] = df[col]
                        employment_found += 1
                    else:
                        # Convert employment status to numeric
                        emp_numeric = self._convert_employment_status(df[col])
                        if emp_numeric is not None:
                            se_df[f'se_employment_status_{employment_found}'] = emp_numeric
                            employment_found += 1
                except:
                    pass
        
        # Education variables
        education_patterns = ['education', 'school', 'grade', 'qualification', 'matric', 'degree']
        education_found = 0
        
        for col in df.columns:
            col_lower = col.lower()
            if any(pattern in col_lower for pattern in education_patterns):
                try:
                    if df[col].dtype in ['int64', 'float64']:
                        se_df[f'se_education_{education_found}'] = df[col]
                        education_found += 1
                    else:
                        # Convert education level to numeric
                        edu_numeric = self._convert_education_level(df[col])
                        if edu_numeric is not None:
                            se_df[f'se_education_level_{education_found}'] = edu_numeric
                            education_found += 1
                except:
                    pass
        
        # Housing quality variables
        housing_patterns = ['housing', 'dwelling', 'house', 'rooms', 'toilet', 'water', 'electricity']
        housing_found = 0
        
        for col in df.columns:
            col_lower = col.lower()
            if any(pattern in col_lower for pattern in housing_patterns):
                try:
                    if df[col].dtype in ['int64', 'float64']:
                        se_df[f'se_housing_{housing_found}'] = df[col]
                        housing_found += 1
                    else:
                        # Convert housing quality to numeric
                        housing_numeric = self._convert_housing_quality(df[col])
                        if housing_numeric is not None:
                            se_df[f'se_housing_quality_{housing_found}'] = housing_numeric
                            housing_found += 1
                except:
                    pass
        
        # Health access variables
        health_patterns = ['health', 'clinic', 'hospital', 'doctor', 'medical']
        health_found = 0
        
        for col in df.columns:
            col_lower = col.lower()
            if any(pattern in col_lower for pattern in health_patterns) and 'mental' not in col_lower:
                try:
                    if df[col].dtype in ['int64', 'float64']:
                        se_df[f'se_health_access_{health_found}'] = df[col]
                        health_found += 1
                    else:
                        # Convert health access to numeric
                        health_numeric = self._convert_health_access(df[col])
                        if health_numeric is not None:
                            se_df[f'se_health_access_{health_found}'] = health_numeric
                            health_found += 1
                except:
                    pass
        
        # Safety and security variables
        safety_patterns = ['safe', 'crime', 'violence', 'security', 'afraid']
        safety_found = 0
        
        for col in df.columns:
            col_lower = col.lower()
            if any(pattern in col_lower for pattern in safety_patterns):
                try:
                    if df[col].dtype in ['int64', 'float64']:
                        se_df[f'se_safety_{safety_found}'] = df[col]
                        safety_found += 1
                    else:
                        # Convert safety perception to numeric
                        safety_numeric = self._convert_safety_perception(df[col])
                        if safety_numeric is not None:
                            se_df[f'se_safety_perception_{safety_found}'] = safety_numeric
                            safety_found += 1
                except:
                    pass
        
        # Life satisfaction and wellbeing
        satisfaction_patterns = ['satisfaction', 'happy', 'life', 'wellbeing', 'quality']
        satisfaction_found = 0
        
        for col in df.columns:
            col_lower = col.lower()
            if any(pattern in col_lower for pattern in satisfaction_patterns):
                try:
                    if df[col].dtype in ['int64', 'float64']:
                        se_df[f'se_satisfaction_{satisfaction_found}'] = df[col]
                        satisfaction_found += 1
                except:
                    pass
        
        # Create composite indices
        self._create_enhanced_composite_indices(se_df)
        
        # Add demographic context if available
        self._extract_demographic_context(df, se_df)
        
        return se_df
    
    def _convert_categorical_income(self, series: pd.Series) -> Optional[pd.Series]:
        """Convert categorical income to numeric values."""
        try:
            # Common income category mappings
            income_mapping = {
                'no income': 0,
                'r1 - r400': 200,
                'r401 - r800': 600,
                'r801 - r1600': 1200,
                'r1601 - r3200': 2400,
                'r3201 - r6400': 4800,
                'r6401 - r12800': 9600,
                'r12801 - r25600': 19200,
                'r25601 - r51200': 38400,
                'r51201 - r102400': 76800,
                'r102401+': 150000
            }
            
            series_lower = series.astype(str).str.lower().str.strip()
            mapped = series_lower.map(income_mapping)
            
            if mapped.notna().sum() > len(series) * 0.1:  # At least 10% mapped successfully
                return mapped
            
        except:
            pass
        
        return None
    
    def _convert_employment_status(self, series: pd.Series) -> Optional[pd.Series]:
        """Convert employment status to numeric."""
        try:
            emp_mapping = {
                'employed': 1,
                'unemployed': 0,
                'retired': 0.5,
                'student': 0.3,
                'housework': 0.3,
                'disabled': 0,
                'self-employed': 1
            }
            
            series_lower = series.astype(str).str.lower().str.strip()
            mapped = series_lower.map(emp_mapping)
            
            if mapped.notna().sum() > len(series) * 0.1:
                return mapped
                
        except:
            pass
        
        return None
    
    def _convert_education_level(self, series: pd.Series) -> Optional[pd.Series]:
        """Convert education level to numeric years."""
        try:
            edu_mapping = {
                'no schooling': 0,
                'grade 1': 1, 'grade 2': 2, 'grade 3': 3, 'grade 4': 4, 'grade 5': 5,
                'grade 6': 6, 'grade 7': 7, 'grade 8': 8, 'grade 9': 9, 'grade 10': 10,
                'grade 11': 11, 'grade 12': 12, 'matric': 12,
                'certificate': 13, 'diploma': 14, 'degree': 16, 'postgraduate': 18
            }
            
            series_lower = series.astype(str).str.lower().str.strip()
            mapped = series_lower.map(edu_mapping)
            
            if mapped.notna().sum() > len(series) * 0.1:
                return mapped
                
        except:
            pass
        
        return None
    
    def _convert_housing_quality(self, series: pd.Series) -> Optional[pd.Series]:
        """Convert housing quality to numeric score."""
        try:
            # Higher scores = better housing
            housing_mapping = {
                'formal dwelling': 5,
                'informal dwelling': 2,
                'backyard dwelling': 3,
                'flat': 4,
                'house': 5,
                'shack': 1
            }
            
            series_lower = series.astype(str).str.lower().str.strip()
            mapped = series_lower.map(housing_mapping)
            
            if mapped.notna().sum() > len(series) * 0.1:
                return mapped
                
        except:
            pass
        
        return None
    
    def _convert_health_access(self, series: pd.Series) -> Optional[pd.Series]:
        """Convert health access to numeric score."""
        try:
            # Higher scores = better access
            health_mapping = {
                'very good': 5,
                'good': 4,
                'fair': 3,
                'poor': 2,
                'very poor': 1,
                'excellent': 5
            }
            
            series_lower = series.astype(str).str.lower().str.strip()
            mapped = series_lower.map(health_mapping)
            
            if mapped.notna().sum() > len(series) * 0.1:
                return mapped
                
        except:
            pass
        
        return None
    
    def _convert_safety_perception(self, series: pd.Series) -> Optional[pd.Series]:
        """Convert safety perception to numeric score."""
        try:
            # Higher scores = safer
            safety_mapping = {
                'very safe': 5,
                'safe': 4,
                'neither safe nor unsafe': 3,
                'unsafe': 2,
                'very unsafe': 1
            }
            
            series_lower = series.astype(str).str.lower().str.strip()
            mapped = series_lower.map(safety_mapping)
            
            if mapped.notna().sum() > len(series) * 0.1:
                return mapped
                
        except:
            pass
        
        return None
    
    def _create_enhanced_composite_indices(self, se_df: pd.DataFrame) -> None:
        """Create enhanced composite socio-economic indices."""
        
        # Income composite
        income_cols = [col for col in se_df.columns if 'se_income' in col]
        if income_cols:
            se_df['se_income_composite'] = se_df[income_cols].mean(axis=1)
        
        # Employment composite
        employment_cols = [col for col in se_df.columns if 'se_employment' in col]
        if employment_cols:
            se_df['se_employment_composite'] = se_df[employment_cols].mean(axis=1)
        
        # Education composite
        education_cols = [col for col in se_df.columns if 'se_education' in col]
        if education_cols:
            se_df['se_education_composite'] = se_df[education_cols].mean(axis=1)
        
        # Housing composite
        housing_cols = [col for col in se_df.columns if 'se_housing' in col]
        if housing_cols:
            se_df['se_housing_composite'] = se_df[housing_cols].mean(axis=1)
        
        # Health access composite
        health_cols = [col for col in se_df.columns if 'se_health_access' in col]
        if health_cols:
            se_df['se_health_access_composite'] = se_df[health_cols].mean(axis=1)
        
        # Safety composite
        safety_cols = [col for col in se_df.columns if 'se_safety' in col]
        if safety_cols:
            se_df['se_safety_composite'] = se_df[safety_cols].mean(axis=1)
        
        # Overall SES index
        composite_cols = [col for col in se_df.columns if col.endswith('_composite')]
        if composite_cols:
            se_df['se_overall_ses_index'] = se_df[composite_cols].mean(axis=1)
        
        # Heat vulnerability index (combination of factors that increase heat risk)
        vulnerability_factors = []
        
        # Low income increases vulnerability
        if 'se_income_composite' in se_df.columns:
            se_df['se_income_vulnerability'] = -se_df['se_income_composite']  # Invert
            vulnerability_factors.append('se_income_vulnerability')
        
        # Poor housing increases vulnerability
        if 'se_housing_composite' in se_df.columns:
            se_df['se_housing_vulnerability'] = -se_df['se_housing_composite']
            vulnerability_factors.append('se_housing_vulnerability')
        
        # Poor health access increases vulnerability
        if 'se_health_access_composite' in se_df.columns:
            se_df['se_health_vulnerability'] = -se_df['se_health_access_composite']
            vulnerability_factors.append('se_health_vulnerability')
        
        if vulnerability_factors:
            se_df['se_heat_vulnerability_index'] = se_df[vulnerability_factors].mean(axis=1)
    
    def _extract_demographic_context(self, original_df: pd.DataFrame, se_df: pd.DataFrame) -> None:
        """Extract demographic context variables."""
        
        # Age
        age_patterns = ['age']
        for col in original_df.columns:
            if any(pattern in col.lower() for pattern in age_patterns):
                try:
                    age_values = pd.to_numeric(original_df[col], errors='coerce')
                    if age_values.notna().sum() > len(original_df) * 0.1:
                        se_df['se_age'] = age_values
                        break
                except:
                    pass
        
        # Gender/Sex
        gender_patterns = ['gender', 'sex']
        for col in original_df.columns:
            if any(pattern in col.lower() for pattern in gender_patterns):
                try:
                    se_df['se_gender'] = original_df[col]
                    break
                except:
                    pass
        
        # Household size
        household_patterns = ['household', 'hh_size', 'people']
        for col in original_df.columns:
            col_lower = col.lower()
            if any(pattern in col_lower for pattern in household_patterns) and 'size' in col_lower:
                try:
                    hh_values = pd.to_numeric(original_df[col], errors='coerce')
                    if hh_values.notna().sum() > len(original_df) * 0.1:
                        se_df['se_household_size'] = hh_values
                        break
                except:
                    pass
    
    def integrate_enhanced_se_data(self) -> Dict[str, pd.DataFrame]:
        """
        Run complete enhanced SE integration.
        """
        self.logger.info("🏠 ENHANCED SOCIO-ECONOMIC INTEGRATION")
        self.logger.info("=" * 80)
        
        # Extract all GCRO data
        gcro_datasets = self.extract_all_gcro_data()
        
        if not gcro_datasets:
            self.logger.error("No GCRO datasets extracted!")
            return {}
        
        # Load XAI datasets and integrate
        xai_files = {
            'high_quality': 'xai_ready_high_quality.csv',
            'dphru_053_optimal': 'xai_ready_dphru_053_optimal.csv',
            'dphru_013_optimal': 'xai_ready_dphru_013_optimal.csv',
            'vida_008_optimal': 'xai_ready_vida_008_optimal.csv'
        }
        
        xai_path = self.base_path / "heat_analysis_optimized" / "data" / "optimal_xai_ready"
        integrated_datasets = {}
        
        for dataset_name, filename in xai_files.items():
            file_path = xai_path / filename
            
            if file_path.exists():
                self.logger.info(f"\\n🔗 Integrating with {dataset_name}")
                
                try:
                    xai_df = pd.read_csv(file_path)
                    self.logger.info(f"   📊 XAI dataset: {len(xai_df)} records, {len(xai_df.columns)} variables")
                    
                    # Enhanced integration
                    integrated_df = self._enhanced_integration(xai_df, gcro_datasets, dataset_name)
                    
                    if not integrated_df.empty:
                        integrated_datasets[dataset_name] = integrated_df
                        
                        se_cols = [col for col in integrated_df.columns if col.startswith('se_')]
                        self.logger.info(f"   ✅ Integration complete: {len(se_cols)} SE variables added")
                    
                except Exception as e:
                    self.logger.error(f"   Error integrating {dataset_name}: {e}")
        
        # Save integrated datasets
        if integrated_datasets:
            for dataset_name, df in integrated_datasets.items():
                output_file = self.output_path / f"enhanced_se_{dataset_name}.csv"
                df.to_csv(output_file, index=False)
                
                se_cols = [col for col in df.columns if col.startswith('se_')]
                self.logger.info(f"✅ Saved {dataset_name}: {len(df)} records, {len(se_cols)} SE variables")
        
        return integrated_datasets
    
    def _enhanced_integration(self, xai_df: pd.DataFrame, gcro_datasets: Dict[str, pd.DataFrame], dataset_name: str) -> pd.DataFrame:
        """Enhanced integration with better temporal matching."""
        
        integrated_df = xai_df.copy()
        
        # Determine temporal coverage
        if 'std_visit_date' in integrated_df.columns:
            valid_dates = integrated_df['std_visit_date'].notna()
            if valid_dates.sum() > 0:
                dates = pd.to_datetime(integrated_df.loc[valid_dates, 'std_visit_date'])
                min_year = dates.dt.year.min()
                max_year = dates.dt.year.max()
                avg_year = np.mean([min_year, max_year])
            else:
                min_year, max_year, avg_year = 2015, 2020, 2017.5
        else:
            min_year, max_year, avg_year = 2015, 2020, 2017.5
        
        # Find best matching GCRO dataset
        best_match = None
        best_distance = float('inf')
        
        for year, gcro_df in gcro_datasets.items():
            # Parse year
            if '-' in year:
                year_start = int(year.split('-')[0])
                year_end = int(year.split('-')[1])
                gcro_year = np.mean([year_start, year_end])
            else:
                gcro_year = int(year)
            
            distance = abs(gcro_year - avg_year)
            if distance < best_distance:
                best_distance = distance
                best_match = (year, gcro_df)
        
        if best_match:
            year, gcro_df = best_match
            self.logger.info(f"   🎯 Best SE match: {year} (distance: {best_distance:.1f} years)")
            
            # Enhanced integration with more sophisticated sampling
            se_cols = [col for col in gcro_df.columns if col.startswith('se_')]
            
            # Sample representative population
            n_samples = min(len(gcro_df), 2000)
            gcro_sample = gcro_df.sample(n_samples, random_state=42)
            
            # Add population-level statistics
            for col in se_cols:
                if gcro_sample[col].dtype in ['int64', 'float64']:
                    # Population statistics
                    integrated_df[f'{col}_pop_mean'] = gcro_sample[col].mean()
                    integrated_df[f'{col}_pop_std'] = gcro_sample[col].std()
                    integrated_df[f'{col}_pop_q25'] = gcro_sample[col].quantile(0.25)
                    integrated_df[f'{col}_pop_q75'] = gcro_sample[col].quantile(0.75)
                    
                    # Individual assignment with stratification
                    if len(integrated_df) <= len(gcro_sample):
                        assigned_values = gcro_sample[col].sample(len(integrated_df), replace=True, random_state=42).values
                    else:
                        # Bootstrap with replacement
                        np.random.seed(42)
                        assigned_values = np.random.choice(gcro_sample[col].dropna().values, len(integrated_df), replace=True)
                    
                    integrated_df[f'{col}_assigned'] = assigned_values
            
            # Add metadata
            integrated_df['se_data_year'] = year
            integrated_df['se_temporal_distance'] = best_distance
            integrated_df['se_variables_available'] = len(se_cols)
        
        return integrated_df


def main():
    """Main execution function."""
    print("🏠 ENHANCED SOCIO-ECONOMIC INTEGRATION")
    print("=" * 80)
    print("Enhanced extraction and integration of GCRO Quality of Life data")
    print("=" * 80)
    
    extractor = EnhancedSEExtractor()
    
    # Run enhanced integration
    results = extractor.integrate_enhanced_se_data()
    
    total_datasets = len(results)
    max_se_vars = 0
    if results:
        max_se_vars = max(len([col for col in df.columns if col.startswith('se_')]) for df in results.values())
    
    print(f"\\n🎉 ENHANCED INTEGRATION COMPLETE!")
    print(f"📊 Enhanced {total_datasets} datasets with comprehensive SE data")
    print(f"🏠 Maximum SE variables added: {max_se_vars}")
    print(f"💾 Results saved to: heat_analysis_optimized/data/enhanced_se_integrated/")
    print("🎯 Ready for comprehensive heat-health-SE XAI analysis!")
    
    return results


if __name__ == "__main__":
    main()