"""
WRHI Biomarker Data Explorer

Comprehensive exploration of JHB_WRHI_001 and JHB_WRHI_003 to extract all 
biomarker data that may have been missed in previous extractions.
"""

import pandas as pd
import numpy as np
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any
import logging
from datetime import datetime
import warnings

warnings.filterwarnings('ignore')

class WRHIBiomarkerExplorer:
    """
    Comprehensive exploration of WRHI datasets for biomarker data.
    """
    
    def __init__(self, base_path: str = "/home/cparker"):
        self.base_path = Path(base_path)
        self.raw_path = self.base_path / "incoming" / "RP2"
        self.output_path = self.base_path / "heat_analysis_optimized" / "data" / "wrhi_biomarkers"
        
        # Create output directory
        self.output_path.mkdir(parents=True, exist_ok=True)
        
        # Setup logging
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)
        
        # Comprehensive biomarker patterns
        self.biomarker_patterns = {
            'glucose': ['glucose', 'gluc', 'blood_sugar', 'fbs', 'fasting_glucose', 'random_glucose'],
            'cholesterol': ['cholesterol', 'chol', 'tc', 'total_chol', 'total_cholesterol'],
            'triglycerides': ['triglyceride', 'trig', 'tg', 'triglycerides'],
            'hdl': ['hdl', 'hdl_c', 'hdl_chol', 'high_density', 'hdl_cholesterol'],
            'ldl': ['ldl', 'ldl_c', 'ldl_chol', 'low_density', 'ldl_cholesterol'],
            'creatinine': ['creatinine', 'creat', 'cr', 'scr', 'serum_creatinine'],
            'hemoglobin': ['hemoglobin', 'hgb', 'hb', 'haemoglobin'],
            'hematocrit': ['hematocrit', 'hct', 'haematocrit'],
            'wbc': ['wbc', 'white_blood', 'leucocyte', 'leukocyte', 'white_cell'],
            'rbc': ['rbc', 'red_blood', 'red_cell', 'erythrocyte'],
            'platelets': ['platelet', 'plt', 'thrombocyte'],
            'cd4': ['cd4', 'cd4_count', 'cd4count', 'cd4_cells'],
            'cd8': ['cd8', 'cd8_count', 'cd8count', 'cd8_cells'],
            'viral_load': ['viral_load', 'vl', 'hiv_rna', 'hivrna', 'viral_rna'],
            'blood_pressure': ['bp', 'blood_pressure', 'systolic', 'diastolic', 'sbp', 'dbp'],
            'weight': ['weight', 'wt', 'body_weight', 'bwt'],
            'height': ['height', 'ht', 'stature'],
            'bmi': ['bmi', 'body_mass_index'],
            'temperature': ['temp', 'temperature', 'fever', 'body_temp'],
            'heart_rate': ['heart_rate', 'hr', 'pulse', 'pulse_rate'],
            'oxygen_saturation': ['spo2', 'oxygen', 'sat', 'o2_sat'],
            'albumin': ['albumin', 'alb', 'serum_albumin'],
            'bilirubin': ['bilirubin', 'bili', 'total_bili', 'direct_bili'],
            'alt': ['alt', 'alat', 'alanine', 'sgpt'],
            'ast': ['ast', 'asat', 'aspartate', 'sgot'],
            'alkaline_phosphatase': ['alp', 'alkp', 'alkaline', 'phosphatase'],
            'urea': ['urea', 'bun', 'blood_urea'],
            'sodium': ['sodium', 'na', 'serum_sodium'],
            'potassium': ['potassium', 'k', 'serum_potassium'],
            'chloride': ['chloride', 'cl', 'serum_chloride']
        }
    
    def explore_wrhi_001_comprehensive(self) -> Dict[str, Any]:
        """
        Comprehensive exploration of JHB_WRHI_001.
        """
        self.logger.info("=" * 80)
        self.logger.info("🔍 COMPREHENSIVE EXPLORATION: JHB_WRHI_001")
        self.logger.info("=" * 80)
        self.logger.info("👩 WOMEN'S REPRODUCTIVE HEALTH INSTITUTE - HIV Prevention Study")
        
        dataset_path = self.raw_path / "JHB_WRHI_001"
        
        analysis = {
            'name': 'JHB_WRHI_001',
            'directories': [],
            'csv_files': [],
            'total_records': 0,
            'biomarker_files': {},
            'unique_biomarkers': set(),
            'data_samples': {},
            'extraction_candidates': []
        }
        
        # Explore all subdirectories
        if dataset_path.exists():
            for subdir in dataset_path.iterdir():
                if subdir.is_dir():
                    analysis['directories'].append(subdir.name)
                    self.logger.info(f"\\n📁 DIRECTORY: {subdir.name}")
                    
                    # Look for CSV files
                    csv_files = list(subdir.glob("*.csv"))
                    if csv_files:
                        self.logger.info(f"   CSV files: {len(csv_files)}")
                        
                        for csv_file in csv_files:
                            self.logger.info(f"\\n   📄 {csv_file.name}")
                            
                            try:
                                # Quick peek at file
                                df_sample = pd.read_csv(csv_file, nrows=10)
                                df_full = pd.read_csv(csv_file)
                                
                                self.logger.info(f"      Records: {len(df_full)}")
                                self.logger.info(f"      Variables: {len(df_full.columns)}")
                                
                                # Check for biomarkers
                                biomarkers_found = []
                                for biomarker_type, patterns in self.biomarker_patterns.items():
                                    for col in df_full.columns:
                                        if any(pattern in col.lower() for pattern in patterns):
                                            biomarkers_found.append((biomarker_type, col))
                                            analysis['unique_biomarkers'].add(biomarker_type)
                                
                                if biomarkers_found:
                                    self.logger.info(f"      🔬 Biomarkers found: {len(biomarkers_found)}")
                                    for biomarker_type, col in biomarkers_found[:5]:
                                        non_null = df_full[col].notna().sum()
                                        self.logger.info(f"         - {biomarker_type} ({col}): {non_null} values")
                                    
                                    analysis['biomarker_files'][csv_file.name] = {
                                        'path': str(csv_file),
                                        'records': len(df_full),
                                        'biomarkers': biomarkers_found,
                                        'directory': subdir.name
                                    }
                                
                                # Check for participant IDs
                                id_cols = [col for col in df_full.columns if 'id' in col.lower()]
                                if id_cols:
                                    self.logger.info(f"      🆔 ID columns: {id_cols[:3]}")
                                
                                # Check for dates
                                date_cols = [col for col in df_full.columns if any(x in col.lower() for x in ['date', 'time', 'visit'])]
                                if date_cols:
                                    self.logger.info(f"      📅 Date columns: {date_cols[:3]}")
                                
                                analysis['csv_files'].append({
                                    'name': csv_file.name,
                                    'path': str(csv_file),
                                    'directory': subdir.name,
                                    'records': len(df_full),
                                    'variables': len(df_full.columns),
                                    'biomarkers': len(biomarkers_found)
                                })
                                
                                analysis['total_records'] += len(df_full)
                                
                                # Store sample if biomarkers found
                                if biomarkers_found:
                                    analysis['data_samples'][csv_file.name] = df_sample.to_dict()
                                    analysis['extraction_candidates'].append(csv_file)
                                
                            except Exception as e:
                                self.logger.error(f"      Error reading {csv_file.name}: {e}")
                    
                    # Also check for Excel files
                    excel_files = list(subdir.glob("*.xlsx")) + list(subdir.glob("*.xls"))
                    if excel_files:
                        self.logger.info(f"   Excel files: {len(excel_files)}")
                        for excel_file in excel_files:
                            self.logger.info(f"      📊 {excel_file.name}")
        
        self.logger.info(f"\\n📊 WRHI_001 SUMMARY:")
        self.logger.info(f"   Directories explored: {len(analysis['directories'])}")
        self.logger.info(f"   CSV files found: {len(analysis['csv_files'])}")
        self.logger.info(f"   Total records: {analysis['total_records']:,}")
        self.logger.info(f"   Files with biomarkers: {len(analysis['biomarker_files'])}")
        self.logger.info(f"   Unique biomarker types: {len(analysis['unique_biomarkers'])}")
        
        if analysis['unique_biomarkers']:
            self.logger.info(f"   Biomarker types found: {sorted(list(analysis['unique_biomarkers']))}")
        
        return analysis
    
    def explore_wrhi_003_comprehensive(self) -> Dict[str, Any]:
        """
        Comprehensive exploration of JHB_WRHI_003.
        """
        self.logger.info("\\n" + "=" * 80)
        self.logger.info("🔍 COMPREHENSIVE EXPLORATION: JHB_WRHI_003")
        self.logger.info("=" * 80)
        self.logger.info("👩 WOMEN'S REPRODUCTIVE HEALTH INSTITUTE - Clinical Trial")
        
        dataset_path = self.raw_path / "JHB_WRHI_003"
        
        analysis = {
            'name': 'JHB_WRHI_003',
            'directories': [],
            'csv_files': [],
            'total_records': 0,
            'biomarker_files': {},
            'unique_biomarkers': set(),
            'data_samples': {},
            'extraction_candidates': []
        }
        
        # Explore all subdirectories
        if dataset_path.exists():
            for subdir in dataset_path.iterdir():
                if subdir.is_dir():
                    analysis['directories'].append(subdir.name)
                    self.logger.info(f"\\n📁 DIRECTORY: {subdir.name}")
                    
                    # Look for CSV files
                    csv_files = list(subdir.glob("*.csv"))
                    if csv_files:
                        self.logger.info(f"   CSV files: {len(csv_files)}")
                        
                        for csv_file in csv_files:
                            self.logger.info(f"\\n   📄 {csv_file.name}")
                            
                            try:
                                # Quick peek at file
                                df_sample = pd.read_csv(csv_file, nrows=10)
                                df_full = pd.read_csv(csv_file)
                                
                                self.logger.info(f"      Records: {len(df_full)}")
                                self.logger.info(f"      Variables: {len(df_full.columns)}")
                                
                                # Check for biomarkers
                                biomarkers_found = []
                                for biomarker_type, patterns in self.biomarker_patterns.items():
                                    for col in df_full.columns:
                                        if any(pattern in col.lower() for pattern in patterns):
                                            biomarkers_found.append((biomarker_type, col))
                                            analysis['unique_biomarkers'].add(biomarker_type)
                                
                                if biomarkers_found:
                                    self.logger.info(f"      🔬 Biomarkers found: {len(biomarkers_found)}")
                                    for biomarker_type, col in biomarkers_found[:5]:
                                        non_null = df_full[col].notna().sum()
                                        self.logger.info(f"         - {biomarker_type} ({col}): {non_null} values")
                                    
                                    analysis['biomarker_files'][csv_file.name] = {
                                        'path': str(csv_file),
                                        'records': len(df_full),
                                        'biomarkers': biomarkers_found,
                                        'directory': subdir.name
                                    }
                                
                                # Check for participant IDs
                                id_cols = [col for col in df_full.columns if 'id' in col.lower()]
                                if id_cols:
                                    self.logger.info(f"      🆔 ID columns: {id_cols[:3]}")
                                
                                # Check for dates
                                date_cols = [col for col in df_full.columns if any(x in col.lower() for x in ['date', 'time', 'visit'])]
                                if date_cols:
                                    self.logger.info(f"      📅 Date columns: {date_cols[:3]}")
                                
                                analysis['csv_files'].append({
                                    'name': csv_file.name,
                                    'path': str(csv_file),
                                    'directory': subdir.name,
                                    'records': len(df_full),
                                    'variables': len(df_full.columns),
                                    'biomarkers': len(biomarkers_found)
                                })
                                
                                analysis['total_records'] += len(df_full)
                                
                                # Store sample if biomarkers found
                                if biomarkers_found:
                                    analysis['data_samples'][csv_file.name] = df_sample.to_dict()
                                    analysis['extraction_candidates'].append(csv_file)
                                
                            except Exception as e:
                                self.logger.error(f"      Error reading {csv_file.name}: {e}")
                    
                    # Also check for Excel files
                    excel_files = list(subdir.glob("*.xlsx")) + list(subdir.glob("*.xls"))
                    if excel_files:
                        self.logger.info(f"   Excel files: {len(excel_files)}")
                        for excel_file in excel_files:
                            self.logger.info(f"      📊 {excel_file.name}")
        
        self.logger.info(f"\\n📊 WRHI_003 SUMMARY:")
        self.logger.info(f"   Directories explored: {len(analysis['directories'])}")
        self.logger.info(f"   CSV files found: {len(analysis['csv_files'])}")
        self.logger.info(f"   Total records: {analysis['total_records']:,}")
        self.logger.info(f"   Files with biomarkers: {len(analysis['biomarker_files'])}")
        self.logger.info(f"   Unique biomarker types: {len(analysis['unique_biomarkers'])}")
        
        if analysis['unique_biomarkers']:
            self.logger.info(f"   Biomarker types found: {sorted(list(analysis['unique_biomarkers']))}")
        
        return analysis
    
    def extract_wrhi_biomarkers(self, wrhi_001_analysis: Dict, wrhi_003_analysis: Dict) -> Dict[str, pd.DataFrame]:
        """
        Extract all biomarker data from both WRHI datasets.
        """
        self.logger.info("\\n" + "=" * 80)
        self.logger.info("📥 EXTRACTING WRHI BIOMARKER DATA")
        self.logger.info("=" * 80)
        
        results = {}
        
        # Extract WRHI_001
        if wrhi_001_analysis['extraction_candidates']:
            self.logger.info(f"\\n🔬 EXTRACTING WRHI_001 BIOMARKERS")
            self.logger.info(f"Processing {len(wrhi_001_analysis['extraction_candidates'])} biomarker files")
            
            all_wrhi_001_data = []
            
            for csv_file in wrhi_001_analysis['extraction_candidates']:
                self.logger.info(f"\\n   📄 Processing: {csv_file.name}")
                
                try:
                    df = pd.read_csv(csv_file)
                    
                    # Add metadata
                    df['dataset_name'] = 'jhb_wrhi_001'
                    df['source_file'] = csv_file.name
                    df['source_directory'] = csv_file.parent.name
                    
                    # Create participant IDs if not present
                    if 'usubjid' in df.columns:
                        df['participant_id'] = 'wrhi_001_' + df['usubjid'].astype(str)
                    elif 'subjid' in df.columns:
                        df['participant_id'] = 'wrhi_001_' + df['subjid'].astype(str)
                    else:
                        id_cols = [col for col in df.columns if 'id' in col.lower()]
                        if id_cols:
                            df['participant_id'] = 'wrhi_001_' + df[id_cols[0]].astype(str)
                        else:
                            df['participant_id'] = [f"wrhi_001_{csv_file.stem}_{i:04d}" for i in range(len(df))]
                    
                    # Standardize biomarkers
                    for biomarker_type, patterns in self.biomarker_patterns.items():
                        for col in df.columns:
                            if any(pattern in col.lower() for pattern in patterns):
                                std_name = f'biomarker_{biomarker_type}'
                                if std_name not in df.columns:  # Don't overwrite if already exists
                                    try:
                                        df[std_name] = pd.to_numeric(df[col], errors='coerce')
                                    except:
                                        df[std_name] = df[col]
                                break  # Take first match for each biomarker type
                    
                    all_wrhi_001_data.append(df)
                    self.logger.info(f"      ✅ Extracted {len(df)} records")
                    
                except Exception as e:
                    self.logger.error(f"      ❌ Error: {e}")
            
            if all_wrhi_001_data:
                # Combine all WRHI_001 data
                combined_001 = pd.concat(all_wrhi_001_data, ignore_index=True, sort=False)
                
                # Remove duplicates based on participant_id
                before = len(combined_001)
                combined_001 = combined_001.drop_duplicates(subset=['participant_id'], keep='first')
                after = len(combined_001)
                
                if before != after:
                    self.logger.info(f"   Removed {before - after} duplicate records")
                
                # Save
                output_file = self.output_path / "comprehensive_wrhi_001_biomarkers.csv"
                combined_001.to_csv(output_file, index=False)
                
                results['wrhi_001'] = combined_001
                
                self.logger.info(f"\\n   ✅ WRHI_001 extraction complete:")
                self.logger.info(f"      Records: {len(combined_001)}")
                self.logger.info(f"      Variables: {len(combined_001.columns)}")
                self.logger.info(f"      Output: {output_file}")
                
                # Report biomarkers
                biomarker_cols = [col for col in combined_001.columns if col.startswith('biomarker_')]
                if biomarker_cols:
                    self.logger.info(f"      🔬 Biomarkers standardized: {len(biomarker_cols)}")
                    for col in sorted(biomarker_cols):
                        non_null = combined_001[col].notna().sum()
                        if non_null > 0:
                            self.logger.info(f"         - {col}: {non_null} values")
        
        # Extract WRHI_003
        if wrhi_003_analysis['extraction_candidates']:
            self.logger.info(f"\\n🔬 EXTRACTING WRHI_003 BIOMARKERS")
            self.logger.info(f"Processing {len(wrhi_003_analysis['extraction_candidates'])} biomarker files")
            
            all_wrhi_003_data = []
            
            for csv_file in wrhi_003_analysis['extraction_candidates']:
                self.logger.info(f"\\n   📄 Processing: {csv_file.name}")
                
                try:
                    df = pd.read_csv(csv_file)
                    
                    # Add metadata
                    df['dataset_name'] = 'jhb_wrhi_003'
                    df['source_file'] = csv_file.name
                    df['source_directory'] = csv_file.parent.name
                    
                    # Create participant IDs if not present
                    if 'usubjid' in df.columns:
                        df['participant_id'] = 'wrhi_003_' + df['usubjid'].astype(str)
                    elif 'subjid' in df.columns:
                        df['participant_id'] = 'wrhi_003_' + df['subjid'].astype(str)
                    else:
                        id_cols = [col for col in df.columns if 'id' in col.lower()]
                        if id_cols:
                            df['participant_id'] = 'wrhi_003_' + df[id_cols[0]].astype(str)
                        else:
                            df['participant_id'] = [f"wrhi_003_{csv_file.stem}_{i:04d}" for i in range(len(df))]
                    
                    # Standardize biomarkers
                    for biomarker_type, patterns in self.biomarker_patterns.items():
                        for col in df.columns:
                            if any(pattern in col.lower() for pattern in patterns):
                                std_name = f'biomarker_{biomarker_type}'
                                if std_name not in df.columns:  # Don't overwrite if already exists
                                    try:
                                        df[std_name] = pd.to_numeric(df[col], errors='coerce')
                                    except:
                                        df[std_name] = df[col]
                                break  # Take first match for each biomarker type
                    
                    all_wrhi_003_data.append(df)
                    self.logger.info(f"      ✅ Extracted {len(df)} records")
                    
                except Exception as e:
                    self.logger.error(f"      ❌ Error: {e}")
            
            if all_wrhi_003_data:
                # Combine all WRHI_003 data
                combined_003 = pd.concat(all_wrhi_003_data, ignore_index=True, sort=False)
                
                # Remove duplicates based on participant_id
                before = len(combined_003)
                combined_003 = combined_003.drop_duplicates(subset=['participant_id'], keep='first')
                after = len(combined_003)
                
                if before != after:
                    self.logger.info(f"   Removed {before - after} duplicate records")
                
                # Save
                output_file = self.output_path / "comprehensive_wrhi_003_biomarkers.csv"
                combined_003.to_csv(output_file, index=False)
                
                results['wrhi_003'] = combined_003
                
                self.logger.info(f"\\n   ✅ WRHI_003 extraction complete:")
                self.logger.info(f"      Records: {len(combined_003)}")
                self.logger.info(f"      Variables: {len(combined_003.columns)}")
                self.logger.info(f"      Output: {output_file}")
                
                # Report biomarkers
                biomarker_cols = [col for col in combined_003.columns if col.startswith('biomarker_')]
                if biomarker_cols:
                    self.logger.info(f"      🔬 Biomarkers standardized: {len(biomarker_cols)}")
                    for col in sorted(biomarker_cols):
                        non_null = combined_003[col].notna().sum()
                        if non_null > 0:
                            self.logger.info(f"         - {col}: {non_null} values")
        
        return results
    
    def run_comprehensive_wrhi_exploration(self) -> Dict[str, Any]:
        """
        Run comprehensive exploration of both WRHI datasets.
        """
        self.logger.info("🔍 COMPREHENSIVE WRHI BIOMARKER EXPLORATION")
        self.logger.info("=" * 80)
        self.logger.info("Thoroughly exploring WRHI_001 and WRHI_003 for biomarker data")
        self.logger.info("=" * 80)
        
        results = {}
        
        # Explore both datasets
        wrhi_001_analysis = self.explore_wrhi_001_comprehensive()
        wrhi_003_analysis = self.explore_wrhi_003_comprehensive()
        
        results['wrhi_001_analysis'] = wrhi_001_analysis
        results['wrhi_003_analysis'] = wrhi_003_analysis
        
        # Extract biomarker data
        extracted_data = self.extract_wrhi_biomarkers(wrhi_001_analysis, wrhi_003_analysis)
        results.update(extracted_data)
        
        # Final summary
        self.logger.info("\\n" + "=" * 80)
        self.logger.info("📊 COMPREHENSIVE WRHI EXPLORATION SUMMARY")
        self.logger.info("=" * 80)
        
        total_participants = 0
        for dataset_name, data in extracted_data.items():
            biomarker_cols = [col for col in data.columns if col.startswith('biomarker_')]
            total_participants += len(data)
            
            self.logger.info(f"\\n✅ {dataset_name.upper()}:")
            self.logger.info(f"   Records: {len(data)}")
            self.logger.info(f"   Variables: {len(data.columns)}")
            self.logger.info(f"   Biomarker types: {len(biomarker_cols)}")
            
            # Show top biomarkers by completeness
            if biomarker_cols:
                biomarker_completeness = [(col, data[col].notna().sum()) for col in biomarker_cols]
                biomarker_completeness.sort(key=lambda x: x[1], reverse=True)
                
                self.logger.info(f"   Top biomarkers by completeness:")
                for col, count in biomarker_completeness[:5]:
                    pct = count / len(data) * 100
                    self.logger.info(f"      - {col}: {count} ({pct:.1f}%)")
        
        self.logger.info(f"\\n🎯 TOTAL WRHI BIOMARKER PARTICIPANTS: {total_participants}")
        
        return results


def main():
    """Main execution function."""
    print("🔍 COMPREHENSIVE WRHI BIOMARKER EXPLORATION")
    print("=" * 80)
    print("Thoroughly exploring JHB_WRHI_001 and JHB_WRHI_003 for biomarker data")
    print("=" * 80)
    
    explorer = WRHIBiomarkerExplorer()
    
    # Run comprehensive exploration
    results = explorer.run_comprehensive_wrhi_exploration()
    
    total_extracted = sum(len(data) for key, data in results.items() if isinstance(data, pd.DataFrame))
    
    print(f"\\n✅ WRHI biomarker exploration complete!")
    print(f"📊 Total participants extracted: {total_extracted}")
    print(f"💾 Results saved to: heat_analysis_optimized/data/wrhi_biomarkers/")
    
    return results


if __name__ == "__main__":
    main()