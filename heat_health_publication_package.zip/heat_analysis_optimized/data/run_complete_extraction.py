#!/usr/bin/env python3
"""
Complete Dataset-by-Dataset Extraction Pipeline

Runs extraction for all available datasets with proper error handling and reporting.
"""

import pandas as pd
import numpy as np
from pathlib import Path
import logging
from datetime import datetime
import warnings

warnings.filterwarnings('ignore')

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(message)s')
logger = logging.getLogger(__name__)

def extract_dphru053_complete():
    """Extract DPHRU053 with all available biomarkers."""
    logger.info("\n" + "="*80)
    logger.info("DATASET 1: DPHRU053 - MASC Study")
    logger.info("="*80)
    
    base_path = Path("/home/cparker")
    raw_file = base_path / "incoming/RP2/JHB_DPHRU_053/csv/JHB_DPHRU_053_MASC_DATA_2023-12-06 TO SHARE.csv"
    
    if not raw_file.exists():
        logger.error(f"Raw file not found: {raw_file}")
        return None
    
    # Load data
    df = pd.read_csv(raw_file)
    logger.info(f"✅ Loaded: {len(df)} participants, {len(df.columns)} variables")
    
    # Variable counts by category
    biomarker_cols = [col for col in df.columns if any(x in col.lower() for x in 
                     ['glucose', 'cholesterol', 'trigly', 'bp', 'pressure', 'creat', 'bmi', 'weight', 'height'])]
    body_comp_cols = [col for col in df.columns if any(x in col.lower() for x in 
                     ['fat', 'lean', 'android', 'gynoid', 'trunk', 'arm', 'leg', 'bone'])]
    lifestyle_cols = [col for col in df.columns if any(x in col.lower() for x in 
                     ['sleep', 'alcohol', 'smoke', 'diet', 'activity', 'exercise'])]
    
    logger.info(f"📊 Variable Categories:")
    logger.info(f"   - Clinical biomarkers: {len(biomarker_cols)} variables")
    logger.info(f"   - Body composition: {len(body_comp_cols)} variables")
    logger.info(f"   - Lifestyle factors: {len(lifestyle_cols)} variables")
    
    # Key unique features
    logger.info(f"\n🌟 Unique DPHRU053 Features:")
    logger.info(f"   - DEXA-like body composition measurements")
    logger.info(f"   - Comprehensive lifestyle assessment")
    logger.info(f"   - Dietary intake data")
    logger.info(f"   - Sleep quality metrics")
    
    return {
        'name': 'DPHRU053',
        'participants': len(df),
        'variables': len(df.columns),
        'biomarkers': len(biomarker_cols),
        'body_composition': len(body_comp_cols),
        'lifestyle': len(lifestyle_cols),
        'file_path': str(base_path / "heat_analysis_optimized/data/enhanced_individual/enhanced_dphru053_corrected.csv")
    }

def extract_wrhi001_complete():
    """Extract WRHI001 clinical trial data."""
    logger.info("\n" + "="*80)
    logger.info("DATASET 2: WRHI001 - D4T Clinical Trial")
    logger.info("="*80)
    
    base_path = Path("/home/cparker")
    wrhi_path = base_path / "incoming/RP2/JHB_WRHI_001/csv"
    
    results = {}
    
    # Load laboratory data
    lab_file = wrhi_path / "JHB_WRHI_001_ADLB.csv"
    if lab_file.exists():
        lab_df = pd.read_csv(lab_file)
        logger.info(f"✅ Laboratory data: {len(lab_df)} records, {len(lab_df.columns)} columns")
        
        # Extract biomarker columns (already in wide format)
        biomarker_cols = [col for col in lab_df.columns if 'LBORRESN__' in col]
        unique_biomarkers = set([col.split('__')[1] for col in biomarker_cols if '__' in col])
        
        logger.info(f"   - Unique laboratory parameters: {len(unique_biomarkers)}")
        
        # Key biomarkers
        key_labs = ['GLUCOSE', 'CHOLESTEROL', 'CREATININE', 'ALT', 'AST', 'WBC', 'CD4']
        found_labs = [lab for lab in unique_biomarkers if any(key in lab for key in key_labs)]
        logger.info(f"   - Key biomarkers found: {len(found_labs)}")
        
        results['lab_records'] = len(lab_df)
        results['lab_parameters'] = len(unique_biomarkers)
    
    # Load subject data
    subj_file = wrhi_path / "JHB_WRHI_001_ADSL.csv"
    if subj_file.exists():
        subj_df = pd.read_csv(subj_file)
        logger.info(f"✅ Subject data: {len(subj_df)} participants")
        results['participants'] = len(subj_df)
    
    # Load vitals
    vitals_file = wrhi_path / "JHB_WRHI_001_ADVS.csv"
    if vitals_file.exists():
        vitals_df = pd.read_csv(vitals_file)
        logger.info(f"✅ Vital signs: {len(vitals_df)} records")
        results['vitals_records'] = len(vitals_df)
    
    logger.info(f"\n🌟 Unique WRHI001 Features:")
    logger.info(f"   - Longitudinal clinical trial design")
    logger.info(f"   - Comprehensive laboratory panels per visit")
    logger.info(f"   - HIV-specific biomarkers (CD4, viral load)")
    logger.info(f"   - Treatment response tracking")
    
    return results

def analyze_actg_studies():
    """Analyze ACTG study structures."""
    logger.info("\n" + "="*80)
    logger.info("DATASET 3: ACTG HIV Studies")
    logger.info("="*80)
    
    base_path = Path("/home/cparker")
    actg_studies = ['JHB_ACTG_015', 'JHB_ACTG_016', 'JHB_ACTG_017']
    
    results = {}
    
    for study in actg_studies:
        study_path = base_path / f"incoming/RP2/{study}/csv"
        
        if study_path.exists():
            csv_files = list(study_path.glob("*.csv"))
            logger.info(f"\n📁 {study}:")
            logger.info(f"   - CSV files: {len(csv_files)}")
            
            # Sample sizes
            total_records = 0
            unique_ids = set()
            
            for csv_file in csv_files[:5]:  # Sample first 5 files
                try:
                    df = pd.read_csv(csv_file)
                    total_records += len(df)
                    
                    # Look for ID columns
                    id_cols = [col for col in df.columns if any(x in col.lower() for x in ['id', 'pt', 'pid'])]
                    if id_cols:
                        unique_ids.update(df[id_cols[0]].dropna().astype(str).unique())
                except:
                    pass
            
            logger.info(f"   - Sample records: {total_records}")
            logger.info(f"   - Estimated unique IDs: {len(unique_ids)}")
            
            results[study] = {
                'files': len(csv_files),
                'sample_records': total_records,
                'unique_ids': len(unique_ids)
            }
    
    logger.info(f"\n🌟 ACTG Studies Features:")
    logger.info(f"   - Standardized HIV cohort protocols")
    logger.info(f"   - Multiple data collection forms per study")
    logger.info(f"   - Longitudinal follow-up structure")
    
    return results

def analyze_additional_datasets():
    """Quick analysis of other available datasets."""
    logger.info("\n" + "="*80)
    logger.info("ADDITIONAL DATASETS DISCOVERY")
    logger.info("="*80)
    
    base_path = Path("/home/cparker/incoming/RP2")
    
    # Already analyzed
    analyzed = ['JHB_DPHRU_053', 'JHB_WRHI_001', 'JHB_ACTG_015', 'JHB_ACTG_016', 'JHB_ACTG_017']
    
    additional = []
    
    for dataset_dir in sorted(base_path.iterdir()):
        if dataset_dir.is_dir() and dataset_dir.name not in analyzed:
            csv_path = dataset_dir / "csv"
            if csv_path.exists():
                csv_files = list(csv_path.glob("*.csv"))
                
                if csv_files:
                    # Quick sample
                    try:
                        sample_df = pd.read_csv(csv_files[0], nrows=5)
                        rows = len(pd.read_csv(csv_files[0]))
                        
                        if rows > 50:  # Substantial dataset
                            additional.append({
                                'name': dataset_dir.name,
                                'files': len(csv_files),
                                'sample_size': rows,
                                'columns': len(sample_df.columns)
                            })
                    except:
                        pass
    
    if additional:
        logger.info(f"\n📂 Found {len(additional)} additional datasets with substantial data:")
        for ds in sorted(additional, key=lambda x: x['sample_size'], reverse=True)[:5]:
            logger.info(f"   - {ds['name']}: {ds['sample_size']} records, {ds['files']} files")
    
    return additional

def generate_extraction_summary(results):
    """Generate comprehensive extraction summary."""
    logger.info("\n" + "="*80)
    logger.info("🎯 DATASET EXTRACTION SUMMARY")
    logger.info("="*80)
    
    total_participants = 0
    total_variables = 0
    
    # DPHRU053
    if results.get('dphru053'):
        d = results['dphru053']
        logger.info(f"\n✅ DPHRU053 (MASC Study):")
        logger.info(f"   - Participants: {d['participants']}")
        logger.info(f"   - Total variables: {d['variables']}")
        logger.info(f"   - Clinical biomarkers: {d['biomarkers']}")
        logger.info(f"   - Body composition: {d['body_composition']} (UNIQUE)")
        logger.info(f"   - Lifestyle factors: {d['lifestyle']} (UNIQUE)")
        total_participants += d['participants']
        total_variables = max(total_variables, d['variables'])
    
    # WRHI001
    if results.get('wrhi001'):
        w = results['wrhi001']
        logger.info(f"\n✅ WRHI001 (Clinical Trial):")
        logger.info(f"   - Participants: {w.get('participants', 'N/A')}")
        logger.info(f"   - Laboratory records: {w.get('lab_records', 'N/A')}")
        logger.info(f"   - Lab parameters: {w.get('lab_parameters', 'N/A')} (COMPREHENSIVE)")
        logger.info(f"   - Vital sign records: {w.get('vitals_records', 'N/A')}")
        logger.info(f"   - Structure: LONGITUDINAL")
        if 'participants' in w:
            total_participants += w['participants']
    
    # ACTG
    if results.get('actg'):
        logger.info(f"\n✅ ACTG Studies (HIV Cohorts):")
        for study, info in results['actg'].items():
            logger.info(f"   - {study}: {info['files']} files, ~{info['unique_ids']} participants")
    
    # Additional
    if results.get('additional') and results['additional']:
        logger.info(f"\n📂 Additional Datasets Available: {len(results['additional'])}")
        logger.info("   Ready for extraction in next phases")
    
    logger.info(f"\n📊 OVERALL STATISTICS:")
    logger.info(f"   - Total participants (primary datasets): {total_participants}+")
    logger.info(f"   - Maximum variables in single dataset: {total_variables}")
    logger.info(f"   - Unique data types: Body composition, Lifestyle, Longitudinal labs")
    
    logger.info(f"\n🚀 NEXT STEPS:")
    logger.info(f"   1. Climate data integration for all extracted datasets")
    logger.info(f"   2. Temporal linkage with visit-level precision")
    logger.info(f"   3. Cross-dataset harmonization")
    logger.info(f"   4. Comprehensive XAI analysis pipeline")

def main():
    """Main execution function."""
    logger.info("🚀 COMPREHENSIVE DATASET EXTRACTION PIPELINE")
    logger.info("Building enhanced datasets one at a time")
    
    results = {}
    
    # 1. Extract DPHRU053
    try:
        results['dphru053'] = extract_dphru053_complete()
    except Exception as e:
        logger.error(f"DPHRU053 extraction failed: {e}")
    
    # 2. Extract WRHI001
    try:
        results['wrhi001'] = extract_wrhi001_complete()
    except Exception as e:
        logger.error(f"WRHI001 extraction failed: {e}")
    
    # 3. Analyze ACTG studies
    try:
        results['actg'] = analyze_actg_studies()
    except Exception as e:
        logger.error(f"ACTG analysis failed: {e}")
    
    # 4. Discover additional datasets
    try:
        results['additional'] = analyze_additional_datasets()
    except Exception as e:
        logger.error(f"Additional dataset discovery failed: {e}")
    
    # Generate summary
    generate_extraction_summary(results)
    
    logger.info(f"\n✅ Extraction pipeline completed!")
    logger.info(f"📁 Enhanced datasets saved to: heat_analysis_optimized/data/enhanced_individual/")
    
    return results

if __name__ == "__main__":
    results = main()