"""
Additional Dataset Extractors for RP2 High-Value Datasets

Extracts and standardizes the most promising additional datasets discovered:
1. JHB_Ezin_002 - Largest dataset (9,535 records)
2. JHB_IMPAACT_010 - Pediatric HIV study (8,948 records)
3. JHB_SCHARP_006 - HIV vaccine trials (3,353 records)
4. JHB_VIDA_007 - Maternal/child health (2,130 records)
5. JHB_WRHI_003 - Women's reproductive health (2,127 records)
"""

import pandas as pd
import numpy as np
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any
import logging
from datetime import datetime
import warnings

warnings.filterwarnings('ignore')

class AdditionalDatasetExtractor:
    """
    Extracts high-value additional datasets from RP2 folder.
    Each dataset is analyzed, standardized, and prepared for pipeline integration.
    """
    
    def __init__(self, base_path: str = "/home/cparker"):
        self.base_path = Path(base_path)
        self.raw_path = self.base_path / "incoming" / "RP2"
        self.output_path = self.base_path / "heat_analysis_optimized" / "data" / "enhanced_additional"
        
        # Create output directory
        self.output_path.mkdir(parents=True, exist_ok=True)
        
        # Setup logging
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)
        
        # Common biomarker patterns for standardization
        self.biomarker_patterns = {
            'glucose': ['glucose', 'gluc', 'blood_sugar', 'fbs'],
            'cholesterol': ['cholesterol', 'chol', 'tc', 'total_chol'],
            'triglycerides': ['triglyceride', 'trig', 'tg'],
            'hdl': ['hdl', 'hdl_c', 'hdl_chol', 'high_density'],
            'ldl': ['ldl', 'ldl_c', 'ldl_chol', 'low_density'],
            'creatinine': ['creatinine', 'creat', 'cr', 'scr'],
            'hemoglobin': ['hemoglobin', 'hgb', 'hb', 'haemoglobin'],
            'wbc': ['wbc', 'white_blood', 'leucocyte', 'leukocyte'],
            'cd4': ['cd4', 'cd4_count', 'cd4count', 'cd4_cells'],
            'viral_load': ['viral_load', 'vl', 'hiv_rna', 'hivrna'],
            'blood_pressure': ['bp', 'blood_pressure', 'systolic', 'diastolic'],
            'weight': ['weight', 'wt', 'body_weight'],
            'height': ['height', 'ht', 'stature'],
            'bmi': ['bmi', 'body_mass_index']
        }
    
    def extract_jhb_ezin_002(self) -> pd.DataFrame:
        """
        Extract JHB_Ezin_002 - Largest additional dataset.
        
        Expected features:
        - Large sample size (9,535 records)
        - Multiple CSV files suggesting comprehensive data
        """
        self.logger.info("\n" + "="*60)
        self.logger.info("DATASET: JHB_Ezin_002 - Large Cohort Study")
        self.logger.info("="*60)
        
        dataset_path = self.raw_path / "JHB_Ezin_002" / "csv"
        
        if not dataset_path.exists():
            self.logger.error(f"Dataset path not found: {dataset_path}")
            return pd.DataFrame()
        
        # List all CSV files
        csv_files = sorted(dataset_path.glob("*.csv"))
        self.logger.info(f"Found {len(csv_files)} CSV files")
        
        all_data = []
        file_summaries = {}
        
        for csv_file in csv_files:
            self.logger.info(f"\n📄 Processing: {csv_file.name}")
            
            try:
                df = pd.read_csv(csv_file)
                self.logger.info(f"   Loaded: {len(df)} records, {len(df.columns)} columns")
                
                # Analyze content
                file_summaries[csv_file.name] = {
                    'records': len(df),
                    'columns': len(df.columns),
                    'biomarkers_found': self._identify_biomarkers(df)
                }
                
                # If it looks like primary data (not metadata), process it
                if len(df) > 100 and len(df.columns) > 10:
                    standardized = self._standardize_dataset(df, 'ezin_002', csv_file.name)
                    if not standardized.empty:
                        all_data.append(standardized)
                
            except Exception as e:
                self.logger.error(f"   Error processing {csv_file.name}: {e}")
        
        # Combine all processed data
        if all_data:
            combined = pd.concat(all_data, ignore_index=True)
            
            # Remove duplicates if any
            before = len(combined)
            if 'participant_id' in combined.columns:
                combined = combined.drop_duplicates(subset=['participant_id'])
            after = len(combined)
            
            if before != after:
                self.logger.info(f"Removed {before - after} duplicate records")
            
            # Save dataset
            output_file = self.output_path / "enhanced_jhb_ezin_002.csv"
            combined.to_csv(output_file, index=False)
            
            self.logger.info(f"\n✅ JHB_Ezin_002 extraction complete:")
            self.logger.info(f"   Total records: {len(combined)}")
            self.logger.info(f"   Variables: {len(combined.columns)}")
            self.logger.info(f"   Output: {output_file}")
            
            # Report biomarkers found
            self._report_biomarkers_found(combined)
            
            return combined
        else:
            self.logger.warning("No data successfully extracted from JHB_Ezin_002")
            return pd.DataFrame()
    
    def extract_jhb_impaact_010(self) -> pd.DataFrame:
        """
        Extract JHB_IMPAACT_010 - Pediatric HIV study.
        
        IMPAACT = International Maternal Pediatric Adolescent AIDS Clinical Trials
        Expected features:
        - Pediatric/adolescent focus
        - HIV-related biomarkers
        - Growth and development metrics
        """
        self.logger.info("\n" + "="*60)
        self.logger.info("DATASET: JHB_IMPAACT_010 - Pediatric HIV Study")
        self.logger.info("="*60)
        
        dataset_path = self.raw_path / "JHB_IMPAACT_010" / "csv"
        
        if not dataset_path.exists():
            self.logger.error(f"Dataset path not found: {dataset_path}")
            return pd.DataFrame()
        
        csv_files = sorted(dataset_path.glob("*.csv"))
        self.logger.info(f"Found {len(csv_files)} CSV files")
        
        all_data = []
        
        for csv_file in csv_files:
            self.logger.info(f"\n📄 Processing: {csv_file.name}")
            
            try:
                df = pd.read_csv(csv_file)
                self.logger.info(f"   Loaded: {len(df)} records, {len(df.columns)} columns")
                
                # IMPAACT studies often have age-specific data
                if 'age' in df.columns or 'age_years' in df.columns:
                    age_col = 'age' if 'age' in df.columns else 'age_years'
                    age_mean = df[age_col].mean()
                    self.logger.info(f"   Mean age: {age_mean:.1f} years (pediatric focus)")
                
                # Standardize
                standardized = self._standardize_dataset(df, 'impaact_010', csv_file.name)
                
                # Add pediatric-specific features if available
                standardized = self._add_pediatric_features(standardized, df)
                
                if not standardized.empty:
                    all_data.append(standardized)
                    
            except Exception as e:
                self.logger.error(f"   Error processing {csv_file.name}: {e}")
        
        # Combine and save
        if all_data:
            combined = pd.concat(all_data, ignore_index=True)
            
            # Deduplicate
            if 'participant_id' in combined.columns:
                combined = combined.drop_duplicates(subset=['participant_id'])
            
            output_file = self.output_path / "enhanced_jhb_impaact_010.csv"
            combined.to_csv(output_file, index=False)
            
            self.logger.info(f"\n✅ JHB_IMPAACT_010 extraction complete:")
            self.logger.info(f"   Total records: {len(combined)}")
            self.logger.info(f"   Variables: {len(combined.columns)}")
            self.logger.info(f"   Output: {output_file}")
            
            # Check for pediatric-specific variables
            growth_vars = [col for col in combined.columns if any(x in col for x in ['height', 'weight', 'growth', 'bmi'])]
            if growth_vars:
                self.logger.info(f"   Growth metrics: {len(growth_vars)} variables")
            
            self._report_biomarkers_found(combined)
            
            return combined
        else:
            self.logger.warning("No data successfully extracted from JHB_IMPAACT_010")
            return pd.DataFrame()
    
    def extract_jhb_scharp_006(self) -> pd.DataFrame:
        """
        Extract JHB_SCHARP_006 - HIV vaccine trials.
        
        SCHARP = Statistical Center for HIV/AIDS Research & Prevention
        Expected features:
        - Vaccine trial data
        - Immunological markers
        - Safety monitoring
        """
        self.logger.info("\n" + "="*60)
        self.logger.info("DATASET: JHB_SCHARP_006 - HIV Vaccine Trials")
        self.logger.info("="*60)
        
        dataset_path = self.raw_path / "JHB_SCHARP_006" / "csv"
        
        if not dataset_path.exists():
            self.logger.error(f"Dataset path not found: {dataset_path}")
            return pd.DataFrame()
        
        csv_files = sorted(dataset_path.glob("*.csv"))
        self.logger.info(f"Found {len(csv_files)} CSV files")
        
        all_data = []
        vaccine_data = []
        
        for csv_file in csv_files:
            self.logger.info(f"\n📄 Processing: {csv_file.name}")
            
            try:
                df = pd.read_csv(csv_file)
                self.logger.info(f"   Loaded: {len(df)} records, {len(df.columns)} columns")
                
                # Look for vaccine-specific data
                vaccine_cols = [col for col in df.columns if any(x in col.lower() for x in ['vaccine', 'dose', 'immunization', 'antibody'])]
                if vaccine_cols:
                    self.logger.info(f"   Vaccine-related columns: {len(vaccine_cols)}")
                    vaccine_data.append(csv_file.name)
                
                # Standardize
                standardized = self._standardize_dataset(df, 'scharp_006', csv_file.name)
                
                if not standardized.empty:
                    all_data.append(standardized)
                    
            except Exception as e:
                self.logger.error(f"   Error processing {csv_file.name}: {e}")
        
        # Combine and save
        if all_data:
            combined = pd.concat(all_data, ignore_index=True)
            
            if 'participant_id' in combined.columns:
                combined = combined.drop_duplicates(subset=['participant_id'])
            
            output_file = self.output_path / "enhanced_jhb_scharp_006.csv"
            combined.to_csv(output_file, index=False)
            
            self.logger.info(f"\n✅ JHB_SCHARP_006 extraction complete:")
            self.logger.info(f"   Total records: {len(combined)}")
            self.logger.info(f"   Variables: {len(combined.columns)}")
            self.logger.info(f"   Vaccine data files: {len(vaccine_data)}")
            self.logger.info(f"   Output: {output_file}")
            
            self._report_biomarkers_found(combined)
            
            return combined
        else:
            self.logger.warning("No data successfully extracted from JHB_SCHARP_006")
            return pd.DataFrame()
    
    def extract_jhb_vida_007(self) -> pd.DataFrame:
        """
        Extract JHB_VIDA_007 - Maternal/child health study.
        
        Expected features:
        - Maternal health indicators
        - Child health outcomes
        - Pregnancy/birth data
        """
        self.logger.info("\n" + "="*60)
        self.logger.info("DATASET: JHB_VIDA_007 - Maternal/Child Health")
        self.logger.info("="*60)
        
        dataset_path = self.raw_path / "JHB_VIDA_007" / "csv"
        
        if not dataset_path.exists():
            self.logger.error(f"Dataset path not found: {dataset_path}")
            return pd.DataFrame()
        
        csv_files = sorted(dataset_path.glob("*.csv"))
        self.logger.info(f"Found {len(csv_files)} CSV files")
        
        all_data = []
        maternal_files = []
        
        for csv_file in csv_files:
            self.logger.info(f"\n📄 Processing: {csv_file.name}")
            
            try:
                df = pd.read_csv(csv_file)
                self.logger.info(f"   Loaded: {len(df)} records, {len(df.columns)} columns")
                
                # Look for maternal/child indicators
                maternal_cols = [col for col in df.columns if any(x in col.lower() for x in 
                               ['maternal', 'pregnancy', 'birth', 'gestational', 'antenatal', 'postnatal'])]
                if maternal_cols:
                    self.logger.info(f"   Maternal health columns: {len(maternal_cols)}")
                    maternal_files.append(csv_file.name)
                
                # Standardize
                standardized = self._standardize_dataset(df, 'vida_007', csv_file.name)
                
                # Add maternal-specific features
                standardized = self._add_maternal_features(standardized, df)
                
                if not standardized.empty:
                    all_data.append(standardized)
                    
            except Exception as e:
                self.logger.error(f"   Error processing {csv_file.name}: {e}")
        
        # Combine and save
        if all_data:
            combined = pd.concat(all_data, ignore_index=True)
            
            if 'participant_id' in combined.columns:
                combined = combined.drop_duplicates(subset=['participant_id'])
            
            output_file = self.output_path / "enhanced_jhb_vida_007.csv"
            combined.to_csv(output_file, index=False)
            
            self.logger.info(f"\n✅ JHB_VIDA_007 extraction complete:")
            self.logger.info(f"   Total records: {len(combined)}")
            self.logger.info(f"   Variables: {len(combined.columns)}")
            self.logger.info(f"   Maternal data files: {len(maternal_files)}")
            self.logger.info(f"   Output: {output_file}")
            
            self._report_biomarkers_found(combined)
            
            return combined
        else:
            self.logger.warning("No data successfully extracted from JHB_VIDA_007")
            return pd.DataFrame()
    
    def extract_jhb_wrhi_003(self) -> pd.DataFrame:
        """
        Extract JHB_WRHI_003 - Women's reproductive health.
        
        WRHI = Wits Reproductive Health Institute
        Expected features:
        - Women's health focus
        - Reproductive health indicators
        - HIV prevention data
        """
        self.logger.info("\n" + "="*60)
        self.logger.info("DATASET: JHB_WRHI_003 - Women's Reproductive Health")
        self.logger.info("="*60)
        
        dataset_path = self.raw_path / "JHB_WRHI_003" / "csv"
        
        if not dataset_path.exists():
            self.logger.error(f"Dataset path not found: {dataset_path}")
            return pd.DataFrame()
        
        csv_files = sorted(dataset_path.glob("*.csv"))
        self.logger.info(f"Found {len(csv_files)} CSV files")
        
        all_data = []
        
        for csv_file in csv_files:
            self.logger.info(f"\n📄 Processing: {csv_file.name}")
            
            try:
                df = pd.read_csv(csv_file)
                self.logger.info(f"   Loaded: {len(df)} records, {len(df.columns)} columns")
                
                # Check for women's health indicators
                womens_health_cols = [col for col in df.columns if any(x in col.lower() for x in 
                                    ['contraception', 'reproductive', 'menstrual', 'pregnancy', 'family_planning'])]
                if womens_health_cols:
                    self.logger.info(f"   Women's health columns: {len(womens_health_cols)}")
                
                # Standardize
                standardized = self._standardize_dataset(df, 'wrhi_003', csv_file.name)
                
                if not standardized.empty:
                    all_data.append(standardized)
                    
            except Exception as e:
                self.logger.error(f"   Error processing {csv_file.name}: {e}")
        
        # Combine and save
        if all_data:
            combined = pd.concat(all_data, ignore_index=True)
            
            if 'participant_id' in combined.columns:
                combined = combined.drop_duplicates(subset=['participant_id'])
            
            output_file = self.output_path / "enhanced_jhb_wrhi_003.csv"
            combined.to_csv(output_file, index=False)
            
            self.logger.info(f"\n✅ JHB_WRHI_003 extraction complete:")
            self.logger.info(f"   Total records: {len(combined)}")
            self.logger.info(f"   Variables: {len(combined.columns)}")
            self.logger.info(f"   Output: {output_file}")
            
            self._report_biomarkers_found(combined)
            
            return combined
        else:
            self.logger.warning("No data successfully extracted from JHB_WRHI_003")
            return pd.DataFrame()
    
    # Helper methods
    
    def _standardize_dataset(self, df: pd.DataFrame, dataset_name: str, source_file: str) -> pd.DataFrame:
        """Standardize dataset to common format."""
        standardized = pd.DataFrame()
        
        # Add metadata
        standardized['dataset_name'] = dataset_name
        standardized['source_file'] = source_file
        
        # Participant ID standardization
        id_found = False
        for id_pattern in ['id', 'pid', 'participant', 'subject', 'patient', 'gsk_id', 'pt']:
            matching_cols = [col for col in df.columns if id_pattern in col.lower() and 'date' not in col.lower()]
            if matching_cols:
                standardized['participant_id'] = dataset_name + "_" + df[matching_cols[0]].astype(str)
                id_found = True
                break
        
        if not id_found:
            # Create sequential IDs
            standardized['participant_id'] = [f"{dataset_name}_{i:05d}" for i in range(len(df))]
        
        # Date standardization
        date_found = False
        for date_pattern in ['date', 'visit_date', 'collection_date', 'sample_date']:
            matching_cols = [col for col in df.columns if date_pattern in col.lower()]
            if matching_cols:
                try:
                    standardized['visit_date'] = pd.to_datetime(df[matching_cols[0]], errors='coerce')
                    date_found = True
                    break
                except:
                    pass
        
        # Demographics
        if 'age' in df.columns:
            standardized['demographic_age'] = pd.to_numeric(df['age'], errors='coerce')
        
        # Gender/Sex
        for gender_col in ['gender', 'sex', 'participant_gender']:
            if gender_col in df.columns:
                standardized['demographic_sex'] = df[gender_col]
                break
        
        # Standardize biomarkers
        for biomarker_type, patterns in self.biomarker_patterns.items():
            for col in df.columns:
                if any(pattern in col.lower() for pattern in patterns):
                    std_name = f'biomarker_{biomarker_type}'
                    try:
                        standardized[std_name] = pd.to_numeric(df[col], errors='coerce')
                        break
                    except:
                        pass
        
        return standardized
    
    def _identify_biomarkers(self, df: pd.DataFrame) -> List[str]:
        """Identify biomarkers in dataset."""
        found_biomarkers = []
        
        for biomarker_type, patterns in self.biomarker_patterns.items():
            for col in df.columns:
                if any(pattern in col.lower() for pattern in patterns):
                    found_biomarkers.append(biomarker_type)
                    break
        
        return found_biomarkers
    
    def _add_pediatric_features(self, standardized: pd.DataFrame, original_df: pd.DataFrame) -> pd.DataFrame:
        """Add pediatric-specific features."""
        
        # Growth percentiles
        for growth_var in ['height_percentile', 'weight_percentile', 'bmi_percentile']:
            if growth_var in original_df.columns:
                standardized[f'pediatric_{growth_var}'] = pd.to_numeric(original_df[growth_var], errors='coerce')
        
        # Development milestones
        for dev_var in ['developmental_score', 'cognitive_score', 'motor_score']:
            if dev_var in original_df.columns:
                standardized[f'pediatric_{dev_var}'] = pd.to_numeric(original_df[dev_var], errors='coerce')
        
        return standardized
    
    def _add_maternal_features(self, standardized: pd.DataFrame, original_df: pd.DataFrame) -> pd.DataFrame:
        """Add maternal health features."""
        
        # Pregnancy indicators
        for maternal_var in ['gestational_age', 'gravidity', 'parity', 'anc_visits']:
            if maternal_var in original_df.columns:
                standardized[f'maternal_{maternal_var}'] = pd.to_numeric(original_df[maternal_var], errors='coerce')
        
        # Birth outcomes
        for birth_var in ['birth_weight', 'apgar_score', 'delivery_type']:
            if birth_var in original_df.columns:
                if birth_var == 'delivery_type':
                    standardized[f'maternal_{birth_var}'] = original_df[birth_var]
                else:
                    standardized[f'maternal_{birth_var}'] = pd.to_numeric(original_df[birth_var], errors='coerce')
        
        return standardized
    
    def _report_biomarkers_found(self, df: pd.DataFrame) -> None:
        """Report biomarkers found in dataset."""
        biomarker_cols = [col for col in df.columns if col.startswith('biomarker_')]
        
        if biomarker_cols:
            self.logger.info(f"\n🔬 Biomarkers found: {len(biomarker_cols)}")
            for col in sorted(biomarker_cols):
                non_missing = df[col].notna().sum()
                if non_missing > 0:
                    self.logger.info(f"   - {col}: {non_missing} values")
    
    def extract_all_additional_datasets(self) -> Dict[str, pd.DataFrame]:
        """Extract all additional high-value datasets."""
        
        self.logger.info("="*80)
        self.logger.info("🚀 EXTRACTING ALL ADDITIONAL HIGH-VALUE DATASETS")
        self.logger.info("="*80)
        
        results = {}
        
        # 1. JHB_Ezin_002 - Largest dataset
        try:
            ezin = self.extract_jhb_ezin_002()
            if not ezin.empty:
                results['jhb_ezin_002'] = ezin
        except Exception as e:
            self.logger.error(f"Ezin extraction failed: {e}")
        
        # 2. JHB_IMPAACT_010 - Pediatric HIV
        try:
            impaact = self.extract_jhb_impaact_010()
            if not impaact.empty:
                results['jhb_impaact_010'] = impaact
        except Exception as e:
            self.logger.error(f"IMPAACT extraction failed: {e}")
        
        # 3. JHB_SCHARP_006 - HIV vaccine trials
        try:
            scharp = self.extract_jhb_scharp_006()
            if not scharp.empty:
                results['jhb_scharp_006'] = scharp
        except Exception as e:
            self.logger.error(f"SCHARP extraction failed: {e}")
        
        # 4. JHB_VIDA_007 - Maternal/child health
        try:
            vida = self.extract_jhb_vida_007()
            if not vida.empty:
                results['jhb_vida_007'] = vida
        except Exception as e:
            self.logger.error(f"VIDA extraction failed: {e}")
        
        # 5. JHB_WRHI_003 - Women's reproductive health
        try:
            wrhi003 = self.extract_jhb_wrhi_003()
            if not wrhi003.empty:
                results['jhb_wrhi_003'] = wrhi003
        except Exception as e:
            self.logger.error(f"WRHI_003 extraction failed: {e}")
        
        # Summary report
        self.logger.info("\n" + "="*80)
        self.logger.info("📊 ADDITIONAL DATASET EXTRACTION SUMMARY")
        self.logger.info("="*80)
        
        total_participants = 0
        total_biomarkers = set()
        
        for dataset_name, df in results.items():
            biomarker_cols = [col for col in df.columns if col.startswith('biomarker_')]
            total_participants += len(df)
            total_biomarkers.update([col.replace('biomarker_', '') for col in biomarker_cols])
            
            self.logger.info(f"\n✅ {dataset_name}:")
            self.logger.info(f"   - Records: {len(df)}")
            self.logger.info(f"   - Variables: {len(df.columns)}")
            self.logger.info(f"   - Biomarkers: {len(biomarker_cols)}")
        
        self.logger.info(f"\n📈 TOTALS:")
        self.logger.info(f"   - Datasets extracted: {len(results)}")
        self.logger.info(f"   - Total participants: {total_participants}")
        self.logger.info(f"   - Unique biomarker types: {len(total_biomarkers)}")
        self.logger.info(f"\n📁 All datasets saved to: {self.output_path}")
        
        return results


def main():
    """Main execution function."""
    print("🚀 EXTRACTING ADDITIONAL HIGH-VALUE DATASETS FROM RP2")
    print("="*80)
    
    extractor = AdditionalDatasetExtractor()
    
    # Extract all additional datasets
    results = extractor.extract_all_additional_datasets()
    
    print(f"\n✅ Extraction complete!")
    print(f"📊 Successfully extracted {len(results)} additional datasets")
    print(f"🎯 Ready for climate integration and XAI pipeline")
    
    return results


if __name__ == "__main__":
    main()