#!/usr/bin/env python
"""
Model Optimization Module

Hyperparameter optimization and model selection for heat vulnerability analysis.
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Tuple, Any, Optional
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.linear_model import Ridge, ElasticNet
from sklearn.model_selection import RandomizedSearchCV, cross_val_score
from sklearn.metrics import r2_score
import warnings
warnings.filterwarnings('ignore')

class ModelOptimizer:
    """Optimizes models for pathway-specific analysis."""
    
    def __init__(self):
        self.model_configs = {
            'random_forest': {
                'model': RandomForestRegressor,
                'params': {
                    'n_estimators': [50, 100, 200],
                    'max_depth': [5, 10, 15, None],
                    'min_samples_split': [5, 10, 20],
                    'min_samples_leaf': [2, 5, 10],
                    'max_features': ['sqrt', 'log2', None]
                }
            },
            'gradient_boosting': {
                'model': GradientBoostingRegressor,
                'params': {
                    'n_estimators': [50, 100, 200],
                    'max_depth': [3, 5, 7],
                    'learning_rate': [0.01, 0.1, 0.2],
                    'subsample': [0.8, 0.9, 1.0],
                    'min_samples_split': [5, 10, 20]
                }
            },
            'ridge': {
                'model': Ridge,
                'params': {
                    'alpha': [0.1, 1.0, 10.0, 100.0],
                    'solver': ['auto', 'svd', 'cholesky']
                }
            },
            'elastic_net': {
                'model': ElasticNet,
                'params': {
                    'alpha': [0.1, 1.0, 10.0],
                    'l1_ratio': [0.1, 0.5, 0.7, 0.9],
                    'max_iter': [1000, 2000]
                }
            }
        }
    
    def optimize_pathway_model(self, X_train: pd.DataFrame, 
                              y_train: pd.Series,
                              pathway: str,
                              model_types: Optional[List[str]] = None,
                              cv_folds: int = 5,
                              random_seed: int = 42) -> Tuple[Any, Dict[str, Any], np.ndarray]:
        """
        Optimize model for specific pathway.
        
        Args:
            X_train: Training features
            y_train: Training target
            pathway: Pathway name (for logging)
            model_types: List of model types to try
            cv_folds: Cross-validation folds
            random_seed: Random seed for reproducibility
            
        Returns:
            Tuple of (best_model, best_params, cv_scores)
        """
        if model_types is None:
            model_types = ['random_forest', 'gradient_boosting', 'ridge']
        
        print(f"   🔧 Optimizing models: {', '.join(model_types)}")
        
        best_model = None
        best_params = {}
        best_score = -np.inf
        best_cv_scores = None
        
        for model_type in model_types:
            if model_type not in self.model_configs:
                print(f"   ⚠️  Unknown model type: {model_type}")
                continue
            
            config = self.model_configs[model_type]
            
            # Create base model
            base_model = config['model'](random_state=random_seed)
            
            # Hyperparameter search
            search = RandomizedSearchCV(
                base_model,
                config['params'],
                n_iter=20,  # Reduced for efficiency
                cv=cv_folds,
                scoring='r2',
                random_state=random_seed,
                n_jobs=-1
            )
            
            try:
                search.fit(X_train, y_train)
                
                # Cross-validation scores
                cv_scores = cross_val_score(
                    search.best_estimator_, 
                    X_train, y_train, 
                    cv=cv_folds, 
                    scoring='r2'
                )
                
                mean_cv_score = cv_scores.mean()
                
                print(f"     {model_type}: CV R² = {mean_cv_score:.3f} ± {cv_scores.std():.3f}")
                
                if mean_cv_score > best_score:
                    best_score = mean_cv_score
                    best_model = search.best_estimator_
                    best_params = {model_type: search.best_params_}
                    best_cv_scores = cv_scores
                    
            except Exception as e:
                print(f"     {model_type}: Failed - {str(e)}")
                continue
        
        if best_model is None:
            # Fallback to simple Random Forest
            print("   🔄 Falling back to default Random Forest")
            best_model = RandomForestRegressor(
                n_estimators=100,
                max_depth=10,
                random_state=random_seed
            )
            best_model.fit(X_train, y_train)
            best_cv_scores = cross_val_score(best_model, X_train, y_train, cv=cv_folds, scoring='r2')
            best_params = {'random_forest_default': best_model.get_params()}
        
        print(f"   ✅ Best model: {type(best_model).__name__} (CV R² = {best_cv_scores.mean():.3f})")
        
        return best_model, best_params, best_cv_scores
    
    def evaluate_feature_importance(self, model: Any, feature_names: List[str]) -> pd.DataFrame:
        """
        Extract feature importance from trained model.
        
        Args:
            model: Trained scikit-learn model
            feature_names: List of feature names
            
        Returns:
            DataFrame with feature importance scores
        """
        try:
            if hasattr(model, 'feature_importances_'):
                # Tree-based models
                importance_scores = model.feature_importances_
            elif hasattr(model, 'coef_'):
                # Linear models
                importance_scores = np.abs(model.coef_)
            else:
                # Unknown model type
                importance_scores = np.zeros(len(feature_names))
            
            importance_df = pd.DataFrame({
                'feature': feature_names,
                'importance': importance_scores
            }).sort_values('importance', ascending=False)
            
            return importance_df
            
        except Exception as e:
            print(f"   ⚠️  Feature importance extraction failed: {e}")
            return pd.DataFrame({'feature': feature_names, 'importance': 0})